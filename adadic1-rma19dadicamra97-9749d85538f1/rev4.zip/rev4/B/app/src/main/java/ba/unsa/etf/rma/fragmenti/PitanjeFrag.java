package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizAkt;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.klase.ShareIgraj.broj_preostalih;
import static ba.unsa.etf.rma.klase.ShareIgraj.broj_tacnih;
import static ba.unsa.etf.rma.klase.ShareIgraj.igraj_kviz;
import static ba.unsa.etf.rma.klase.ShareIgraj.broj;


public class PitanjeFrag extends Fragment {

    private ArrayList<String> odgovori=new ArrayList<>();

    private ArrayAdapter adaptOdg;
    private OnFragmentInteractionListener mListener;
    private ListView listaOdg;
    private TextView naziv;
    private ArrayList<Pitanje> pitanja;
    private Pitanje izabrano;
    private int trenutni_odg=-1;

    public PitanjeFrag() {

    }


    public static PitanjeFrag newInstance(String param1, String param2) {
        PitanjeFrag fragment = new PitanjeFrag();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        broj=igraj_kviz.getPitanja().size();
        super.onCreate(savedInstanceState);



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_pitanje, container, false);

        pitanja=igraj_kviz.getPitanja();
        listaOdg=(ListView) v.findViewById(R.id.odgovoriPitanja);
        adaptOdg=new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, odgovori){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                // Get the current item from ListView
                View view = super.getView(position,convertView,parent);
               if(trenutni_odg!=-1 && odgovori.get(position).equals(izabrano.getTacan()))
               view.setBackgroundColor(Color.parseColor("#7FFF00"));
               else if(trenutni_odg==-1)
                   view.setBackgroundColor(Color.parseColor("#FFFFFF"));
                return view;
            }
        };
        listaOdg.setAdapter(adaptOdg);
        naziv=(TextView) v.findViewById(R.id.tekstPitanja);
        broj_preostalih=igraj_kviz.getPitanja().size();

        izaberiPitanje();
        listaOdg.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                broj++;
                trenutni_odg=pos;
               if(!odgovori.get(pos).equals(izabrano.getTacan())){
                       // Set a background color for ListView regular row/item
                       view.setBackgroundColor(Color.parseColor("#FF3030"));
                        onButtonPressed(igraj_kviz);
                        adaptOdg.notifyDataSetChanged();

               }else{
                   broj_tacnih++;
                   onButtonPressed(igraj_kviz);
                   adaptOdg.notifyDataSetChanged();


               }

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if(broj_preostalih!=0)
                        izaberiPitanje();
                        else{
                            onButtonPressed(igraj_kviz);
                            naziv.setText("Kviz je završen!");
                            odgovori.removeAll(odgovori);
                            adaptOdg.notifyDataSetChanged();
                        }
                    }
                }, 2000);
         ;


            }
        });
        return v;
    }

    private void izaberiPitanje(){
        int r= ThreadLocalRandom.current().nextInt(0,  pitanja.size());
        broj_preostalih--;
        onButtonPressed(igraj_kviz);
        izabrano=pitanja.get(r);
        pitanja.remove(r);
        naziv.setText(izabrano.getNaziv());
        odgovori.removeAll(odgovori);
        for(String o:izabrano.getOdgovori()){
            odgovori.add(o);
        }
        trenutni_odg=-1;
        adaptOdg.notifyDataSetChanged();
    }
    public void onButtonPressed(Kviz k) {
        if (mListener != null) {
            mListener.onFragmentInteraction(k);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Kviz kviz);
    }
}
