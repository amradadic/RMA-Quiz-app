package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CustomListPitanjaAdapter;
import ba.unsa.etf.rma.klase.CustomSpinnerAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.klase.PomocnaBaza.kvizovi;
import static ba.unsa.etf.rma.klase.PomocnaBaza.kategorije;
import static ba.unsa.etf.rma.klase.ShareKviz.sharePitanja;
import static ba.unsa.etf.rma.klase.ShareKviz.uredi;


public class DodajKvizAkt extends AppCompatActivity {
    public class VratiKategorijuTask extends  AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            String TOKEN="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENTA PITANJA KOJA SU SADRZANA U KVIZU KOJI SE TREBA SPASIT U BAZU-RJESENO
                String url2 = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kategorije?access_token=" + TOKEN;
                URL url3;

                url3 = new URL(url2);
                HttpURLConnection urlConnection = (HttpURLConnection) url3.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rez = convertStreamToString(in);
                JSONObject j = null;
                j = new JSONObject(rez);
                JSONArray items = j.getJSONArray("documents");

                for (int i = 0; i < items.length(); i++) {
                    JSONObject name = null;
                    name = items.getJSONObject(i);
                    String id = name.getString("name");
                    id = id.substring(65);
                    JSONObject pitanje = name.getJSONObject("fields");
                    String naziv = pitanje.getJSONObject("naziv").getString("stringValue");

                        if (trenutniKviz.getKategorija().getNaziv().equals(naziv)) {
                            kategorijaIdDokumenta=id;
                        }

                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class VratiPitanjaTask extends  AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            String TOKEN="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENTA PITANJA KOJA SU SADRZANA U KVIZU KOJI SE TREBA SPASIT U BAZU-RJESENO
                String url2 = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Pitanja?access_token=" + TOKEN;
                URL url3;

                url3 = new URL(url2);
                HttpURLConnection urlConnection = (HttpURLConnection) url3.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rez = convertStreamToString(in);
                JSONObject j = null;
                j = new JSONObject(rez);
                JSONArray dok = j.getJSONArray("documents");

                for (int i = 0; i < dok.length(); i++) {
                    JSONObject name = null;
                    name = dok.getJSONObject(i);
                    String id = name.getString("name");
                    id = id.substring(62);
                    JSONObject pitanje = name.getJSONObject("fields");
                    String naziv = pitanje.getJSONObject("naziv").getString("stringValue");
                    for (Pitanje p : trenutniKviz.getPitanja()) {
                        if (p.getNaziv().equals(naziv)) {
                            pitanjaUKvizuIdDokumenta.add(id);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class KreirajDokumentKvizTask extends AsyncTask<String,Void,Void> {
        @Override
        protected void onPreExecute() {
            new VratiPitanjaTask().execute("Spirala3");
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            String TOKEN="";
            try{
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA",TOKEN);


                String url="https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kvizovi?access_token=";

                URL urlObj=new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn= (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept","application/json");
                //conn.setRequestProperty("User-Agent","Mozilla/5.0 ( compatible ) ");

                String dokument= "{ \"fields\": {\"pitanja\": {\"arrayValue\": {\"values\": [";
                int i=0;
                for(String p: pitanjaUKvizuIdDokumenta){
                    if(i!=0) dokument+=",";
                    i++;
                    dokument+="{\"stringValue\":\""+p+"\"}"; //ovdje treba promijeniti da trazi id dokumenta tog pitanja-RJESENO
                }

                 dokument+="              \n" +
                        "            ]\n" +
                        "          }\n" +
                        "        },\n" +
                        "        \"naziv\": {\n" +
                        "          \"stringValue\": \""+trenutniKviz.getNaziv()+"\"\n" +
                        "        },\n" +
                        "        \"idKategorije\": {\n" +
                        "          \"stringValue\": \""+trenutniKviz.getKategorija().getIdBaza()+"\"\n" + //ovdje treba promijenit trazit id kategorije dokumenta
                        "        }\n" +
                        "      }}";

                try(OutputStream os= conn.getOutputStream()){
                    byte[] input= dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = conn.getResponseCode();

                InputStream odgovor= conn.getInputStream();
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response= new StringBuilder();
                    String responseLine=null;
                    while((responseLine = br.readLine())!= null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR",response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }


    private class EditujKvizTask extends AsyncTask<String, Integer, Void> {
        @Override
        protected void onPreExecute() {
            new VratiKategorijuTask().execute("Spirala3");
            new VratiPitanjaTask().execute("Spirala3");
            super.onPreExecute();
        }

        protected  Void doInBackground(String... urls) {
            String idKviza="";
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            try {
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

            String TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENT TRENUTNOG KVIZA
                String url2 = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kvizovi?access_token=" + TOKEN;
                URL url3;

                url3 = new URL(url2);
                HttpURLConnection urlConnection = (HttpURLConnection) url3.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rez = convertStreamToString(in);
                JSONObject j = null;
                j = new JSONObject(rez);
                JSONArray dok = j.getJSONArray("documents");

                for (int i = 0; i < dok.length(); i++) {
                    JSONObject name = null;
                    name = dok.getJSONObject(i);
                    String id = name.getString("name");
                    id = id.substring(62);
                    JSONObject kviz = name.getJSONObject("fields");
                    String naziv = kviz.getJSONObject("naziv").getString("stringValue");

                        if (trenutniKviz.getNaziv().equals(naziv)) {
                           idKviza=id;
                           break;
                        }
                }

            String url1;
            url1 = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kvizovi?documentId=" + idKviza + "&access_token=" + TOKEN;
            URL url;

                url = new URL(url1);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent","Mozilla/5.0 ( compatible ) ");
                String dokument = "";
                int i = 0;
                dokument = "{ \"fields\": { \"pitanja\": { \"arrayValue\": { \"values\": [" ;
                    for(String p : pitanjaUKvizuIdDokumenta) {
                        if(i>0)
                            dokument += ",{ \"stringValue\": \"" + p + "\"} ";
                        else
                            dokument += "{ \"stringValue\": \"" + p + "\"} ";
                        i++;
                    }

                    dokument += "]}}, \"naziv\": { \"stringValue\": \"" + trenutniKviz.getNaziv() + "\"}, \"idKategorije\": { \"stringValue\": \"" + kategorijaIdDokumenta + "\"}}}";


                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
            }  catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null ;
        }

    }
    public class MogucaPitanjaTask extends AsyncTask<String,Void,Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            String TOKEN="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENTA PITANJA KOJA SU SADRZANA U KVIZU KOJI SE TREBA SPASIT U BAZU
                String url2 = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Pitanja?access_token=" + TOKEN;
                URL url3;

                url3 = new URL(url2);
                HttpURLConnection urlConnection = (HttpURLConnection) url3.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rez = convertStreamToString(in);
                JSONObject j = null;
                j = new JSONObject(rez);
                JSONArray dok = j.getJSONArray("documents");

                for (int i = 0; i < dok.length(); i++) {
                    JSONObject name = null;
                    name = dok.getJSONObject(i);
                    JSONObject pitanje = name.getJSONObject("fields");
                    String naziv = pitanje.getJSONObject("naziv").getString("stringValue");
                    int indexTacnog = Integer.parseInt(pitanje.getJSONObject("indexTacnog").getString("integerValue"));
                    ArrayList<String> odgovori = new ArrayList<String>();
                    JSONArray nizOdg = pitanje.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                    for (int r = 0; r < nizOdg.length(); r++){
                        odgovori.add(nizOdg.getJSONObject(r).getString("stringValue"));
                    }
                    Pitanje pit = new Pitanje(naziv, naziv, odgovori, odgovori.get(indexTacnog));
                   // mogucaPitanja.removeAll(mogucaPitanja);
                    if(sharePitanja.size()>1) {
                        boolean b=false;
                        for (Pitanje p : sharePitanja) {
                            if (p.getNaziv().equals(naziv)) {
                                b=true;
                                break;

                            }
                        }
                        if(!b) mogucaPitanja.add(pit);
                    }
                    else {
                        mogucaPitanja.add(pit);
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    private ArrayList<Pitanje> mogucaPitanja=new ArrayList<>();
    private Kviz trenutniKviz=new Kviz();
    private EditText nazivKviza;
    private ListView lista;
    private Spinner spinner;
    private ListView listaMogucih;
    private CustomListPitanjaAdapter pitanjauKvizuAdapter, mogucaPitanjaAdapter;
    private  DodajKvizAkt CustomListView = null;
    private  Kategorija odabranaKat;
    private Button dugmeDodaj;
    private Button dugmeImport;
    private static final int READ_REQUEST_CODE = 42;
    private CustomSpinnerAdapter spinerAdap2;
    private ArrayList<Kategorija> kat2=new ArrayList<>();
    private Pitanje dodaj= new Pitanje();
    private ArrayList<String> pitanjaUKvizuIdDokumenta = new ArrayList<>();
    private String kategorijaIdDokumenta;
    private String token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_dodajkviz);
        Resources res=getResources();
        nazivKviza= findViewById(R.id.etNaziv);
        lista=findViewById(R.id.lvDodanaPitanja);
        listaMogucih=findViewById(R.id.lvMogucaPitanja);

        CustomListView=this;
        mogucaPitanjaAdapter= new CustomListPitanjaAdapter(CustomListView, mogucaPitanja,res);
        listaMogucih.setAdapter(mogucaPitanjaAdapter);
        dugmeDodaj= findViewById(R.id.btnDodajKviz);

        init();



        dodaj.setNaziv("Dodaj Pitanje");
        spinner= (Spinner) findViewById(R.id.spKategorije);
        dugmeImport=(Button) findViewById(R.id.btnImportKviz);
        Kategorija k=new Kategorija();
        for(Kategorija kate: kategorije) if(!kat2.contains(kate)) kat2.add(kate);
        k.setNaziv("Dodaj Kategoriju");
        k.setId("3");
        if(!kat2.contains(k))
        kat2.add(k);
        spinerAdap2= new CustomSpinnerAdapter(this, kat2);
        spinner.setAdapter(spinerAdap2);
        pitanjauKvizuAdapter = new CustomListPitanjaAdapter( CustomListView, sharePitanja, res );
        lista.setAdapter( pitanjauKvizuAdapter );

        if(uredi!=null){
            nazivKviza.setText(uredi.getNaziv());
            int i=0;
            for(i=0;i<kat2.size();i++){
                if(kat2.get(i).getNaziv().equals(uredi.getKategorija().getNaziv()))
                    break;
            }
            spinner.setSelection(i);
            odabranaKat=kat2.get(i);
            ArrayList<Pitanje> pu=uredi.getPitanja();
            if(uredi.getPitanja().size()>=1)
            for(int l=0;l<uredi.getPitanja().size();l++){
                boolean b= false;
                for(int m=l+1;m<uredi.getPitanja().size();m++){
                    if(pu.get(l).getId().equals(pu.get(m).getId())) b=true;
                }
               if(b) uredi.getPitanja().remove(l);
            }
            for(Pitanje p: uredi.getPitanja()){
                sharePitanja.add(p);
            }
            pitanjauKvizuAdapter.notifyDataSetChanged();
        }

        dugmeImport.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

                intent.addCategory(Intent.CATEGORY_OPENABLE);


                intent.setType("text/*");

                startActivityForResult(intent, READ_REQUEST_CODE);
            }
        });



        if(!sharePitanja.contains(dodaj))
            sharePitanja.add(dodaj);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Kategorija clikedItem=(Kategorija) parent.getItemAtPosition(pos);
                String clickesKatNaziv=clikedItem.getNaziv();
                if(!clickesKatNaziv.equals("Dodaj Kategoriju")){
                Toast.makeText(DodajKvizAkt.this,"Odabrali ste: "+clickesKatNaziv, Toast.LENGTH_SHORT).show();
                odabranaKat=clikedItem;
                } else{
                    Intent intent=new Intent(DodajKvizAkt.this,DodajKategorijuAkt.class);
                    startActivityForResult(intent,1);

                }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
        });

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                //Kviz clikedItem=(Kviz) parent.getItemAtPosition(pos);
                String clickedKvizNaziv=sharePitanja.get(pos).getNaziv();
                if(clickedKvizNaziv.equals("Dodaj Pitanje")) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    startActivityForResult(intent,1);


                } else {
                    mogucaPitanja.add(sharePitanja.get(pos));
                    mogucaPitanjaAdapter.notifyDataSetChanged();
                    sharePitanja.remove(pos);
                    pitanjauKvizuAdapter.notifyDataSetChanged();
                }

            }

        });

        listaMogucih.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                Pitanje clickedItem=mogucaPitanja.get(pos);
                sharePitanja.add(sharePitanja.size()-1,clickedItem);
                pitanjauKvizuAdapter.notifyDataSetChanged();
                mogucaPitanja.remove(pos);
                mogucaPitanjaAdapter.notifyDataSetChanged();


            }

        });


        dugmeDodaj.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                trenutniKviz.setNaziv(nazivKviza.getText().toString());
                ArrayList<Pitanje> pomoc=new ArrayList<>();
                for(Pitanje p: sharePitanja)
                    if(!p.getNaziv().equals("Dodaj Pitanje")) pomoc.add(p);
                trenutniKviz.setPitanja(pomoc);
                sharePitanja.removeAll(sharePitanja);
                Log.e("KAT","ovo je odabrana :" +odabranaKat.getNaziv());
                odabranaKat= (Kategorija) spinner.getSelectedItem();
                trenutniKviz.setKategorija(odabranaKat);
                boolean tr=false;
                int i=0;
                for(i=0;i<kvizovi.size();i++){
                    if(kvizovi.get(i).getNaziv().equals(trenutniKviz.getNaziv())) {
                        tr=true;
                        break;
                    }
                }
                if(tr) kvizovi.remove(i);
                kvizovi.add(trenutniKviz);
                if(uredi==null)
                new KreirajDokumentKvizTask().execute("Spirala3");
                else new EditujKvizTask().execute("Spirala3");
                uredi=null;
                Intent intent = new Intent();

                setResult(1,intent);
                finish();
            }
        });

    }
    private String readTextFromUri(Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptor =
                getContentResolver().openFileDescriptor(uri, "r");
        FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append("\n");
            stringBuilder.append(line);
        }
        inputStream.close();
        parcelFileDescriptor.close();
        return stringBuilder.toString();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

            if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {

                Uri uri = null;
                if (data != null) {
                    uri = data.getData();

                    try {
                        String s=readTextFromUri(uri);
                        String[] parts = s.split("\n");
                        String naziv=parts[1];
                        String kat;
                        int slucaj=0;
                        String[] prviRed =naziv.split(",");
                        naziv= prviRed[0];
                        kat= prviRed[1];
                        int br_pitanja;
                        br_pitanja=Integer.parseInt(prviRed[2].replaceAll(" ",""));
                        for(Kviz k: kvizovi){
                            if(k.getNaziv().equals(naziv)) {
                                slucaj=1;
                                break;

                            }
                        }
                        if(br_pitanja!=parts.length-2) slucaj=2;

                            switch (slucaj){
                                case 0: {
                                    boolean r=false;
                                    Kviz kvizimp= new Kviz();
                                    kvizimp.setNaziv(naziv);
                                    nazivKviza.setText(naziv);
                                    boolean p=false;
                                    int i=0;
                                    for(Kategorija k: kategorije){
                                        if(k.getNaziv().equals(kat)){
                                            p=true;
                                            break;
                                        }
                                      i++;
                                    }
                                    if(p) {
                                        spinner.setSelection(i);
                                        odabranaKat= kat2.get(i);
                                    }
                                    else{
                                        Kategorija novakat=new Kategorija();
                                        novakat.setId("3");
                                        novakat.setNaziv(kat);
                                        kategorije.add(novakat);
                                        kat2.removeAll(kat2);
                                        Kategorija k=new Kategorija();
                                        for(Kategorija kate: kategorije)  kat2.add(kate);
                                        k.setNaziv("Dodaj Kategoriju");
                                        k.setId("2");
                                        kat2.add(k);
                                        spinerAdap2.notifyDataSetChanged();
                                        spinner.setSelection(kategorije.size()-1);

                                    }
                                    ArrayList<Pitanje> pitanja= new ArrayList<>();
                                    for(int j=2;j<parts.length;j++){
                                        //i=0 će uvijek biti prazan red
                                        //i=1 je naziv,kat,br
                                        String[] red= parts[j].split(",");
                                        String naziv_pitanja=red[0];
                                        int br_odgovora= Integer.parseInt(red[1].replaceAll(" ",""));
                                        if(br_odgovora!=red.length-3) {
                                            r = true;
                                            break;
                                        }
                                        ArrayList<String> odgovori=new ArrayList<>();
                                        for(int u=3;u<red.length;u++) {
                                            odgovori.add(red[u]);
                                        }
                                        Pitanje pit=new Pitanje();
                                        pit.setNaziv(naziv_pitanja);
                                        pit.setTekstPitanja(naziv_pitanja);
                                        pit.setOdgovori(odgovori);
                                        String tacan=red[2].replace(" ","");
                                        int t=Integer.parseInt(tacan);
                                        pit.setTacan(odgovori.get(t));
                                        pitanja.add(pit);
                                    }

                                    kvizimp.setPitanja(pitanja);
                                    trenutniKviz=kvizimp;
                                    sharePitanja.removeAll(sharePitanja);
                                    for(Pitanje pita: pitanja){
                                        sharePitanja.add(pita);
                                    }
                                    sharePitanja.add(dodaj);
                                    pitanjauKvizuAdapter.notifyDataSetChanged();
                                    break;
                                }
                                case 1:{
                                    new AlertDialog.Builder(DodajKvizAkt.this)
                                            .setTitle("IMPORT")
                                            .setMessage("Kviz kojeg importujete već postoji!")
                                            .setPositiveButton("povratak na dodavanje kviza", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {

                                        }
                                    })


                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                                    break;
                                }
                                case 2:{
                                    new AlertDialog.Builder(DodajKvizAkt.this)
                                            .setTitle("IMPORT")
                                            .setMessage("Kviz kojeg imporujete ima neispravan broj pitanja!")
                                            .setPositiveButton("povratak na dodavanje kviza", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {

                                                }
                                            })


                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                                    break;
                                }
                            }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
        if (resultCode == 1) {
            pitanjauKvizuAdapter.notifyDataSetChanged();


        }
        if (resultCode == 2) {

            Kategorija k=new Kategorija();
            kat2.removeAll(kat2);
            for(Kategorija kate: kategorije)  kat2.add(kate);
            k.setNaziv("Dodaj Kategoriju");
            k.setId("2");
                kat2.add(k);
            spinerAdap2.notifyDataSetChanged();
            spinner.setSelection(kategorije.size()-1);

        }
    }
    private void init() {
       /* if(kvizovi!=null)
       if (kvizovi .size()!=0) {
           for (Kviz k : kvizovi) {
               ArrayList<Pitanje> temp = k.getPitanja();
               for (Pitanje p : temp) {
                   mogucaPitanja.add(p);
              }
           }
           mogucaPitanjaAdapter.notifyDataSetChanged();

        }*/
        int vel= mogucaPitanja.size();
        new MogucaPitanjaTask().execute("Spirala3");
        int vel2=mogucaPitanja.size();
        if(vel!=vel2)
        mogucaPitanjaAdapter.notifyDataSetChanged();
   }
    public static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
        } finally {
            try {
                is.close();
            } catch (IOException e) {
            }
        }
        return sb.toString();
    }
}
