package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class RangListaFrag extends Fragment {
    private ListView lista;
    private ArrayList<Pair<String,Double>> korisnici= new ArrayList<>();
    private ArrayList<String> rangLista=new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.rang_lista_fragment, container, false);
        lista=v.findViewById(R.id.rangLista);
        lista.setClickable(false);
        lista.setLongClickable(false);
        if (getArguments() != null)
            korisnici= (ArrayList<Pair<String, Double>>) getArguments().getSerializable("korisnici");
        for (int i = 0; i <korisnici.size() ; i++) {
            rangLista.add(i+1+ ". "+ korisnici.get(i).first + " - "+String.format("%.2f", korisnici.get(i).second)+"%");
        }
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final ArrayAdapter<String> adapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,rangLista);
        lista.setAdapter(adapter);
    }
}
