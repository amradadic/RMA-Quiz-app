package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import ba.unsa.etf.rma.ListaPitanjaAdapter;
import ba.unsa.etf.rma.ProvjeraKonekcije;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.SpinerAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity {
    private Spinner spinner;
    private EditText naziv;
    private ListView trenutna;
    private ListView moguca;
    private Button dugme;
    private Button dugmeZaImport;
    private ArrayList<Pitanje> trenutnaPitanja=new ArrayList<>();
    private ArrayList<Pitanje> mogucaPitanja=new ArrayList<>();
    private ListaPitanjaAdapter adapterMogucih;
    private ListaPitanjaAdapter adapterTrenutnih;
    private Kviz finalPoslani=null;
    private  ArrayList<Kviz> prisutniKvizovi;
    private SpinerAdapter spinerAdapter;
    private ArrayList<Kategorija> elementiSpinera=new ArrayList<>();
    private boolean dodanaNovaKategorija=false;
    private String stariNaziv="";
    private boolean postojiUBazi=false;
    private int index;
    private Context aktivnost;
    private boolean zaDodavanje=false;
    public class BazaZaPitanja extends AsyncTask<String, Void, Void>{
        @Override
        protected Void doInBackground(String... params) {
            mogucaPitanja.clear();
            GoogleCredential credentials;
            String url1 = "https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/Pitanja/?access_token=";
            ArrayList<Pitanje> izBaze= new ArrayList<>();
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();

                URL url = new URL(url1+TOKEN);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);

                JSONObject jo = new JSONObject(rezultat);

                JSONArray items = jo.getJSONArray("documents");
                Log.d("izBaze", ""+items.length());
                for (int i = 0; i < items.length(); i++) {
                    JSONObject pitanje = items.getJSONObject(i);
                    JSONObject polja = pitanje.getJSONObject("fields");
                    JSONObject ime = polja.getJSONObject("naziv");
                    String naziv = ime.getString("stringValue");
                    Log.d("imee", naziv);
                    JSONObject indexTacnog = polja.getJSONObject("indexTacnog");
                     index = indexTacnog.getInt("integerValue");
                    Log.d("index tacog", "doInBackground: "+index);
                    JSONObject odgs= polja.getJSONObject("odgovori");
                    JSONObject object= odgs.getJSONObject("arrayValue");
                    JSONArray array=object.getJSONArray("values");
                    ArrayList<String> arr= new ArrayList<>();
                    for(int j = 0; j < array.length(); j++)
                    {
                        JSONObject odg = array.getJSONObject(j);
                        String tekstOdg=odg.getString("stringValue");
                        arr.add(tekstOdg);
                        Log.e("odg", tekstOdg);
                    }
                    Pitanje p=new Pitanje(naziv,naziv,arr.get(index),arr);
                    if(!trenutnaPitanja.contains(p)) izBaze.add(p);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            mogucaPitanja.addAll(izBaze);
            Log.d("uProgramu", ""+mogucaPitanja.size());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            adapterMogucih.notifyDataSetChanged();
        }

        private String convertStreamToString(InputStream is) {
            BufferedReader reader = new BufferedReader(new
                    InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;
            try {
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
            } catch (IOException e) {
            } finally {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
            return sb.toString();
        }

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodavanje_kviza);
        ContentLoadingProgressBar bar=new ContentLoadingProgressBar(this);
        bar.show();
        if(new ProvjeraKonekcije().imaKonekcije(aktivnost,false)) new BazaZaPitanja().execute();
        //bar.hide();
        spinner = (Spinner) findViewById(R.id.spKategorije);
        naziv=(EditText) findViewById(R.id.etNaziv);
        trenutna=(ListView) findViewById(R.id.lvDodanaPitanja);
        moguca=(ListView) findViewById(R.id.lvMogucaPitanja);
        dugme = (Button) findViewById(R.id.btnDodajKviz);
        dugmeZaImport=findViewById(R.id.btnImportKviz);
        naziv.setHint("Naziv kviza - INPUT");
        Resources res = getResources();

        adapterMogucih = new ListaPitanjaAdapter(this, mogucaPitanja, res);
        adapterTrenutnih = new ListaPitanjaAdapter(this, trenutnaPitanja, res);

        elementiSpinera= (ArrayList<Kategorija>) getIntent().getSerializableExtra("spiner");
        aktivnost=this;
        boolean postoji=false;
        for (int i = 0; i <elementiSpinera.size() ; i++) {
            if(elementiSpinera.get(i).equals(Kategorija.dajPraznuKategoriju())) postoji=true;
        }
        if(!postoji) elementiSpinera.add(Kategorija.dajPraznuKategoriju());

        final int index= (int) getIntent().getIntExtra("pozicija",0);
        Kviz poslani = (Kviz) getIntent().getSerializableExtra("kviz");
        if(poslani.equals(Kviz.dajPrazan())) zaDodavanje=true;
        prisutniKvizovi= (ArrayList<Kviz>) getIntent().getSerializableExtra("kvizovi");
        stariNaziv=getIntent().getStringExtra("staro_ime");
        spinerAdapter=new SpinerAdapter(this,elementiSpinera,res);
        spinner.setAdapter(spinerAdapter);
        trenutna.setAdapter(adapterTrenutnih);
        moguca.setAdapter(adapterMogucih);
        if(!(new ProvjeraKonekcije().imaKonekcije(this,true))) dugme.setEnabled(false);
        if(poslani.equals(Kviz.dajPrazan())) spinner.setSelection(getIntent().getIntExtra("indexSpinera",0));
        else{
        for (int i = 0; i <elementiSpinera.size() ; i++) {
                if(elementiSpinera.get(i).equals(poslani.getKategorija())) spinner.setSelection(i);
        }}

        if(poslani.equals(Kviz.dajPrazan())){
            naziv.setText("");
            poslani = new Kviz();
            trenutnaPitanja.add(Pitanje.dajPraznoPitanje());
             adapterMogucih.notifyDataSetChanged();
            adapterTrenutnih.notifyDataSetChanged();
        }else{
            naziv.setText(poslani.getNaziv());
//            trenutnaPitanja=poslani.getPitanja();
            for (int i = 0; i <poslani.getPitanja().size() ; i++) {
                trenutnaPitanja.add(poslani.getPitanja().get(i));
            }
            trenutnaPitanja.add(Pitanje.dajPraznoPitanje());
            adapterTrenutnih.notifyDataSetChanged();
            adapterMogucih.notifyDataSetChanged();
        }

        trenutna.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!trenutnaPitanja.isEmpty()){
              if(trenutnaPitanja.get(position).equals(Pitanje.dajPraznoPitanje())){
                  Intent myIntent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                  DodajKvizAkt.this.startActivityForResult(myIntent,2);
                  finalPoslani.setPitanja(trenutnaPitanja);
              }else{
                  mogucaPitanja.add(trenutnaPitanja.get(position));
                  trenutnaPitanja.remove(position);
                  adapterTrenutnih.notifyDataSetChanged();
                  adapterMogucih.notifyDataSetChanged();
                  finalPoslani.setPitanja(trenutnaPitanja);
              }}
            }}
            );


        moguca.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if(!mogucaPitanja.isEmpty()){
            trenutnaPitanja.add(trenutnaPitanja.size()-1,mogucaPitanja.get(position));
            mogucaPitanja.remove(position);
            finalPoslani.setPitanja(trenutnaPitanja);
            adapterTrenutnih.notifyDataSetChanged();
            adapterMogucih.notifyDataSetChanged();}
        }});

        finalPoslani = poslani;
        naziv.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                naziv.setBackgroundColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            public void afterTextChanged(Editable s) {
                finalPoslani.setNaziv(String.valueOf(naziv.getText()));
            }
        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if(elementiSpinera.get(position).equals(Kategorija.dajPraznuKategoriju())){
                    Intent myIntent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    DodajKvizAkt.this.startActivityForResult(myIntent,3);
                }else if(elementiSpinera.get(position).equals(Kategorija.dajSveKategoriju())) {
                    finalPoslani.setKategorija(Kategorija.dajSveKategoriju());
                    spinner.setSelection(position);
                    spinerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                for (int i = 0; i <elementiSpinera.size() ; i++) {
                    if(elementiSpinera.get(i).equals(Kategorija.dajSveKategoriju()))
                        spinner.setSelection(i);
                }
                spinerAdapter.notifyDataSetChanged();
            }
        });

        dugme.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(new ProvjeraKonekcije().imaKonekcije(aktivnost,true)){
                    new PostojanjeKviza().execute(finalPoslani.getNaziv());}
            }
        });

        dugmeZaImport.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] mimeTypes = {"text/csv", "text/comma-separated-values", "text/plain"};
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                startActivityForResult(intent, 4);
            }
        });

    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 2) {
            if(resultCode == RESULT_OK){
               Pitanje p= (Pitanje) data.getSerializableExtra("pitanje");
                boolean postojiPitanje=false;
                for (int i = 0; i <trenutnaPitanja.size(); i++) {
                    if(trenutnaPitanja.get(i).getNaziv().equals(p.getNaziv())) postojiPitanje=true;
                }
                if(!postojiPitanje) trenutnaPitanja.add(trenutnaPitanja.size()-1,p);
               finalPoslani.setPitanja(trenutnaPitanja);
            adapterTrenutnih.notifyDataSetChanged();
        }}
        if(requestCode==3){
            if(resultCode==RESULT_OK){
                dodanaNovaKategorija=true;
            Kategorija k= (Kategorija) data.getSerializableExtra("kategorija");
            elementiSpinera.add(elementiSpinera.size()-1,k);
            finalPoslani.setKategorija(k);
            spinner.setSelection(elementiSpinera.size()-2);
            spinerAdapter.notifyDataSetChanged();
            }
        }
        if(requestCode==4){
            if (resultCode == RESULT_OK) {
                Uri uri = null;
                if (data != null) {
                    uri = data.getData();
                    try {
                        ucitajKviz(uri);
                    } catch (IOException e) {
                        dajAlert("Datoteka kviza kojeg importujete nema ispravan format!");
                                             e.printStackTrace();
                        return;
                    }
                }
            }
        }
    }
    private void ucitajKviz(Uri uri) throws IOException {
        
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        String line;
        ArrayList<String> redoviDatoteke=new ArrayList<>();
        while((line=reader.readLine())!=null) {
            System.out.print(line+"...\n");
            redoviDatoteke.add(line);
        }

        int brojPitanja;
        String nazivKategorije;
        ArrayList<Pitanje> pitanjaArrayList=new ArrayList<>();

            String[] kviz = redoviDatoteke.get(0).split(",");
            if(kviz.length!=3){
                // TODO: 16.4.2019. ako u prvom redu nisu samo 3 elementa???
               // return;
                dajAlert("Datoteka kviza kojeg importujete nema ispravan format!");
                return;
            }
            for (int i = 0; i <prisutniKvizovi.size() ; i++) {
                if(kviz[0].equals(prisutniKvizovi.get(i).getNaziv())){
                    dajAlert("Kviz kojeg " +
                        "importujete već postoji!");
                return;
                }
            }
            nazivKategorije=kviz[1];
            brojPitanja=Integer.parseInt(kviz[2].trim());
            if(brojPitanja!=redoviDatoteke.size()-1) {
                System.out.println(redoviDatoteke.size()+" br pitanja = "+brojPitanja);
                dajAlert("Kviz kojeg importujete ima neispravan broj pitanja!");
                return;
            }
            for(int i =1; i<redoviDatoteke.size();i++){
                ArrayList<String> odgovori=new ArrayList<>();
                String[] pitanje = redoviDatoteke.get(i).split(",");
                if(pitanje.length<3){
                    dajAlert("Datoteka kviza kojeg importujete nema ispravan format!");
                    return;
                }
                String nazivPitanja = pitanje[0];
                int brojOdgovora=Integer.parseInt(pitanje[1].trim());
                int indexTacnog=Integer.parseInt(pitanje[2].trim());
                if(brojOdgovora!=pitanje.length-3) {
                    dajAlert("Kviz kojeg importujete ima neispravan broj odgovora!");
                    return;
                }
                else if(indexTacnog<0 || indexTacnog>pitanje.length-3){
                    dajAlert("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
                    return;
                }else{
                    for (int j = 3; j <pitanje.length ; j++) {
                       if(!odgovori.contains(pitanje[j])) odgovori.add(pitanje[j]);
                       else{
                           dajAlert("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
                           return;
                       }
                    }
                    boolean postojiPitanje=false;
                    for (int j = 0; j < pitanjaArrayList.size() ; j++) {
                        if(pitanjaArrayList.get(j).getNaziv().equals(nazivPitanja)) postojiPitanje=true;
                    }
                    if(!postojiPitanje)pitanjaArrayList.add(new Pitanje(nazivPitanja,nazivPitanja,pitanje[3+indexTacnog],odgovori));
                    if(postojiPitanje){
                        dajAlert("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                        return;
                    }
                }}
            naziv.setText(kviz[0]);
            trenutnaPitanja.addAll(pitanjaArrayList);
            boolean postojiKategorija=false;
            for (int i = 0; i <elementiSpinera.size() ; i++) {
               if(elementiSpinera.get(i).getNaziv().equals(nazivKategorije)){
                   spinner.setSelection(i);
                   postojiKategorija=true;
               }
            }
            if(!postojiKategorija){
                elementiSpinera.add(elementiSpinera.size()-1,new Kategorija(nazivKategorije,"333", "333"));
                spinner.setSelection(elementiSpinera.size()-2);
            }
            spinerAdapter.notifyDataSetChanged();
            adapterTrenutnih.notifyDataSetChanged();

        trenutna.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
        moguca.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
    }

    private  void dajAlert(String s){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(s);
        builder1.setCancelable(true);
        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            elementiSpinera.remove(elementiSpinera.size() - 1);
            Intent myIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
            myIntent.putExtra("kategorije", elementiSpinera);
            myIntent.putExtra("nova",dodanaNovaKategorija);
            setResult(RESULT_CANCELED, myIntent);
            finish();
        }
        return super.onKeyDown(keyCode,event);
    }


    private class BazaZaKviz extends AsyncTask<Object,Void,Void>{
        @Override
        protected Void doInBackground(Object... objects) {
            mogucaPitanja.clear();
            GoogleCredential credentials;
            try {
                Kviz k=(Kviz)objects[0];

                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                Log.d("tokennn","++"+TOKEN);

                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/";
                url+="Kvizovi/"+k.getNaziv()+"/?access_token="+TOKEN;
                Log.d("tokenich", TOKEN);
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");

                String dokument ="{\"fields\": {\n" +
                        "        \"pitanja\": {\n" +
                        "          \"arrayValue\": {\n" +
                        "            \"values\": [";
                String pitanja="";
                for (int i = 0; i < k.getPitanja().size(); i++) {
                    pitanja+=  "{\"referenceValue\": \"projects/rma-radusicesmina94/databases/(default)/documents/Pitanja/"+k.getPitanja().get(i).getNaziv()+"\"}";
                    if(i<k.getPitanja().size()-1)pitanja+=",";
                }
                dokument+=pitanja;
                dokument+="]\n}},\"naziv\": {\n" +
                        "          \"stringValue\": \""+k.getNaziv()+"\"},\"idKategorije\": {\n" +
                        "          \"referenceValue\": \"projects/rma-radusicesmina94/databases/(default)/documents/Kategorije/"+k.getKategorija().getNaziv()+"\"}}}";

                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                Log.e("kvizich", conn.getResponseCode() + ": " +conn.getResponseMessage());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("izuzetak","krah");
            }
            return null;
        }
    }
    private  class BrisanjeStarogKviza extends AsyncTask<Object,Void,Void>{

        @Override
        protected Void doInBackground(Object... objects) {
            try{
            GoogleCredential credentials;
            InputStream is = getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.d("tokennn","++"+TOKEN);
            String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/";
            url+="Kvizovi/"+(String) objects[0]+"/?access_token="+TOKEN;
            Log.d("tokenich", TOKEN);
            URL urlObj=new URL(url);
            HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty("Content-type","application/json");
            Log.e("BRISANJEkvizich", conn.getResponseCode() + ": " +conn.getResponseMessage());
            }  catch (IOException e) {
            e.printStackTrace();
        }
            return null;
        }
    }

    @Override
    protected void onResume() {
        mogucaPitanja.clear();
        if(new ProvjeraKonekcije().imaKonekcije(aktivnost,false)) new BazaZaPitanja().execute();
        super.onResume();
    }

    private class PostojanjeKviza extends AsyncTask<Object,Void,Void>{

        @Override
        protected Void doInBackground(Object... objects) {
            GoogleCredential credentials;
            String TOKEN = "";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                TOKEN = credentials.getAccessToken();
                String query="{\"structuredQuery\":{\"where\":{\"fieldFilter\":{\"field\":{\"fieldPath\":\"naziv\"},\"op\":\"EQUAL\"," +
                        "\"value\":{\"stringValue\":\""+(String)objects[0]+"\"}}}," +
                        "\"select\":{\"fields\":[{\"fieldPath\":\"naziv\"}]}," +
                        "\"from\":[{\"collectionId\":\"Kvizovi\"}],\"limit\":1000}}";
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents:runQuery?access_token="+ TOKEN;
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");
                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                InputStream odgovor=conn.getInputStream();
                String rezultat="";
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor,"utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine())!=null){
                        response.append(responseLine.trim());
                    }
                    rezultat =  "{ \"documents\": " + response.toString() + "}";
                    JSONObject object = new JSONObject(rezultat);
                    JSONArray niz=object.getJSONArray("documents");
                    for (int i =0;i<niz.length();i++){
                        if(niz.getJSONObject(i).has("document")) { postojiUBazi=true; break;}
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            Log.d("rez bool", "doInBackground: "+postojiUBazi);
            return  null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if(finalPoslani.getNaziv().isEmpty()){
                naziv.setBackgroundColor(Color.parseColor("#f4b2ae"));
            }else if(postojiUBazi && zaDodavanje){
                dajAlert("Uneseni kviz vec postoji!");
                postojiUBazi=false;
            }
            else{
                finalPoslani.setKategorija(elementiSpinera.get(spinner.getSelectedItemPosition()));
                for (int i = 0; i < trenutnaPitanja.size(); i++) {
                    if(trenutnaPitanja.get(i).equals(Pitanje.dajPraznoPitanje())) trenutnaPitanja.remove(i);
                }                    finalPoslani.setPitanja(trenutnaPitanja);
                elementiSpinera.remove(elementiSpinera.size()-1);
                if(finalPoslani.getKategorija().equals(Kategorija.dajPraznuKategoriju())) finalPoslani.setKategorija(Kategorija.dajSveKategoriju());
                if(!finalPoslani.getNaziv().equals(stariNaziv) && !stariNaziv.equals("Dodaj kviz"))  new BrisanjeStarogKviza().execute(stariNaziv);
                new BazaZaKviz().execute(finalPoslani, stariNaziv);
                Intent myIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                myIntent.putExtra("pozicija",index);
                myIntent.putExtra("kviz",finalPoslani);
                myIntent.putExtra("kategorije",elementiSpinera);
                myIntent.putExtra("staro_ime",stariNaziv);
                setResult(1);
                setResult(RESULT_OK,myIntent);
                finish();
            }
        }
    }

}
