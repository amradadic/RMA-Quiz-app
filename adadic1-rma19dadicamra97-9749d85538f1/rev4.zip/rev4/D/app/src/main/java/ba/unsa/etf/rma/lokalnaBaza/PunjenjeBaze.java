package ba.unsa.etf.rma.lokalnaBaza;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;

public class PunjenjeBaze {
    Context context;
    private SQLiteDatabase baza;
    private SQLiteDatabase zaCitanje;
    public PunjenjeBaze(Context context) {
        this.context=context;
    baza=new KvizoviDBOpenHelper(context,null,null,KvizoviDBOpenHelper.DATABASE_VERSION).getWritableDatabase();
            zaCitanje=new KvizoviDBOpenHelper(context,null,null,KvizoviDBOpenHelper.DATABASE_VERSION).getReadableDatabase();
    }


    public void napuniKvizove(ArrayList<Kviz> kvizovi) {
        isprazniTabele();
        for (int i = 0; i <kvizovi.size() ; i++) {
            ContentValues kviz=new ContentValues();
            kviz.put("naziv",kvizovi.get(i).getNaziv());
            kviz.put("kategorija",kvizovi.get(i).getKategorija().getNaziv());
            if(!postojiKviz(kvizovi.get(i).getNaziv()))baza.insert("Kvizovi",null,kviz);
            for(int j=0;j<kvizovi.get(i).getPitanja().size();j++){
                ContentValues pitanje=new ContentValues();
                pitanje.put("naziv",kvizovi.get(i).getPitanja().get(j).getNaziv());
                pitanje.put("tekstTacnog", kvizovi.get(i).getPitanja().get(j).getTacan());
               if(!postojiPitanje(kvizovi.get(i).getPitanja().get(j).getNaziv())) baza.insert("Pitanja",null,pitanje);
                ContentValues posrednik = new ContentValues();
                posrednik.put("nazivKviza", kvizovi.get(i).getNaziv());
                posrednik.put("nazivPitanja",kvizovi.get(i).getPitanja().get(j).getNaziv());
                baza.insert("Kviz_Pitanje",null,posrednik);
                for(int k=0;k<kvizovi.get(i).getPitanja().get(j).getOdgovori().size();k++){
                    ContentValues odgovor = new ContentValues();
                    odgovor.put("tekst", kvizovi.get(i).getPitanja().get(j).getOdgovori().get(k));
                    odgovor.put("tekstPitanja",kvizovi.get(i).getPitanja().get(j).getNaziv());
                    baza.insert("Odgovori",null,odgovor);
                }
            }
        }
        baza.close();
        zaCitanje.close();
    }

    public void napuniKategorije(ArrayList<Kategorija> kategorije) {
isprazniKategorije();
        for (int i = 0; i <kategorije.size() ; i++) {
            ContentValues kategorija=new ContentValues();
            kategorija.put("naziv",kategorije.get(i).getNaziv());
            kategorija.put("idIkonice",kategorije.get(i).getIkona());
            if(!postojiKategorija(kategorije.get(i).getNaziv()))baza.insert("Kategorije",null,kategorija);
        }
        baza.close();
        zaCitanje.close();
    }

    public void isprazniTabele() {
        baza.delete("Kvizovi",null,null);
        baza.delete("Pitanja",null,null);
        baza.delete("Odgovori",null,null);
        baza.delete("Kviz_Pitanje",null,null);
    }
    public void isprazniKategorije(){
        baza.delete("Kategorije",null,null);
    }

    private boolean postojiKviz(String naziv){
        Cursor cursor=zaCitanje.query("Kvizovi",null,"naziv='"+naziv+"'",null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))) return true;
     return false;
    }
    private boolean postojiKategorija(String naziv){
        Cursor cursor=zaCitanje.query("Kategorije",null,"naziv='"+naziv+"'",null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))) return true;
        return false;
    }
    private boolean postojiPitanje(String naziv){
        Cursor cursor=zaCitanje.query("Pitanja",null,"naziv='"+naziv+"'",null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))) return true;
        return false;
    }
}
