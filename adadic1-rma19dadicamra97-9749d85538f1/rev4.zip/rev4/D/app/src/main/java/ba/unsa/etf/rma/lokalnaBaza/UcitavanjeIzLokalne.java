package ba.unsa.etf.rma.lokalnaBaza;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class UcitavanjeIzLokalne {
    SQLiteDatabase baza;

    public UcitavanjeIzLokalne(SQLiteDatabase baza) {
        this.baza = baza;
    }

    public void ucitajKvizove(ArrayList<Kviz> kvizovi){
        kvizovi.clear();
        String[] kolone = {"naziv", "kategorija"};
        Cursor cursor = baza.query("Kvizovi",kolone,null,null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))){
            cursor.moveToFirst();
            while (!cursor.isAfterLast()){
                Log.d("lokalna", "ucitajKvizove: kviz");
                String naziv = cursor.getString(0);
                String kat = cursor.getString(1);
                ArrayList<Pitanje> pitanja=ucitajPitanjaKviza(naziv);
                Kategorija kategorija=ucitajKategorijuKviza(kat);
                cursor.moveToNext();
            }
        }
        cursor.close();
    }

    private Kategorija ucitajKategorijuKviza(String naziv) {
        Kategorija k=new Kategorija();
        String[] kolone = {"idIkonice"};
        int id=0;
        Cursor cursor= baza.query("Kategorije", kolone," naziv='"+naziv+"'",null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))){
            Log.d("lokalna", "ucitajKategorijuKviza: kat za kviz");
            cursor.moveToFirst();
             id= cursor.getInt(0);
        }
        k.setId(""+id);k.setIkona(""+id);k.setNaziv(naziv);
        cursor.close();
        return k;
    }

    private ArrayList<Pitanje> ucitajPitanjaKviza(String naziv) {
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        String[] kolona = {"nazivPitanja"};
        ArrayList<String> naziviPitanja=new ArrayList<>();
        Cursor cursor = baza.query("Kviz_Pitanje", kolona," nazivKviza='"+naziv+"'",null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))){
            cursor.moveToFirst();
            Log.d("lokalna", "ucitajPitanjaKviza: pitanja");
            while (!cursor.isAfterLast()){
                String pit=cursor.getString(0);
                naziviPitanja.add(pit);
                cursor.moveToNext();
            }
        }
        cursor.close();
        String[] kolone = {"tekstTacnog"};

        for (int i = 0; i <naziviPitanja.size() ; i++) {
            String tacan=null;

            Cursor c = baza.query("Pitanja", kolone," naziv='"+naziv+"'",null,null,null,null);
            if(((c != null) && (c.getCount() > 0))){
                c.moveToFirst();
                Log.d("lokalna", "ucitajPitanjaKviza: tacni odgovori");
                tacan= c.getString(0);
            }
            ArrayList<String> odgs=ucitajOdgovoreNaPitanje(naziviPitanja.get(i));
            pitanja.add(new Pitanje(naziviPitanja.get(i),naziviPitanja.get(i),tacan,odgs));
            if(i==naziviPitanja.size()-1) c.close();
        }
        return pitanja;
    }

    private ArrayList<String> ucitajOdgovoreNaPitanje(String s) {
        ArrayList<String> odgovori=new ArrayList<>();
        String[] kolona = {"tekst"};
        Cursor cursor = baza.query("Odgovori", kolona," tekstPitanja='"+s+"'",null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))){
            cursor.moveToFirst();
            Log.d("lokalna", "ucitajOdgovoreNaPitanje: odgovori");
            while (!cursor.isAfterLast()){
                String odg=cursor.getString(0);
                odgovori.add(odg);
                cursor.moveToNext();
            }
        }
        cursor.close();
        return odgovori;
    }

    public void  ucitajKategorije(ArrayList<Kategorija> kategorije){
        kategorije.clear();
        Log.d("lokalna", "ucitajKategorije: sve kat");

        String[] kolone = {"naziv","idIkonice"};
        Cursor cursor= baza.query("Kategorije", kolone,null,null,null,null,null);
        if(((cursor != null) && (cursor.getCount() > 0))){
            cursor.moveToFirst();
            Log.d("lokalna", "ucitajKategorije: sve kat");
            while (!cursor.isAfterLast()){
                int id= cursor.getInt(1);
            String naziv = cursor.getString(0);
            Kategorija k = new Kategorija(naziv,id+"",id+"");
            if(!naziv.equals(Kategorija.dajSveKategoriju().getNaziv()))kategorije.add(k);
                cursor.moveToNext();
            }
        }
        cursor.close();
    }
}
