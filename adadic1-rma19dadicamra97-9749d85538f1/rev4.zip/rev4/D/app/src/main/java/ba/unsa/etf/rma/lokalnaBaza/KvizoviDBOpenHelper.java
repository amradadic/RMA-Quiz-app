package ba.unsa.etf.rma.lokalnaBaza;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class KvizoviDBOpenHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "kvizoviBazaNova.db";
    public static final int DATABASE_VERSION = 2;


    private static final String TABLE_KATEGORIJE = "CREATE TABLE Kategorije (\n" +
            "kat_id integer primary key autoincrement,\n" +
            "\t naziv TEXT,\n" +
            "\t idIkonice INTEGER\n" +
            ");";

    private static final String TABLE_PITANJA = "CREATE TABLE Pitanja (\n" +
            "\t pitanje_id integer primary key autoincrement ,\n" +
            "\t naziv \tTEXT,\n" +
            "\t tekstTacnog \t text \n" +
            ");";

    private static final String TABLE_ODGOVORI ="CREATE TABLE Odgovori (\n" +
            "\t tekstPitanja \t text,\n" +
            "\t tekst \tTEXT,\n" +
            "\t odgovor_id \t integer primary key autoincrement\n" +
            ");" ;

    private static final String TABLE_KVIZOVI = "CREATE TABLE Kvizovi (\n" +
            "\t kviz_id  \t integer primary key autoincrement,\n" +
            "\t naziv \t text,\n" +
            "\t kategorija \ttext\n" +
            ");";

    private static final String TABLE_POSREDNICKA ="CREATE TABLE Kviz_Pitanje (\n" +
            "\t nazivKviza \t text,\n" +
            "\t nazivPitanja \t text ,\n" +
            "\t veza_id integer primary key autoincrement \n" +
            ");" ;

    public KvizoviDBOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_KVIZOVI);
        db.execSQL(TABLE_KATEGORIJE);
        db.execSQL(TABLE_PITANJA);
        db.execSQL(TABLE_ODGOVORI);
        db.execSQL(TABLE_POSREDNICKA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        switch (oldVersion){
        case 1:
        db.execSQL("DROP TABLE IF EXISTS Kvizovi"+ TABLE_KVIZOVI);
        db.execSQL("DROP TABLE IF EXISTS Pitanja"+ TABLE_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS Odgovori"+ TABLE_ODGOVORI);
        db.execSQL("DROP TABLE IF EXISTS Kategorije"+ TABLE_KATEGORIJE);
        db.execSQL("DROP TABLE IF EXISTS Kviz_Pitanje"+ TABLE_POSREDNICKA);
            case 2:
                db.execSQL("DROP TABLE IF EXISTS Kvizovi"+ TABLE_KVIZOVI);
                db.execSQL("DROP TABLE IF EXISTS Pitanja"+ TABLE_PITANJA);
                db.execSQL("DROP TABLE IF EXISTS Odgovori"+ TABLE_ODGOVORI);
                db.execSQL("DROP TABLE IF EXISTS Kategorije"+ TABLE_KATEGORIJE);
                db.execSQL("DROP TABLE IF EXISTS Kviz_Pitanje"+ TABLE_POSREDNICKA);
        }
// Kreiranje nove
        onCreate(db);
    }
}
