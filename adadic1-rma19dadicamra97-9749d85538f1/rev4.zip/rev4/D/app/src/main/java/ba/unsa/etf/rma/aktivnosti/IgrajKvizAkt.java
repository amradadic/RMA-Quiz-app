package ba.unsa.etf.rma.aktivnosti;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.util.Pair;
import android.widget.EditText;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;


import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangListaFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick {
    private Kviz k;
    int br=0, max;
    Activity activity =null;
    private String ime;
    private double procenat;
    private int brojTacnih=0;
    private AlarmClock alarm = new AlarmClock();
    ArrayList<Pitanje> izmijesanaPitanja=new ArrayList<>();
    private ArrayList<Pair<String,Double>> korisnici= new ArrayList<>();
    private FragmentTransaction ft2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.igranje_kviza);
        activity=this;
        k= (Kviz) getIntent().getSerializableExtra("kviz");
        max=k.getPitanja().size();
        izmijesanaPitanja.addAll(k.getPitanja());
        Collections.shuffle(izmijesanaPitanja);

        if(max!=0) {
            Calendar calendar= new GregorianCalendar();
            calendar.setTimeInMillis(System.currentTimeMillis());
            int seconds=calendar.get(Calendar.SECOND);
            if(seconds!=0) calendar.add(Calendar.SECOND, 60-seconds);
            calendar.add(Calendar.MINUTE,max/2);
            if(max%2!=0) calendar.add(Calendar.MINUTE,1);


            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
            intent.putExtra(AlarmClock.EXTRA_MINUTES, calendar.get(Calendar.MINUTE));
            intent.putExtra(AlarmClock.EXTRA_HOUR, calendar.get(Calendar.HOUR_OF_DAY));
            intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Pozuri, odgovori na sva pitanja! \uD83D\uDE42");
            startActivity(intent);
        }
        InformacijeFrag informacijeFrag=new InformacijeFrag();
        PitanjeFrag pitanjeFrag = new PitanjeFrag();
        new UcitavanjeRangListe().execute(k.getNaziv());

        Bundle argumentiP= new Bundle();
        if(br<max) {
            argumentiP.putSerializable("pitanje", izmijesanaPitanja.get(br));
        }else{
            argumentiP.putSerializable("pitanje", new Pitanje("Kviz je završen!","Kviz je završen!","", new ArrayList<String>()));
        }
        pitanjeFrag.setArguments(argumentiP);

        Bundle argumentiInfo= new Bundle();
        argumentiInfo.putSerializable("kviz", k);
        argumentiInfo.putString("procenat", "0");
        argumentiInfo.putString("brTacnih", "0");
       if(k.getPitanja().size()!=0) argumentiInfo.putString("preostalo", ""+(k.getPitanja().size()-1));
        else argumentiInfo.putString("preostalo", ""+k.getPitanja().size());
        informacijeFrag.setArguments(argumentiInfo);

        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.informacijePlace,informacijeFrag);
        FragmentManager fm2=getSupportFragmentManager();
        FragmentTransaction ft2 = fm2.beginTransaction();
        ft2.replace(R.id.pitanjePlace, pitanjeFrag);

        ft.commit();
        ft2.commit();
    }

    @Override
    public void onItemClicked(int pos,boolean tacan) {
        int delay =2000;// in ms
        if(tacan) brojTacnih++;
        br++;
         procenat=(double)brojTacnih/br;
         procenat*=100;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               try{
                   PitanjeFrag novi=new PitanjeFrag();
                Bundle argumentiP= new Bundle();
                if(br<max) {
                    argumentiP.putSerializable("pitanje",izmijesanaPitanja.get(br));
                }else{
                    argumentiP.putSerializable("pitanje", new Pitanje("Kviz je završen!","Kviz je završen!","", new ArrayList<String>()));
                }
                novi.setArguments(argumentiP);
                FragmentManager fm2=getSupportFragmentManager();
                ft2 = fm2.beginTransaction();
                if(br<max){
                    ft2.replace(R.id.pitanjePlace, novi);
                    ft2.commit();
                }
                else{
//                    Intent i=new Intent(AlarmClock.ACTION_DISMISS_ALARM);
//                    i.putExtra(AlarmClock.EXTRA_SKIP_UI,true);
//                    startActivity(i);

                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                    alertDialog.setTitle("Rang lista");
                    alertDialog.setMessage("Unesite ime:");
                    alertDialog.setIcon(R.drawable.alert_icon);
                    final EditText input = new EditText(activity);
                    input.setInputType(InputType.TYPE_CLASS_TEXT);
                    alertDialog.setView(input);
                    alertDialog.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    ime=input.getText().toString();
                                    Pair<String,Double> igrac= new Pair<>(ime,procenat);
                                    korisnici.add(igrac);
                                    SortirajRangListu();
//                                    if(postojaoRangRanije)
                                        new BrisanjeRanga().execute(k.getNaziv());
                                    new UpisivanjeRanga().execute();
                                    RangListaFrag rang= new RangListaFrag();
                                    Bundle arugmentiRang=new Bundle();
                                    arugmentiRang.putSerializable("korisnici",(Serializable)korisnici);
                                    rang.setArguments(arugmentiRang);
                                    ft2.replace(R.id.pitanjePlace,rang);
                                    ft2.commit();
                                }
                            });
                   alertDialog.create().show();

                }
                InformacijeFrag noveInfo=new InformacijeFrag();
                Bundle argumentiInfo= new Bundle();
                argumentiInfo.putSerializable("kviz", k);
                argumentiInfo.putString("procenat", ""+String.format("%.2f", procenat));
                argumentiInfo.putString("brTacnih", ""+brojTacnih);
                if(k.getPitanja().size()-br>=1) argumentiInfo.putString("preostalo", ""+(k.getPitanja().size()-br-1));
                else argumentiInfo.putString("preostalo", ""+(k.getPitanja().size()-br));
                noveInfo.setArguments(argumentiInfo);
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.informacijePlace, noveInfo);

                ft.commit();
            }catch(Exception e){
                finish();
            }}
        }, delay);
    }
    private class UcitavanjeRangListe extends AsyncTask<Object,Void,Void> {
        @Override
        protected Void doInBackground(Object... objects) {
            Log.d("rang", "doInBackground: UCITAVANJE LISTE RANG");
            GoogleCredential credentials;
            String url1 = "https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/Rangliste/"+(String)objects[0]+"/?access_token=";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                URL url = new URL(url1+TOKEN);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in;
                try {
                     in = new BufferedInputStream(urlConnection.getInputStream());
                }catch (Exception e){
                    return  null;
                }
                String rezultat = convertStreamToString(in);
                    JSONObject object = new JSONObject(rezultat);
                        JSONObject polja = object.getJSONObject("fields");
                        JSONObject lista = polja.getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
                        int br=0;
                        while (true) {
                            if(!lista.has("" + (br + 1))) break;
                            JSONObject pozicija = lista.getJSONObject("" + (br + 1));
                            JSONObject poz= pozicija.getJSONObject("mapValue").getJSONObject("fields");
                            br++;
                            String element = poz.toString();
                            String[] dijelovi = element.split("\"");
                            String ime = dijelovi[1];
                            Double procenat = Double.parseDouble(dijelovi[dijelovi.length-1].replace("}"," ").replace(":"," ").trim());
                            Pair<String, Double> par = new Pair<>(ime, procenat);
                            korisnici.add(par);
                        }
                    } catch (IOException e2) {
                e2.printStackTrace();
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
                return null;
        }

        private String convertStreamToString(InputStream is) {
            BufferedReader reader = new BufferedReader(new
                    InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;
            try {
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
            } catch (IOException e) {
            } finally {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
            return sb.toString();
        }
    }

    private void SortirajRangListu(){
        Collections.sort(korisnici, new Comparator<Pair<String, Double>>() {
            @Override
            public int compare(Pair<String, Double> prvi, Pair<String, Double> drugi) {
                if (prvi.second > drugi.second) {
                    return -1;
                } else if (prvi.second < drugi.second){
                    return 1;
                } else {
                    return 0;
                }
            }
        });
    }
    private class BrisanjeRanga extends AsyncTask<Object,Void,Void> {

        @Override
        protected Void doInBackground(Object... objects) {
            try{
                GoogleCredential credentials;
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                Log.d("rang","usao u brisanje ranga");
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/";
                url+="Rangliste/"+(String) objects[0]+"/?access_token="+TOKEN;
                Log.d("tokenich", TOKEN);
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Content-type","application/json");
                Log.e("BRISANJErangich", conn.getResponseCode() + ": " +conn.getResponseMessage());
            }  catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
private class UpisivanjeRanga extends  AsyncTask<Object,Void,Void>{

    @Override
    protected Void doInBackground(Object... objects) {
       try{
           Log.e("rang", "doInBackground: UPISIVANJE RANGA");
           GoogleCredential credentials;
        InputStream is = getResources().openRawResource(R.raw.secret);
        credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
        credentials.refreshToken();
        String TOKEN = credentials.getAccessToken();
        Log.d("tokennn","++"+TOKEN);

        String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/";
        url+="Rangliste/"+k.getNaziv() + "/?access_token="+TOKEN;
        Log.d("rang", "ok kokenkcija"+TOKEN);
        URL urlObj=new URL(url);
        HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("PATCH");
        conn.setRequestProperty("Content-type","application/json");
        conn.setRequestProperty("Accept","application/json");

           StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                   "{ \"nazivKviza\": { \"stringValue\": \"" + k.getNaziv() + "\"}, " +
                   " \"lista\" : { \"mapValue\" : { \"fields\" : { ");
           int pozicija = 1;

           for (int i = 0; i < korisnici.size(); i++) {
               dokuemntBilder.append(" \"" + pozicija + "\" : { \"mapValue\" : { \"fields\" : { " +
                       " \"" + korisnici.get(i).first + "\" : { \"doubleValue\" : \"" + korisnici.get(i).second+ "\"}}}}");

               if (i != korisnici.size() - 1)
                   dokuemntBilder.append(", ");

               pozicija++;
           }
           dokuemntBilder.append(" }}}}}");


           String dokument = dokuemntBilder.toString();
           try (OutputStream os=conn.getOutputStream()){
               byte[] input = dokument.getBytes("utf-8");
               os.write(input, 0, input.length);

               int codde = conn.getResponseCode();
           }
           Log.d("rang", "ok upit");

       } catch (IOException e) {
        e.printStackTrace();
        Log.e("izuzetakRang","izuzetak kod upsia ranga");
    }
        return null;
    }
}

}
