package ba.unsa.etf.rma.klase;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Pitanje implements Serializable {
    String naziv="", tekstPitanja="", tacan="";
    ArrayList<String> odgovori=new ArrayList<>();

    public Pitanje(String naziv, String tekstPitanja, String tacan, ArrayList<String> odgovori) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.tacan = tacan;
        this.odgovori = odgovori;
    }

    public Pitanje() {

    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public ArrayList<String> dajRandomOdgovore(){
        ArrayList<String> izmijesani = new ArrayList<>();
        izmijesani.addAll(odgovori);
        Collections.shuffle(izmijesani);
        return izmijesani;
    }

    public static Pitanje dajPraznoPitanje(){
        return new Pitanje("Dodaj pitanje","","", new ArrayList<String>());
    }

    @Override
    public boolean equals(Object obj) {
        return ((Pitanje)obj).getNaziv().equals(naziv);
    }
}
