package ba.unsa.etf.rma.fragmenti;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjeFrag extends Fragment {
    private ArrayList<String> odgovori=new ArrayList<>();
    private ListView odgovoriList;
    private TextView pitanjeView;
//private OnItemClick oic;
    public void setPitanje(Pitanje pitanje) {
        this.pitanje = pitanje;
    }

    private OnItemClick oic;
    private Pitanje pitanje;
    private int indexTacnog;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View v= inflater.inflate(R.layout.pitanja_fragment, container, false);
       pitanje= (Pitanje) getArguments().getSerializable("pitanje");
       odgovoriList=v.findViewById(R.id.odgovoriPitanja);
       ArrayList<String> odgs=pitanje.dajRandomOdgovore();
       odgovori.addAll(odgs);
       pitanjeView=v.findViewById(R.id.tekstPitanja);
        for (int i = 0; i <odgovori.size() ; i++) {
            if(odgovori.get(i).equals(pitanje.getTacan())) indexTacnog=i;
        }
       return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final ArrayAdapter<String> adapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,odgovori);
        odgovoriList.setAdapter(adapter);
        pitanjeView.setText(pitanje.getNaziv());
        final boolean[] tacno = new boolean[1];
        odgovoriList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                oic = (OnItemClick)getActivity();
                if(odgovori.get(position).equals(pitanje.getTacan())) {
                    arg1.setBackgroundColor(getResources().getColor(R.color.zelena));
                   tacno[0] =true;
                }
                else {
                    tacno[0] =false;
                    arg1.setBackgroundColor(getResources().getColor(R.color.crvena));
                    odgovoriList.getChildAt(indexTacnog).setBackgroundColor(getResources().getColor(R.color.zelena));
                };
                adapter.notifyDataSetChanged();
                oic.onItemClicked(position, tacno[0]);
            }
        });
    }

    public interface OnItemClick {
        public void onItemClicked(int pos,boolean tacno);
    }

}
