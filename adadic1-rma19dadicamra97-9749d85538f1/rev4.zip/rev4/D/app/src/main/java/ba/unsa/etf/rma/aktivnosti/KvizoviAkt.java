package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.ListaKvizovaAdapter;
import ba.unsa.etf.rma.ProvjeraKalendara;
import ba.unsa.etf.rma.ProvjeraKonekcije;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.SpinerAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.lokalnaBaza.KvizoviDBOpenHelper;
import ba.unsa.etf.rma.lokalnaBaza.PunjenjeBaze;
import ba.unsa.etf.rma.lokalnaBaza.UcitavanjeIzLokalne;

interface AsyncTaskListener{

    void updateResult();

}

public class KvizoviAkt extends AppCompatActivity implements  AsyncTaskListener{
    private Context aktivnost;
    private Spinner kategorije;
    private ArrayList<Kviz> kvizovi;
    private ListaKvizovaAdapter adapter;
    private ArrayList<Kategorija> kat;
    private SpinerAdapter adapterSpinera;
    private ArrayList<Kviz> odabrani;
    private SQLiteDatabase dbZaUpis;
    private SQLiteDatabase dbZaCitanje;
    ListView lista;

    @Override
    public void updateResult() {
//        kvizovi.add(Kviz.dajPrazan());
        if(odabrani.contains(Kviz.dajPrazan())){
            odabrani.remove(odabrani.indexOf(Kviz.dajPrazan()));
        }
        odabrani.add(Kviz.dajPrazan());
        adapter=new ListaKvizovaAdapter(this,odabrani,getResources());
        lista.setAdapter(adapter);
        new PunjenjeBaze(aktivnost).napuniKvizove(kvizovi);


    }

    public  class UcitavanjeKategorija extends AsyncTask<Object,Void,Void> {

        @Override
        protected Void doInBackground(Object... objects) {
            kat.clear();
            GoogleCredential credentials;
            String url1 = "https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/Kategorije/?access_token=";
            ArrayList<Kategorija> kategorijeIzBaze= new ArrayList<>();
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                try{
                    credentials.refreshToken();
                }catch(Exception e){
                    System.out.println(e.getMessage());
                }
                String TOKEN = credentials.getAccessToken();
                URL url = new URL(url1+TOKEN);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);

                JSONObject jo = new JSONObject(rezultat);

                JSONArray items = jo.getJSONArray("documents");
                for (int i = 0; i < items.length(); i++) {
                    JSONObject kategorija = items.getJSONObject(i);
                    JSONObject polja = kategorija.getJSONObject("fields");
                    JSONObject ime = polja.getJSONObject("naziv");
                    String naziv = ime.getString("stringValue");
                    JSONObject ikonica = polja.getJSONObject("idIkonice");
                    int idIkone = ikonica.getInt("integerValue");

                    Kategorija k=new Kategorija(naziv,""+idIkone,""+idIkone);
                    kategorijeIzBaze.add(k);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
           kat.addAll(kategorijeIzBaze);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            kat.add(0,Kategorija.dajSveKategoriju());
            adapterSpinera.notifyDataSetChanged();
            new PunjenjeBaze(aktivnost).napuniKategorije(kat);
        }
    }

    private class UcitavanjeKvizova extends AsyncTask<Object,Void,Void>{
        private ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            dialog.setMessage("Ucitavanje sadrzaja u toku.");
            dialog.show();
        }

        private AsyncTaskListener listener;

        public UcitavanjeKvizova(Context context)
        {
            listener= (AsyncTaskListener)context;    // Typecast
            dialog = new ProgressDialog(context);

        }

        @Override
        protected Void doInBackground(Object... objects) {
            odabrani.clear();
            kvizovi.clear();
           if(((Kategorija)objects[0]).getNaziv().trim().equals("Svi")){
               ucitajSveKvizove();
           }else{
               ucitajKvizovePoKategoriji((Kategorija)objects[0]);
           }
            return null;
        }

        private void ucitajKvizovePoKategoriji(Kategorija kategorija) {
            GoogleCredential credentials;
            String TOKEN = "";
            String nazivKviza="";
            ArrayList<Pitanje> pitanja=new ArrayList<>();
            ArrayList<Kviz> kvizoviIzBaze=new ArrayList<>();
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                TOKEN = credentials.getAccessToken();
                String query="{\"structuredQuery\":{\"where\":{\"fieldFilter\":{\"field\":{\"fieldPath\":\"idKategorije\"},\"op\":\"EQUAL\"," +
                        "\"value\":{\"stringValue\":\""+"projects/rma-radusicesmina94/databases/(default)/documents/Kategorije/"+kategorija.getNaziv()+"\"}}}," +
                        "\"select\":{\"fields\":[{\"fieldPath\":\"pitanja\"},{\"fieldPath\":\"naziv\"}]}," +
                        "\"from\":[{\"collectionId\":\"Kvizovi\"}],\"limit\":1000}}";
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents:runQuery?access_token="+ URLEncoder.encode(TOKEN, "UTF-8");
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");
                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                InputStream odgovor=conn.getInputStream();
                String rezultat="";
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor,"utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine())!=null){
                        response.append(responseLine.trim());
                    }
                    rezultat =  "{ \"documents\": " + response.toString() + "}";
                    Log.d("kveri", "ucitajKvizovePoKategoriji: "+rezultat);
                    JSONObject object = new JSONObject(rezultat);
                    JSONArray niz=object.getJSONArray("documents");
                    for (int i =0;i<niz.length();i++){
                        Log.e("KOLIKO KVIZOVA", "ucitajKvizovePoKategoriji: "+niz.length() );
                        JSONObject p=niz.getJSONObject(i);
                        if(!p.has("document")) break;
                        JSONObject doc=p.getJSONObject("document");
                        JSONObject fields=doc.getJSONObject("fields");
                        JSONObject naziv=fields.getJSONObject("naziv");
                        nazivKviza=naziv.getString("stringValue");
                        JSONObject object1=fields.getJSONObject("pitanja");
                        JSONObject object2=object1.getJSONObject("arrayValue");
                        if(object2.length()!=0) {
                            JSONArray niz2 = object2.getJSONArray("values");
                            for (int j = 0; j < niz2.length(); j++) {
                                JSONObject pit= niz2.getJSONObject(j);
                                String nazivPitanja = pit.getString("referenceValue");
                                nazivPitanja = nazivPitanja.substring(67);
                                pitanja.add(ucitajPitanje(nazivPitanja));
                            }}
                        Kviz k = new Kviz(nazivKviza, kategorija, pitanja);
                        kvizoviIzBaze.add(k);
                    }
                    odabrani.addAll(kvizoviIzBaze);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            listener.updateResult();
            if(dialog.isShowing()) dialog.dismiss();
        }

        private void ucitajSveKvizove() {
            GoogleCredential credentials;
            String url1 = "https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/Kvizovi/?access_token=";
            ArrayList<Kviz> kvizoviIzBaze= new ArrayList<>();
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                URL url = new URL(url1+TOKEN);
                Log.e("neww", "ucitajSveKvizove: +"+TOKEN);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);

                JSONObject jo = new JSONObject(rezultat);
                JSONArray items = jo.getJSONArray("documents");
                for (int i = 0; i < items.length(); i++) {
                    JSONObject kvv = items.getJSONObject(i);
                    JSONObject polja = kvv.getJSONObject("fields");
                    JSONObject ime = polja.getJSONObject("naziv");
                    String naziv = ime.getString("stringValue");
                    JSONObject katt = polja.getJSONObject("idKategorije");
                    String nazivKategorije = katt.getString("referenceValue");
                    nazivKategorije=nazivKategorije.substring(70);
                    Kategorija kat;
                    if(nazivKategorije.equals("Svi")) kat=Kategorija.dajSveKategoriju();
                    else kat=ucitajKategoriju(nazivKategorije);
                    ArrayList<Pitanje> pitanja=new ArrayList<>();
                    JSONObject object=polja.getJSONObject("pitanja");
                    JSONObject object1=object.getJSONObject("arrayValue");
                    if(object1.length()!=0) {
                        JSONArray niz = object1.getJSONArray("values");
                        for (int j = 0; j < niz.length(); j++) {
                            JSONObject p = niz.getJSONObject(j);
                            String nazivPitanja = p.getString("referenceValue");
                            nazivPitanja = nazivPitanja.substring(67);
                            pitanja.add(ucitajPitanje(nazivPitanja));
                        }}
                    Kviz k = new Kviz(naziv, kat, pitanja);
                    kvizoviIzBaze.add(k);
                }
                kvizovi.addAll(kvizoviIzBaze);
                odabrani.addAll(kvizoviIzBaze);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private Pitanje ucitajPitanje(String tekstPitanja) {
            GoogleCredential credentials;
            String TOKEN = "";
            String nazivPitanja="";
            int indexTacnog=0;
            ArrayList<String> odgovori=new ArrayList<>();
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                TOKEN = credentials.getAccessToken();
                String query="{\"structuredQuery\":{\"where\":{\"fieldFilter\":{\"field\":{\"fieldPath\":\"naziv\"},\"op\":\"EQUAL\"," +
                        "\"value\":{\"stringValue\":\""+tekstPitanja+"\"}}}," +
                        "\"select\":{\"fields\":[{\"fieldPath\":\"indexTacnog\"},{\"fieldPath\":\"naziv\"},{\"fieldPath\":\"odgovori\"}]}," +
                        "\"from\":[{\"collectionId\":\"Pitanja\"}],\"limit\":1000}}";
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents:runQuery?access_token="+ URLEncoder.encode(TOKEN, "UTF-8");
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");
                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                InputStream odgovor=conn.getInputStream();
                String rezultat="";

                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor,"utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine())!=null){
                        response.append(responseLine.trim());
                    }
                    rezultat =  "{ \"documents\": " + response.toString() + "}";
                    JSONObject object = new JSONObject(rezultat);
                    JSONArray niz=object.getJSONArray("documents");
                    for (int i =0;i<niz.length();i++){
                        JSONObject p=niz.getJSONObject(i);
                        JSONObject doc=p.getJSONObject("document");
                        JSONObject fields=doc.getJSONObject("fields");
                        JSONObject naziv=fields.getJSONObject("naziv");
                        nazivPitanja=naziv.getString("stringValue");
                        JSONObject index= fields.getJSONObject("indexTacnog");
                        indexTacnog=index.getInt("integerValue");
                        JSONObject nizz=fields.getJSONObject("odgovori");
                        JSONObject object2=nizz.getJSONObject("arrayValue");
                        JSONArray array=object2.getJSONArray("values");
                        for(int j=0;j<array.length();j++){
                            JSONObject object1=array.getJSONObject(j);
                            odgovori.add(object1.getString("stringValue"));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return new Pitanje(nazivPitanja,nazivPitanja,odgovori.get(indexTacnog),odgovori);
        }

        private Kategorija ucitajKategoriju(String nazivKategorije) {
            GoogleCredential credentials;
            String TOKEN = "";
            String nazivKat="", idIkone="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                TOKEN = credentials.getAccessToken();
                String query="{\"structuredQuery\":{\"where\":{\"fieldFilter\":{\"field\":{\"fieldPath\":\"naziv\"},\"op\":\"EQUAL\"," +
                        "\"value\":{\"stringValue\":\""+nazivKategorije+"\"}}}," +
                        "\"select\":{\"fields\":[{\"fieldPath\":\"idIkonice\"},{\"fieldPath\":\"naziv\"}]}," +
                        "\"from\":[{\"collectionId\":\"Kategorije\"}],\"limit\":1000}}";
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents:runQuery?access_token="+ URLEncoder.encode(TOKEN, "UTF-8");
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");
                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                InputStream odgovor=conn.getInputStream();
                String rezultat="";
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor,"utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine())!=null){
                        response.append(responseLine.trim());
                    }
                    rezultat =  "{ \"documents\": " + response.toString() + "}";
                    JSONObject object = new JSONObject(rezultat);
                    JSONArray niz=object.getJSONArray("documents");
                    for (int i =0;i<niz.length();i++){
                      JSONObject kat=niz.getJSONObject(i);
                      JSONObject doc=kat.getJSONObject("document");
                      JSONObject fields=doc.getJSONObject("fields");
                      JSONObject naziv=fields.getJSONObject("naziv");
                      nazivKat=naziv.getString("stringValue");
                      JSONObject id= fields.getJSONObject("idIkonice");
                      idIkone=""+id.getInt("integerValue");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return new Kategorija(nazivKat,idIkone,idIkone);
        }

    }

    private String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new
                InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
        } finally {
            try {
                is.close();
            } catch (IOException e) {
            }
        }
        return sb.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALENDAR},1);
        }
        aktivnost=this;
        odabrani = new ArrayList<>();
        kvizovi = new ArrayList<>();
//        odabrani.add(Kviz.dajPrazan());

        kategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
        lista = (ListView) findViewById(R.id.lvKvizovi);
        Resources res = getResources();
//        adapter = new ListaKvizovaAdapter(this, odabrani, res);
//        lista.setAdapter(adapter);
        kat = new ArrayList<>();
//        Kategorija K=Kategorija.dajSveKategoriju();
//        kat.add(K);
        adapterSpinera = new SpinerAdapter(this, kat, res );
        kategorije.setAdapter(adapterSpinera);
//        kategorije.setSelection(kat.size()-1);
//        deleteDatabase(KvizoviDBOpenHelper.DATABASE_NAME);
        dbZaUpis=new KvizoviDBOpenHelper(aktivnost,(KvizoviDBOpenHelper.DATABASE_NAME),null, KvizoviDBOpenHelper.DATABASE_VERSION).getWritableDatabase();
        dbZaCitanje=new KvizoviDBOpenHelper(aktivnost,(KvizoviDBOpenHelper.DATABASE_NAME),null, KvizoviDBOpenHelper.DATABASE_VERSION).getReadableDatabase();

        ContentLoadingProgressBar bar=new ContentLoadingProgressBar(this);
        bar.show();
        if(new ProvjeraKonekcije().imaKonekcije(aktivnost,false)) {
//            new PunjenjeBaze(aktivnost).isprazniTabele();
//            new PunjenjeBaze(aktivnost).isprazniKategorije();
            new UcitavanjeKvizova(this).execute(Kategorija.dajSveKategoriju());
            new UcitavanjeKategorija().execute();
        }
        else{
            Log.e("Net", "onCreate: bezneta");
            new UcitavanjeIzLokalne(dbZaCitanje).ucitajKategorije(kat);
            kat.add(0,Kategorija.dajSveKategoriju());
            adapterSpinera.notifyDataSetChanged();
            new UcitavanjeIzLokalne(dbZaCitanje).ucitajKvizove(kvizovi);
            new UcitavanjeIzLokalne(dbZaCitanje).ucitajKvizove(odabrani);
            if(odabrani.contains(Kviz.dajPrazan())){
                odabrani.remove(odabrani.indexOf(Kviz.dajPrazan()));
            }
            odabrani.add(Kviz.dajPrazan());
            adapter=new ListaKvizovaAdapter(this,odabrani,getResources());
            lista.setAdapter(adapter);
        }

       kategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                odabrani.clear();
                if(new ProvjeraKonekcije().imaKonekcije(aktivnost,false)) {
//                    new PunjenjeBaze(aktivnost).isprazniTabele();
                    new UcitavanjeKvizova(aktivnost).execute(kat.get(position));
                }
                else {if(kat.get(position).equals(Kategorija.dajSveKategoriju())){
                    odabrani.addAll(kvizovi);
                    Log.i("filter", "onItemSelected: dodao sve iz kvizova");
                }
                else {
                    for (int i = 0; i < kvizovi.size(); i++) {
                        if(kvizovi.get(i).getKategorija().getNaziv().equals(kat.get(position).getNaziv()))
                            odabrani.add(kvizovi.get(i));
                        Log.i("filter", "onItemSelected: dodao odabrane iz kvizova");

                    }
                }
                 odabrani.add(Kviz.dajPrazan());
                 adapter.notifyDataSetChanged();}

            }
            public void onNothingSelected(AdapterView<?> parent)
            {
//                new PunjenjeBaze(dbZaUpis).isprazniTabele();
////                lista.setAdapter(adapter);
//                new UcitavanjeKvizova(getBaseContext()).execute(Kategorija.dajSveKategoriju());

            }
        });

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
               if(!odabrani.get(position).equals(Kviz.dajPrazan()) && !new ProvjeraKalendara().provjeri(aktivnost,odabrani.get(position).getPitanja().size())){
                Intent myIntent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                myIntent.putExtra("kviz", odabrani.get(position));
                KvizoviAkt.this.startActivity(myIntent);
               }
            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if(new ProvjeraKonekcije().imaKonekcije(aktivnost, true)){
                Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                myIntent.putExtra("kviz", odabrani.get(position));
                myIntent.putExtra("staro_ime", odabrani.get(position).getNaziv());
               myIntent.putExtra("spiner", (Serializable) kat);
               myIntent.putExtra("pozicija",position);
               myIntent.putExtra("indexSpinera", kategorije.getSelectedItemPosition());
               myIntent.putExtra("kvizovi",kvizovi);
                KvizoviAkt.this.startActivityForResult(myIntent,1);
                }
                return true;
        }});
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if(resultCode == RESULT_OK) {
                ArrayList<Kategorija> novaLista=(ArrayList<Kategorija>) data.getSerializableExtra("kategorije");
                Kategorija nova = null;
                for (Kategorija ka:novaLista) {
                    if(!kat.contains(ka) && !ka.getNaziv().equals("Svi")) {
                        nova=ka; break;
                    }
                }
                kat.clear();
                kat.addAll(novaLista);
                adapterSpinera.notifyDataSetChanged();
                int index = data.getIntExtra("pozicija", 0);
                Kviz kviz = (Kviz) data.getSerializableExtra("kviz");
                if (odabrani.get(index).equals(Kviz.dajPrazan())) {
                    boolean postoji = false;
                    for (int i = 0; i < odabrani.size(); i++) {
                        if (odabrani.get(i).getNaziv().equals(kviz.getNaziv())) postoji = true;
                    }
                    if (!postoji){ odabrani.add(odabrani.size() - 1, kviz);
                    kvizovi.add(kviz);}
                } else {
                    odabrani.set(index, kviz);
                    for (int i = 0; i < kvizovi.size(); i++) {
                        if (kvizovi.get(i).getNaziv().equals(data.getStringExtra("staro_ime")))kvizovi.set(i,kviz);
                    }
                }
                kategorije.setSelection(0);
                adapterSpinera.notifyDataSetChanged();
            }if(resultCode==RESULT_CANCELED){
                ArrayList<Kategorija> novaLista=(ArrayList<Kategorija>) data.getSerializableExtra("kategorije");
                Kategorija nova = null;
                for (Kategorija ka:novaLista) {
                    if(!kat.contains(ka) && !ka.getNaziv().equals("Svi")) {
                        nova=ka; break;
                    }
                }
                kat.clear();
                kat.addAll(novaLista);
                adapterSpinera.notifyDataSetChanged();
            }
        adapter.notifyDataSetChanged();
        }
    }


    @Override
    protected void onResume() {
        if(new ProvjeraKonekcije().imaKonekcije(aktivnost,false)){
//        new PunjenjeBaze(aktivnost).isprazniTabele();
//            new PunjenjeBaze(aktivnost).isprazniKategorije();
        new UcitavanjeKvizova(this).execute(Kategorija.dajSveKategoriju());
        new UcitavanjeKategorija().execute();}
        else{
            new UcitavanjeIzLokalne(dbZaCitanje).ucitajKategorije(kat);
            kat.add(0,Kategorija.dajSveKategoriju());
            adapterSpinera.notifyDataSetChanged();
            new UcitavanjeIzLokalne(dbZaCitanje).ucitajKvizove(kvizovi);
            new UcitavanjeIzLokalne(dbZaCitanje).ucitajKvizove(odabrani);
            if(odabrani.contains(Kviz.dajPrazan())){
                odabrani.remove(odabrani.indexOf(Kviz.dajPrazan()));
            }
            odabrani.add(Kviz.dajPrazan());
            adapter=new ListaKvizovaAdapter(this,odabrani,getResources());
            lista.setAdapter(adapter);
        }
        super.onResume();
    }

}
