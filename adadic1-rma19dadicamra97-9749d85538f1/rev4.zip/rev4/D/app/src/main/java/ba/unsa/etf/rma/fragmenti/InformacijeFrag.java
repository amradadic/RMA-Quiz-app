package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class InformacijeFrag extends Fragment {

    private TextView imeKvizaView, brojTacnihView, procenatTacnihView, brojPreostalihView;
    private Button kraj;
    Kviz k;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v= inflater.inflate(R.layout.informacije_fragment, container, false);
        imeKvizaView=v.findViewById(R.id.infNazivKviza);
        brojTacnihView=v.findViewById(R.id.infBrojTacnihPitanja);
        brojPreostalihView=v.findViewById(R.id.infBrojPreostalihPitanja);
        procenatTacnihView=v.findViewById(R.id.infProcenatTacni);
        kraj=v.findViewById(R.id.btnKraj);
        k= (Kviz) getArguments().getSerializable("kviz");

        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setImeKviza(k.getNaziv());
        setProcenatTacnih(getArguments().getString("procenat"));
        setBrojTacnih(getArguments().getString("brTacnih"));
        setBrojPreostalih(getArguments().getString("preostalo"));

        kraj.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getActivity().finish();
            }
        });
    }

    public void setImeKviza(String ime){
        imeKvizaView.setText(ime);
    }
    public void setBrojTacnih(String brojTacnih) {
        brojTacnihView.setText(brojTacnih);
    }

    public void setProcenatTacnih(String procenatTacnih) {
        procenatTacnihView.setText(procenatTacnih);
    }

    public void setBrojPreostalih(String brojPreostalih) {
        brojPreostalihView.setText(brojPreostalih);
    }


}
