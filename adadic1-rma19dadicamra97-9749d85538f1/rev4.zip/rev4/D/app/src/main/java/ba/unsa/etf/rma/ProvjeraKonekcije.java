package ba.unsa.etf.rma;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.Toast;


public class ProvjeraKonekcije {
    public boolean imaKonekcije(Context context, boolean poruka) {
        boolean connected=false;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            connected = networkInfo != null && networkInfo.isAvailable() &&
                    networkInfo.isConnected();
            if(!connected && poruka) Toast.makeText(context, "Internet konekcija prekinuta" , Toast.LENGTH_LONG).show();

            return connected;


        } catch (Exception e) {
            System.out.println("CheckConnectivity Exception: " + e.getMessage());
            Log.v("connectivity", e.toString());
        }
        if(!connected && poruka) Toast.makeText(context, "Internet konekcija prekinuta" , Toast.LENGTH_LONG).show();
        return connected;
    }
}
