package ba.unsa.etf.rma;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import java.util.Calendar;

public class ProvjeraKalendara {
    public static final String[] INSTANCE_PROJECTION = new String[] {
            CalendarContract.Instances.BEGIN
    };
    public boolean provjeri(Context context, int brPitanja){
        if(brPitanja==0) return false;
        Calendar beginTime = Calendar.getInstance();
        beginTime.setTimeInMillis(System.currentTimeMillis());
        long startMillis = beginTime.getTimeInMillis();
        Calendar endTime = Calendar.getInstance();
        endTime.setTimeInMillis(System.currentTimeMillis());
        int seconds=endTime.get(Calendar.SECOND);
        if(seconds!=0) endTime.add(Calendar.SECOND, 60-seconds);
        endTime.add(Calendar.MINUTE,brPitanja/2);
        if(brPitanja%2!=0) endTime.add(Calendar.MINUTE,1);
        long endMillis = endTime.getTimeInMillis();

        String selection = CalendarContract.Instances.BEGIN + " >= ?";
        String[] selectionArgs = new String[] {""+startMillis};

        Cursor cur = null;
        ContentResolver cr = context.getContentResolver();
        Uri.Builder builder = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(builder, startMillis);
        ContentUris.appendId(builder, endMillis);

        cur =  cr.query(builder.build(),
                INSTANCE_PROJECTION,
                selection,
                selectionArgs,
                null);
        if(cur.getCount()>0){
            long beginVal = 0;
            cur.moveToNext();
            beginVal = cur.getLong(0);
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(beginVal);
            int minute=calendar.get(Calendar.MINUTE)-beginTime.get(Calendar.MINUTE);
            poruka(context,"Imate događaj u kalendaru za "+minute+" minuta!");
            return true;
        }
return false;
    }
    private  void poruka(Context context, String s){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage(s);
        builder1.setCancelable(true);
        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
