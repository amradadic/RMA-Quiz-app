package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class Kategorija implements Serializable {
    String naziv="", id="";
    String ikona;

    public Kategorija() {

    }

    public String getIkona() {
        return ikona;
    }

    public void setIkona(String ikona) {
        this.ikona = ikona;
    }

    public Kategorija(String naziv, String id, String ikona) {
        this.naziv = naziv;
        this.id = id;
        this.ikona=ikona;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    static public Kategorija dajPraznuKategoriju(){
        Kategorija dodaj_kategoriju = new Kategorija("Dodaj kategoriju", "671", "");
        return dodaj_kategoriju;
    }
    static  public Kategorija dajSveKategoriju(){
        final Kategorija sve = new Kategorija("Svi", "809", "");
        return sve;
    }
//    static public Kategorija dajDefaultKategoriju(){
//        final Kategorija defaultna= new Kategorija("Bez kategorije", "809", "");
//        return  defaultna;
//    }

    @Override
    public boolean equals(Object obj) {
        return ((Kategorija)obj).getNaziv().equals(naziv);
    }

}
