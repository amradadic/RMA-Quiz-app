package ba.unsa.etf.rma.aktivnosti;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.provider.CalendarContract;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Calendar;
import java.util.Random;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CustomAdapter;
import ba.unsa.etf.rma.klase.DatabaseHelper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.NetworkStateReceiver;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity implements NetworkStateReceiver.NetworkStateReceiverListener {

    public Spinner spinner;
    public ListView lista;
    public ArrayList<Kviz> kvizovi;
    public ArrayList<Kviz> kvizoviTemp;
    public ArrayList<Kategorija> kategorije;
    public ArrayList<Pitanje> listaMogucihPitanja;
    public CustomAdapter<Kviz> adapter;
    public HashMap<Kategorija, ArrayList<Kviz>> mapaKvizova;
    public HashMap<Kategorija, Boolean> mapaKategorija;
    public HashMap<Kategorija, Integer> mapaIdKategorija;
    public int ukupanBrojPitanja = 0;
    public int ukupanBrojKvizova = 0;
    public int ukupanBrojKategorija = 0;
    public ArrayAdapter<Kategorija> adapterZaSpinner;
    public ArrayList<String> kategorijaZaSpinner;
    public Boolean fetchingData = false;
    private NetworkStateReceiver networkStateReceiver;
    public Boolean imaNeta = false;
    public Boolean already = false;
    public DatabaseHelper databaseHelper;
    public String pozicija, naziv, procenat, idKvizaaa;
    public Boolean vecDohvacenoSaFB = false;
    public ArrayList<Kviz> sviKvizovi;
    private final static int REQUEST_CODE_1 = 1;
    public ArrayList<String> ranglista;
    public Boolean kopiranoIzAssets = false;
    public Boolean kopiranoIzLOkalne = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ranglista = new ArrayList<>();
        Random rand = new Random();
        int n = rand.nextInt(500000);
        databaseHelper = new DatabaseHelper(this);
        try {
            databaseHelper.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }
        networkStateReceiver = new NetworkStateReceiver();
        networkStateReceiver.addListener(this);
        this.registerReceiver(networkStateReceiver, new IntentFilter(android.net.ConnectivityManager.CONNECTIVITY_ACTION));

        mapaKategorija = new HashMap<>();
        mapaKvizova = new HashMap<>();
        mapaIdKategorija = new HashMap<>();

        sviKvizovi = new ArrayList<>();
        kvizoviTemp = new ArrayList<>();
        spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);
        lista = (ListView) findViewById(R.id.lvKvizovi);
        kategorije = new ArrayList<>();
        Intent intent2 = getIntent();
        Bundle bundle2 = intent2.getExtras();
        Handler handler7 = new Handler();
        handler7 = new Handler();
        handler7.postDelayed(new Runnable() {
            public void run() {
                if(imaNeta){
                }
                else {
                    Toast.makeText(getApplicationContext(), "nema neta", Toast.LENGTH_LONG).show();

                }
            }
        }, 1000);



        if(bundle2 != null && bundle2.containsKey("Kategorije")){
            kategorije = (ArrayList<Kategorija>) bundle2.getSerializable("Kategorije");

            if(bundle2.containsKey("mapaKvizova")&& bundle2.containsKey("mapaIdKategorija")&& bundle2.containsKey("mapaKategorija")){
                mapaKvizova = (HashMap<Kategorija, ArrayList<Kviz>>) ((HashMap<Kategorija, ArrayList<Kviz>>) bundle2.getSerializable("mapaKvizova")).clone();
                mapaIdKategorija = (HashMap<Kategorija, Integer>) ((HashMap<Kategorija, Integer>) bundle2.getSerializable("mapaIdKategorija")).clone();
                mapaKategorija = (HashMap<Kategorija, Boolean>) ((HashMap<Kategorija, Boolean>) bundle2.getSerializable("mapaKategorija")).clone();
                ukupanBrojPitanja = bundle2.getInt("ukupanBrojPitanja");
                ukupanBrojKvizova =  bundle2.getInt("ukupanBrojKvizova");
                ukupanBrojKategorija =  bundle2.getInt("ukupanBrojKategorija");
                already = true;
            }
        }
        else {
            kategorije.add(new Kategorija("Kategorija", "0"));
        }


        ArrayList<Pitanje> pitanja = new ArrayList<>();
        ArrayList<String> odgovori = new ArrayList<>();

        ukupanBrojKategorija += 2;

        listaMogucihPitanja = new ArrayList<>();

        pitanja.add(new Pitanje("Dodaj Pitanje", null, null, null, -1,
                android.R.drawable.ic_input_add));

        kvizovi = new ArrayList<>();
        kategorijaZaSpinner = new ArrayList<>();

        kategorijaZaSpinner.add("Kategorije");


        adapterZaSpinner = new ArrayAdapter<Kategorija>(this,
                android.R.layout.simple_spinner_item, kategorije){
            @Override
            public boolean isEnabled(int position){
                if(position == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if(position == 0){
                    tv.setTextColor(Color.GRAY);
                }
                else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        adapter = new CustomAdapter<>(this, R.layout.elementi_liste, kvizoviTemp);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        lista.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                if(position > 0 && position-1 < kategorijaZaSpinner.size()){
                    Kategorija kategorija1 = new Kategorija();
                    for(Kategorija t : kategorije){
                        ////log.d("trazim", "petlja");
                        if(t.getNaziv().equals(kategorijaZaSpinner.get(position+1))){
                            kategorija1 = t;
                            break;
                        }
                    }
                    kvizoviTemp = new ArrayList<>();
                    for(Kviz kv : sviKvizovi){
                        if(kv.getKategorija().getNaziv().equals(kategorija1.getNaziv())){
                            kvizoviTemp.add(kv);
                        }
                    }
                    kvizoviTemp.add(new Kviz("Dodaj kviz", null, kategorije.get(0), android.R.drawable.ic_input_add, 0));
                    adapter = new CustomAdapter<>(getApplicationContext(), R.layout.elementi_liste, kvizoviTemp);
                    lista.setAdapter(adapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        adapterZaSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapterZaSpinner);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(fetchingData)
                    Toast.makeText(getApplicationContext(), "jos uvijek dohvacam podatke sa firebase", Toast.LENGTH_LONG).show();
                else
                   if(position < kvizoviTemp.size()-1){

                        Intent intent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                        int y=-1;
                       if(imaNeta) {
                           CalendarHelper calendarHelper1 = new CalendarHelper();
                           y = calendarHelper1.fetchCal(kvizoviTemp.get(position));
                       }
                        if(y!=-1){
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(KvizoviAkt.this);
                            builder1.setMessage("Imate događaj u kalendaru za "+y+" minuta!");
                            builder1.setCancelable(true);
                            builder1.setPositiveButton("OK", null);
                            AlertDialog alert11 = builder1.create();
                            alert11.show();
                        }else{
                            if(imaNeta)
                                intent.putExtra("Online", "True");
                            else
                                intent.putExtra("Online", "False");
                            intent.putExtra("Kviz", kvizoviTemp.get(position));
                            Pitanje temp = kvizoviTemp.get(position).getPitanja().get(kvizoviTemp.get(position).getPitanja().size()-1);
                            kvizoviTemp.get(position).getPitanja().remove(kvizoviTemp.get(position).getPitanja().size()-1);
                            intent.putStringArrayListExtra("RANGLISTA", ranglista);
                            KvizoviAkt.this.startActivityForResult(intent, REQUEST_CODE_1);
                            kvizoviTemp.get(position).getPitanja().add(temp);
                        }
                    }
            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                intent.putExtra("Kategorije", kategorije);

                if(fetchingData)
                    Toast.makeText(getApplicationContext(), "jos uvijek dohvacam podatke sa firebase", Toast.LENGTH_LONG).show();
                else if(!imaNeta)
                    Toast.makeText(getApplicationContext(), "zabranjeno kreiranje i editovanje kvizova u offline mode-u", Toast.LENGTH_LONG).show();
                else
                if(position < kvizoviTemp.size()-1){
                    intent.putExtra("Edit", "true");
                    intent.putExtra("Kviz", kvizoviTemp.get(position));
                    intent.putExtra("Kvizovi", kvizoviTemp);
                    intent.putExtra("Pozicija", position);
                    intent.putExtra("DodatnaPitanja", listaMogucihPitanja);
                    intent.putExtra("mapaIdKategorija", mapaIdKategorija);
                    intent.putExtra("mapaKategorija", mapaKategorija);
                    intent.putExtra("mapaKvizova", mapaKvizova);
                    intent.putExtra("ukupanBrojPitanja", ukupanBrojPitanja);
                    intent.putExtra("ukupanBrojKvizova", ukupanBrojKvizova);
                    intent.putExtra("ukupanBrojKategorija", ukupanBrojKategorija);

                    KvizoviAkt.this.startActivity(intent);
                }
                else {
                    intent.putExtra("Edit", "false");
                    intent.putExtra("Kvizovi", kvizoviTemp);
                    intent.putExtra("Pozicija", position);
                    intent.putExtra("DodatnaPitanja", listaMogucihPitanja);
                    intent.putExtra("mapaIdKategorija", mapaIdKategorija);
                    intent.putExtra("mapaKategorija", mapaKategorija);
                    intent.putExtra("mapaKvizova", mapaKvizova);
                    intent.putExtra("ukupanBrojPitanja", ukupanBrojPitanja);
                    intent.putExtra("ukupanBrojKvizova", ukupanBrojKvizova);
                    intent.putExtra("ukupanBrojKategorija", ukupanBrojKategorija);

                    KvizoviAkt.this.startActivity(intent);
                }
                return true;
            }
        });
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
                kvizoviTemp = (ArrayList<Kviz>) ((ArrayList<Kviz>) intent.getSerializableExtra("Kvizovi"))
                        .clone();

                kvizovi = (ArrayList<Kviz>) ((ArrayList<Kviz>) intent.getSerializableExtra("Kvizovi"))
                        .clone();
                kategorije = (ArrayList<Kategorija>) ((ArrayList<Kategorija>) intent.getSerializableExtra("Kategorije"))
                        .clone();
                adapterZaSpinner.notifyDataSetChanged();

                listaMogucihPitanja = (ArrayList<Pitanje>) ((ArrayList<Pitanje>) intent.
                        getSerializableExtra("MogucaPitanja"))
                        .clone();

                mapaKvizova = (HashMap<Kategorija, ArrayList<Kviz>>) ((HashMap<Kategorija, ArrayList<Kviz>>) intent.getSerializableExtra("mapaKvizova")).clone();
                mapaIdKategorija = (HashMap<Kategorija, Integer>) ((HashMap<Kategorija, Integer>) intent.getSerializableExtra("mapaIdKategorija")).clone();
                mapaKategorija = (HashMap<Kategorija, Boolean>) ((HashMap<Kategorija, Boolean>) intent.getSerializableExtra("mapaKategorija")).clone();

                adapter = new CustomAdapter<>(this, R.layout.elementi_liste, kvizoviTemp);
                lista.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

    }

    @Override
    public void networkAvailable() {
        imaNeta = true;
        Toast.makeText(getApplicationContext(), "ima neta", Toast.LENGTH_LONG).show();
        if(!vecDohvacenoSaFB) {
            fetchingData = true;


            vecDohvacenoSaFB = true;
            Toast.makeText(getApplicationContext(), "dohvacam podatke sa firebase", Toast.LENGTH_LONG).show();
            new DohvatiSveKategorija().execute("");
            Toast.makeText(getApplicationContext(), "dohvacam podatke sa firebase", Toast.LENGTH_LONG).show();
        }
        new DohvatiRangListu().execute("");
    }

    @Override
    public void networkUnavailable() {
        imaNeta = false;
        if(!kopiranoIzAssets) {
            databaseHelper.kopirajDBizAssets();
            kopiranoIzAssets=true;
        }
        if(!kopiranoIzLOkalne){
            databaseHelper.kopirajIzLokalne();
            kopiranoIzLOkalne=true;
        }

        if(!vecDohvacenoSaFB) {
            kategorije = new ArrayList<>();
            kategorije.addAll((ArrayList<Kategorija>) (databaseHelper.dajKategorije()).clone());
            kategorijaZaSpinner = new ArrayList<>();
            for (Kategorija s : kategorije)
                kategorijaZaSpinner.add(s.getNaziv());

            adapterZaSpinner.addAll((ArrayList<Kategorija>) kategorije.clone());
            sviKvizovi = databaseHelper.dajSveKvizove();
            for (Kategorija ka : kategorije) {
                for (Kviz kv : sviKvizovi) {
                    if (kv.getIdKategorije().equals(ka.getId())) {
                        kv.setKategorija(ka);
                    }
                }
            }

            for (Kviz kivi : sviKvizovi) {
            }
            listaMogucihPitanja = databaseHelper.dajMogucaPitanja();

            if (kategorije.size() > 1) {
                kvizoviTemp = (ArrayList<Kviz>) (databaseHelper.dajKvizove(kategorije.get(1))).clone();
                kvizoviTemp.add(new Kviz("Dodaj kviz", null, kategorije.get(1), android.R.drawable.ic_input_add, 0));
            }
            adapter = new CustomAdapter<>(getApplicationContext(), R.layout.elementi_liste, kvizoviTemp);
            lista.setAdapter(adapter);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        networkStateReceiver.removeListener(this);
        this.unregisterReceiver(networkStateReceiver);
    }

    public class DohvatiKvizove extends AsyncTask<String, Void, List<Kviz>>{

        public Kategorija kat = new Kategorija();

        @Override
        protected List<Kviz> doInBackground(String... strings) {

            GoogleCredential credentials;
            ArrayList<Kviz> kvizs = new ArrayList<>();

            for(Kategorija k : kategorije){
                if(k.getNaziv().equals(strings[0])){
                    kat = k;
                }
            }
            String query = "{\n" +
                    "    \"structuredQuery\": {\n" +
                    "   \"where\" : {\n" +
                    "      \"fieldFilter\" : {\n" +
                    "         \"field\" : {\"fieldPath\" : \"idKategorije\"}, \n" +
                    "         \"op\" : \"EQUAL\", \n" +
                    "                \"value\" : {\"stringValue\" : \""+mapaIdKategorija.get(kat)+"\"}\n" +
                    "   }\n" +
                    "  },\n" +
                    "\"select\" : { "+
                    "\"fields\" : ["+
                    "{\"fieldPath\" : \"idKategorije\"}, {\"fieldPath\" : \"naziv\"}, {\"fieldPath\" : \"pitanja\"}] },\n"+
                    " \"from\" : [{\"collectionId\" : \"Kvizovi\"}], \n" +
                    " \"limit\" : 1000 \n"+
                    " }\n}";


            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Kvizovi?access_token=";
                try {
                    String url1 = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                            "documents:runQuery?access_token=";
                    URL urlObj2 = new URL(url1 + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn2 = (HttpURLConnection) urlObj2.openConnection();
                    conn2.setDoInput(true);
                    conn2.setRequestMethod("POST");
                    conn2.setRequestProperty("Content-Type", "application/json");
                    conn2.setRequestProperty("Accept", "application/json");
                    try (OutputStream os = conn2.getOutputStream()) {
                        byte[] input = query.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }

                    int code = conn2.getResponseCode();
                    InputStream odgovor2 = conn2.getInputStream();
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(odgovor2));
                    StringBuilder sb = new StringBuilder();
                    String rezulat = null;
                    try {
                        while ((rezulat = reader2.readLine()) != null) {
                            sb.append(rezulat + "\n");
                        }
                    } catch (IOException e) {
                    } finally {
                        try {
                            odgovor2.close();
                        } catch (IOException e) {
                        }
                    }

                    try {
                        JSONArray array = new JSONArray(sb.toString());

                        int p=0;
                        try {
                            for(int i=0; i<array.length(); i++) {
                                p=0;
                                Kviz novi = new Kviz();
                                JSONObject object = array.getJSONObject(i);
                                novi.setIndicator(1);
                                JSONObject document = object.getJSONObject("document");
                                String name = document.getString("name");

                                name = name.substring(name.lastIndexOf('/') + 1);
                                novi.setIdKviza(Integer.parseInt(name));
                                JSONObject fields = document.getJSONObject("fields");
                                JSONObject naziv = fields.getJSONObject("naziv");
                                novi.setNaziv(naziv.getString("stringValue"));
                                JSONObject idKat = fields.getJSONObject("idKategorije");
                                novi.setIdKategorije(idKat.getString("stringValue"));
                                ArrayList<String> tempPit = new ArrayList<>();
                                JSONObject array1 = fields.getJSONObject("pitanja");
                                JSONObject arrayValue = array1.getJSONObject("arrayValue");
                                JSONArray values = arrayValue.getJSONArray("values");
                                for(int j=0; j<values.length(); j++) {
                                    tempPit.add(values.getJSONObject(j).getString("integerValue"));
                                }
                                novi.setIndexiPitanja(tempPit);
                                novi.setKategorija(kat);
                                kvizs.add(novi);
                            }
                        } catch (JSONException e) {
                            Log.d("problem", e.getMessage());
                        }
                    } catch (JSONException e) {
                        Log.d("problem", e.getMessage());
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return kvizs;
        }

        @Override
        protected void onPostExecute(List<Kviz> kvizs) {
            super.onPostExecute(kvizs);


            kvizoviTemp.removeAll(kvizoviTemp);
            kvizoviTemp.addAll(kvizs);
            kvizoviTemp.add(new Kviz("Dodaj kviz", null, kategorije.get(2), android.R.drawable.ic_input_add, 0));
            kvizs.add(new Kviz("Dodaj kviz", null, kategorije.get(2), android.R.drawable.ic_input_add, 0));

            mapaKategorija.remove(kat);
            mapaKategorija.put(kat, true);
            mapaKvizova.put(kat, (ArrayList) kvizs);
            adapter.notifyDataSetChanged();

        }
    }
    public class DohvatiPitanja extends AsyncTask<String, Void, List<Pitanje>>{

        public Kviz kvizz;
        public String s = null;

        @Override
        protected List<Pitanje> doInBackground(String... strings) {
            GoogleCredential credentials;
            ArrayList<Pitanje> pitanjas = new ArrayList<>();

            fetchingData = true;
            s = strings[0];
            for(Kviz k : kvizoviTemp){
                if(k.getNaziv().equals(strings[0])){
                    kvizz = k;
                }
            }
            String query = "{\n" +
                    "    \"structuredQuery\": {\n" +
                    "\"select\" : { "+
                    "\"fields\" : ["+
                    "{\"fieldPath\" : \"indexTacnog\"}, {\"fieldPath\" : \"naziv\"}, " +
                    "{\"fieldPath\" : \"postavljen\"}, {\"fieldPath\" : \"odgovori\"}] },\n"+
                    " \"from\" : [{\"collectionId\" : \"Pitanja\"}], \n" +
                    " \"limit\" : 1000 \n"+
                    " }\n}";

            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Pitanja?access_token=";
                try {
                    String url1 = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                            "documents:runQuery?access_token=";
                    URL urlObj2 = new URL(url1 + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn2 = (HttpURLConnection) urlObj2.openConnection();
                    conn2.setDoInput(true);
                    conn2.setRequestMethod("POST");
                    conn2.setRequestProperty("Content-Type", "application/json");
                    conn2.setRequestProperty("Accept", "application/json");


                    try (OutputStream os = conn2.getOutputStream()) {
                        byte[] input = query.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }

                    int code = conn2.getResponseCode();
                    InputStream odgovor2 = conn2.getInputStream();
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(odgovor2));
                    StringBuilder sb = new StringBuilder();
                    String rezulat = null;

                    try {
                        while ((rezulat = reader2.readLine()) != null) {
                            sb.append(rezulat + "\n");
                        }
                    } catch (IOException e) {
                    } finally {
                        try {
                            odgovor2.close();
                        } catch (IOException e) {
                        }
                    }

                    try {
                        JSONArray array = new JSONArray(sb.toString());
                        try {
                            for(int i=0; i<array.length(); i++) {
                                Pitanje novi = new Pitanje();
                                JSONObject object = array.getJSONObject(i);
                                JSONObject document = object.getJSONObject("document");
                                JSONObject fields = document.getJSONObject("fields");
                                JSONObject naziv = fields.getJSONObject("naziv");
                                String name = document.getString("name");
                                name = name.substring(name.lastIndexOf('/') + 1);
                                novi.setNaziv(name);

                                JSONObject postavljen = fields.getJSONObject("postavljen");
                                novi.setPostavljen(postavljen.getBoolean("booleanValue"));

                                novi.setTekstPitanja(naziv.getString("stringValue"));
                                JSONObject idKat = fields.getJSONObject("indexTacnog");
                                novi.setTacan(idKat.getString("integerValue"));
                                novi.setIndexTacnog(idKat.getInt("integerValue"));
                                ArrayList<String> tempPit = new ArrayList<>();

                                JSONObject array1 = fields.getJSONObject("odgovori");
                                JSONObject arrayValue = array1.getJSONObject("arrayValue");
                                JSONArray values = arrayValue.getJSONArray("values");

                                for(int j=0; j<values.length(); j++) {
                                     tempPit.add(values.getJSONObject(j).getString("stringValue"));
                                }

                                novi.setOdgovori(tempPit);
                                pitanjas.add(novi);
                            }
                        } catch (JSONException e) {
                        }
                    } catch (JSONException e) {
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            ukupanBrojPitanja = pitanjas.size();
            return pitanjas;
        }

        @Override
        protected void onPostExecute(List<Pitanje> pitanja) {
            super.onPostExecute(pitanja);
            ArrayList<Pitanje> mogucaP = new ArrayList<>();
            for(Pitanje p: pitanja)
                if(!p.isPostavljen()) {
                    mogucaP.add(p);
                    databaseHelper.createPitanje(p, false);
                }

                boolean nadjenKviz = false;
             for(Pitanje p: pitanja){
                 if(p.isPostavljen()){
                     for(Kviz k : sviKvizovi){
                         for(String index : k.getIndexiPitanja()){
                             if(p.getNaziv().equals(index)){
                                 nadjenKviz = true;
                                 break;
                             }
                         }
                         if(nadjenKviz){
                             nadjenKviz = false;
                             k.dodajPitanje(p);
                             break;
                         }
                     }
                 }
             }

             for(Kviz kv : sviKvizovi){
                 databaseHelper.createKviz(kv);
                 kv.dodajPitanje(new Pitanje("Dodaj Pitanje", null, null, null,-1,
                         android.R.drawable.ic_input_add));
             }

             kvizoviTemp = new ArrayList<>();
             for(Kviz kv : sviKvizovi){
                 if(kv.getKategorija().getNaziv().equals("Svi")){
                     kvizoviTemp.add(kv);
                 }
             }
            kvizoviTemp.add(new Kviz("Dodaj kviz", null, kategorije.get(0), android.R.drawable.ic_input_add, 0));
            adapter = new CustomAdapter<>(getApplicationContext(), R.layout.elementi_liste, kvizoviTemp);
             lista.setAdapter(adapter);
            listaMogucihPitanja = (ArrayList<Pitanje>) mogucaP.clone();
            fetchingData = false;
        }
    }

    public class DohvatiSveKvizove extends AsyncTask<String, Void, Integer>{

        public Kategorija kat = new Kategorija();

        @Override
        protected Integer doInBackground(String... strings) {

            GoogleCredential credentials;
            ArrayList<Kviz> kvizs = new ArrayList<>();

            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Kvizovi?access_token=";
                try {

                    URL urlObj2 = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn2 = (HttpURLConnection) urlObj2.openConnection();
                    conn2.setDoInput(true);
                    conn2.setRequestMethod("GET");
                    conn2.setRequestProperty("Content-Type", "application/json");
                    conn2.setRequestProperty("Accept", "application/json");


                    int code = conn2.getResponseCode();
                    InputStream odgovor2 = conn2.getInputStream();
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(odgovor2));
                    StringBuilder sb = new StringBuilder();
                    String rezulat = null;

                    try {
                        while ((rezulat = reader2.readLine()) != null) {
                            sb.append(rezulat + "\n");
                        }
                    } catch (IOException e) {
                    } finally {
                        try {
                            odgovor2.close();
                        } catch (IOException e) {
                        }
                    }

                    try {
                        JSONObject ob = new JSONObject(sb.toString());
                        JSONArray array = ob.getJSONArray("documents");
                        try {
                                 for(int i=0; i<array.length(); i++) {
                                Kviz novi = new Kviz();
                               JSONObject object = array.getJSONObject(i);
                                JSONObject fields = object.getJSONObject("fields");
                                JSONObject naziv = fields.getJSONObject("naziv");
                                String nazivv = object.getString("name");
                                novi.setIdKviza(Integer.parseInt(nazivv.substring(nazivv.lastIndexOf('/') + 1)));
                                novi.setNaziv(naziv.getString("stringValue"));
                                JSONObject idKat = fields.getJSONObject("idKategorije");
                                novi.setIdKategorije(idKat.getString("stringValue"));
                                ArrayList<String> tempPit = new ArrayList<>();
                                JSONObject array1 = fields.getJSONObject("pitanja");
                                JSONObject arrayValue = array1.getJSONObject("arrayValue");
                                JSONArray values = arrayValue.getJSONArray("values");

                                for(int j=0; j<values.length(); j++) {
                                    tempPit.add(values.getJSONObject(j).getString("integerValue"));
                                }

                                for(Kategorija k: kategorije){
                                    if(k.getId().equals(idKat.getString("stringValue"))){
                                        novi.setKategorija(k);
                                        novi.setIndicator(1);
                                    }
                                }
                                novi.setIndexiPitanja(tempPit);
                                kvizs.add(novi);
                            }
                                 sviKvizovi = (ArrayList<Kviz>) (kvizs.clone());
                        } catch (JSONException e) {
                            Log.d("GETTING BACK", "FETCH IT ALL FROM DB");
                        }
                    } catch (JSONException e) {
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return kvizs.size();
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            ukupanBrojKvizova = integer;

            new DohvatiPitanja().execute("");
        }
    }

    public class DohvatiSveKategorija extends AsyncTask<String, Void, Integer>{

        public Kategorija kat = new Kategorija();

        @Override
        protected Integer doInBackground(String... strings) {

            GoogleCredential credentials;
            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Kategorije?access_token=";
                try {

                    URL urlObj2 = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn2 = (HttpURLConnection) urlObj2.openConnection();
                    conn2.setDoInput(true);
                    conn2.setRequestMethod("GET");
                    conn2.setRequestProperty("Content-Type", "application/json");
                    conn2.setRequestProperty("Accept", "application/json");


                    int code = conn2.getResponseCode();
                    InputStream odgovor2 = conn2.getInputStream();
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(odgovor2));
                    StringBuilder sb = new StringBuilder();
                    String rezulat = null;

                    try {
                        while ((rezulat = reader2.readLine()) != null) {
                            sb.append(rezulat + "\n");
                        }
                    } catch (IOException e) {
                    } finally {
                        try {
                            odgovor2.close();
                        } catch (IOException e) {
                        }
                    }

                    try {
                        JSONObject ob = new JSONObject(sb.toString());
                        JSONArray array = ob.getJSONArray("documents");
                        try {
                            for(int i=0; i<array.length(); i++) {
                                Kategorija novi = new Kategorija();
                                JSONObject object = array.getJSONObject(i);

                                String id = object.getString("name");
                                id = id.substring(id.lastIndexOf('/') + 1);
                                novi.setId(id);
                                JSONObject fields = object.getJSONObject("fields");

                                JSONObject naziv = fields.getJSONObject("naziv");
                                novi.setNaziv(naziv.getString("stringValue"));
                                JSONObject idKat = fields.getJSONObject("idIkonice");
                                novi.setIcon(idKat.getInt("integerValue"));

                                kategorije.add(novi);
                            }
                        } catch (JSONException e) {
                        }
                    } catch (JSONException e) {
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return kategorije.size();
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            ukupanBrojKategorija = integer;

            for(Kategorija k : kategorije) {
                mapaKategorija.put(k, false);
                mapaIdKategorija.put(k, Integer.valueOf(k.getId()));
            }

           for(Kategorija k: kategorije){
                kategorijaZaSpinner.add(k.getNaziv());
            }

           for(int l=1; l<kategorije.size(); l++){
               databaseHelper.createKategoriju(kategorije.get(l));
           }
           //adapterZaSpinner.addAll(kategorije);
            adapterZaSpinner.notifyDataSetChanged();

            kvizoviTemp.add(new Kviz("Dodaj kviz", null, kategorije.get(0), android.R.drawable.ic_input_add, 0));

            new DohvatiSveKvizove().execute("sve");

        }
    }


    public void dohvatiSveKat(){

        if(mapaKategorija.size()>0) return;

        Handler handler4 = new Handler();
        handler4 = new Handler();
        handler4.postDelayed(new Runnable() {
            public void run() {
                if(imaNeta){
                    new DohvatiSveKategorija().execute("");
                    Toast.makeText(getApplicationContext(), "dohvacam podatke sa firebase", Toast.LENGTH_LONG).show();
                    fetchingData = true;
                }
            }
        }, 2000);
    }

    public void dohvatiPitanja(){
        Handler handler = new Handler();
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                if(imaNeta) {
                    Toast.makeText(getApplicationContext(), "dohvacam podatke sa firebase", Toast.LENGTH_LONG).show();
                    for (Map.Entry<Kategorija, ArrayList<Kviz>> m : mapaKvizova.entrySet()) {
                        for (int l = 0; l < m.getValue().size() - 1; l++) {
                            new DohvatiPitanja().execute(m.getValue().get(l).getNaziv());
                        }
                    }
                    fetchingData = false;
                }
                already = true;
            }
        }, 7000);
    }

    public class DohvatiRangListu extends AsyncTask<String, Void, ArrayList<String>> {

        int pozicija1=0;
        @Override
        protected ArrayList<String> doInBackground(String... strings) {

            GoogleCredential credentials;
            ArrayList<String> ranglista = new ArrayList<>();

            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Rangliste?access_token=";
                try {

                    URL urlObj2 = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn2 = (HttpURLConnection) urlObj2.openConnection();
                    conn2.setDoInput(true);
                    conn2.setRequestMethod("GET");
                    conn2.setRequestProperty("Content-Type", "application/json");
                    conn2.setRequestProperty("Accept", "application/json");

                    int code = conn2.getResponseCode();
                    InputStream odgovor2 = conn2.getInputStream();
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(odgovor2));
                    StringBuilder sb = new StringBuilder();
                    String rezulat = null;

                    try {
                        while ((rezulat = reader2.readLine()) != null) {
                            sb.append(rezulat + "\n");
                        }
                    } catch (IOException e) {
                    } finally {
                        try {
                            odgovor2.close();
                        } catch (IOException e) {
                        }
                    }

                    try {

                        JSONObject documne = new JSONObject(sb.toString());
                        JSONArray array = documne.getJSONArray("documents");
                        try {
                            for(int i=0; i<array.length(); i++) {
                                String igrac = "";
                                pozicija1++;
                                JSONObject object = array.getJSONObject(i);

                                JSONObject fields = object.getJSONObject("fields");
                                JSONObject lista = fields.getJSONObject("lista");
                                JSONObject nazivKviza = fields.getJSONObject("nazivKviza");
                                String nazivKvizaa = nazivKviza.getString("stringValue");
                                JSONObject mapa = lista.getJSONObject("mapValue");
                                JSONObject fi = mapa.getJSONObject("fields");
                                igrac += fi.getJSONObject("pozicija").getString("stringValue");

                                igrac += " "+fi.
                                        getJSONObject("vrijednost").
                                        getJSONObject("mapValue").
                                        getJSONObject("fields").
                                        getJSONObject("ime").getString("stringValue") +
                                        " "+ fi.
                                        getJSONObject("vrijednost").
                                        getJSONObject("mapValue").
                                        getJSONObject("fields").
                                        getJSONObject("procenat").getInt("integerValue")+" "+nazivKvizaa;
                                ranglista.add(igrac);

                            }
                        } catch (JSONException e) {
                        }
                    } catch (JSONException e) {
                        Log.d("MISTAKEEE", e.getMessage());
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return ranglista;
        }

        @Override
        protected void onPostExecute(ArrayList<String> ranglistaFirebase) {
            super.onPostExecute(ranglistaFirebase);

            ranglista = (ArrayList<String>) ranglistaFirebase.clone();
            for(String s : ranglistaFirebase){
                String[] arr = s.split(" ");
                pozicija = arr[0];
                naziv = arr[1];
                procenat = arr[2];
                idKvizaaa = arr[3];
                databaseHelper.createRedURangListi(idKvizaaa, naziv, procenat);
            }

            ArrayList<String> ranglistaDB = databaseHelper.dajCijeluRanglistu();

            if(ranglistaDB.size() > ranglistaFirebase.size()){
                for(int i=ranglistaFirebase.size(); i<ranglistaDB.size(); i++){
                    String s = ranglistaDB.get(i);
                    String[] arr = s.split(" ");
                    pozicija = arr[0];
                    naziv = arr[1];
                    procenat = arr[2];
                    idKvizaaa = arr[3];
                    new UpisiKorisnikaNaRangListuTask().execute("");
                }
            }
        }
    }

    public class UpisiKorisnikaNaRangListuTask extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;

            try{
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Rangliste?&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = " {"+
                        "\"fields\": {"+
                        "\"lista\": {"+
                        "\"mapValue\": {"+
                        "\"fields\": {"+
                        "\"pozicija\": {"+
                        "\"stringValue\": \""+ pozicija +"\""+
                        "},"+
                        "\"vrijednost\": {"+
                        "\"mapValue\": {"+
                        "\"fields\": {"+
                        "\"procenat\": {"+
                        "\"integerValue\": \""+Integer.valueOf(procenat)+"\""+
                        "},"+
                        "\"ime\": {"+
                        "\"stringValue\": \""+naziv+"\""+
                        "}}}}}}},"+
                        "\"nazivKviza\": {"+
                        "\"stringValue\": \""+idKvizaaa+"\""+
                        "}}}";

                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    public class CalendarHelper{
        public  final String[] EVENT_PROJECTION = new String[] {
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.ACCOUNT_NAME,
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.OWNER_ACCOUNT
        };

        private static final int PROJECTION_ID_INDEX = 0;
        private static final int PROJECTION_ACCOUNT_NAME_INDEX = 1;
        private static final int PROJECTION_DISPLAY_NAME_INDEX = 2;
        private static final int PROJECTION_OWNER_ACCOUNT_INDEX = 3;

        public int fetchCal(Kviz k){
            Cursor cur = null;
            ContentResolver cr = getContentResolver();
            Uri uri = CalendarContract.Events.CONTENT_URI;
            String selection = "((" + CalendarContract.Calendars.ACCOUNT_NAME + " = ?) AND ("
                    + CalendarContract.Calendars.ACCOUNT_TYPE + " = ?))";
            String[] selectionArgs = new String[] {"sejmakudic12@gmail.com", "com.google"};

            cur = getContentResolver().query(CalendarContract.Events.CONTENT_URI, null, selection, selectionArgs, null);
            ArrayList<Date> dates = new ArrayList<>();
            Date currentTime = Calendar.getInstance().getTime();
            Integer minute= 1;
            while(cur.moveToNext()){
                if(cur!=null){
                    int id_1 = cur.getColumnIndex(CalendarContract.Events._ID);
                    int id_2 = cur.getColumnIndex(CalendarContract.Events.TITLE);
                    int id_3 = cur.getColumnIndex(CalendarContract.Events.DTSTART);
                    String idValue = cur.getString(id_1);
                    String title = cur.getString(id_2);
                    String dateP = cur.getString(id_3);

                    long unixDateSeconds = cur.getLong(id_3);

                        Date date = new java.util.Date(unixDateSeconds);
                    if(date.getYear()==currentTime.getYear() && date.getMonth()==currentTime.getMonth()
                            && date.getDay()==currentTime.getDay() && date.getHours() >= currentTime.getHours() ) {
                        int y = date.getMinutes()-currentTime.getMinutes();
                        if(y < 0) continue;
                        if(y <= minute) {
                            dates.add(date);
                            return y;
                        }
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "no events found", Toast.LENGTH_LONG).show();
                }
            }
             return -1;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dataIntent) {
        super.onActivityResult(requestCode, resultCode, dataIntent);

        switch (requestCode)
        {
            case REQUEST_CODE_1:

                    if(dataIntent.getStringExtra("set").equals("true")) {
                        String dodanIgrac = dataIntent.getStringExtra("dodanIgrac");
                        String[] arr = dodanIgrac.split(" ");
                        databaseHelper.openDataBase();
                        databaseHelper.createRedURangListi(arr[0], arr[1], arr[2]);
                    }


        }
    }
}
