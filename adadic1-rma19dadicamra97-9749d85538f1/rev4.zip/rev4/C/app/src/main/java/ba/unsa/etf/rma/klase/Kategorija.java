package ba.unsa.etf.rma.klase;


import java.io.Serializable;

import ba.unsa.etf.rma.R;

public class Kategorija implements Serializable {
    public String naziv;
    public String id="-";
    public int imageSet=0;
    private int icon;

    public Kategorija(){
        imageSet = android.R.drawable.ic_input_add;

    }
    public Kategorija(String naziv, String id) {
        this.naziv = naziv;
        this.id = id;
        this.imageSet = 0;
    }

    public Kategorija(String naziv, String id, int image, int icon) {
        this.naziv = naziv;
        this.id = id;
        this.imageSet = image;
        this.icon = icon;
    }

    public int isImageSet() {
        return imageSet;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
        imageSet = 1;
    }

    public void setImageInd(int image) {
        this.imageSet = image;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return naziv;
    }
}
