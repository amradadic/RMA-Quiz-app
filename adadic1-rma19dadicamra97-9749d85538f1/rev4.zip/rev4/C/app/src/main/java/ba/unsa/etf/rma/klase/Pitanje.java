package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Pitanje implements Serializable {
    public String naziv;
    public String tekstPitanja;
    ArrayList<String> odgovori;
    public int image = 1;
    public boolean postavljen = false;
    String tacan;
    public int indexTacnog = -1;

    public Pitanje(){}
    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan, int indexTacnog, int image) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;



        this.image = image;
        this.indexTacnog = indexTacnog;
    }

    public boolean isPostavljen() {
        return postavljen;
    }

    public int getIndexTacnog() {
        return indexTacnog;
    }

    public void setIndexTacnog(int indexTacnog) {
        this.indexTacnog = indexTacnog;
    }

    public void setPostavljen(boolean postavljen) {
        this.postavljen = postavljen;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public ArrayList<String> dajRandomOdgovore(){
        ArrayList<String> temp = new ArrayList<>();


        temp.addAll(odgovori);
        Collections.shuffle(temp);
        return temp;
    }

    @Override
    public String toString() {
        return getNaziv();
    }
}
