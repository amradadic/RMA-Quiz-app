package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class CustomAdapter<T>  extends ArrayAdapter<T> {

    Context mContext;
    int resources;
    ArrayList<T> lista;
    ArrayList<Pitanje> pitanje;

    public CustomAdapter(Context context, int resources , ArrayList<T> lista) {

        super(context, resources, (ArrayList<T>) lista);

        this.mContext = context;
        this.resources = resources;
        this.lista = lista;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        convertView = inflater.inflate(R.layout.elementi_liste, parent, false);
        View view = inflater.inflate(R.layout.activity_main, null);


        TextView textView = (TextView) convertView.findViewById(R.id.textView);
        final ImageView image = (ImageView) convertView.findViewById(R.id.imageView4);

        if(lista.get(0) instanceof Kviz) {
            final Kviz kviz = (Kviz) lista.get(position);
            textView.setText(kviz.getNaziv());

            if(kviz.getKategorija() != null){
                    image.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_input_add));

            }
        }
        else if(lista.get(0) instanceof Pitanje){
            final Pitanje pitanje = (Pitanje) lista.get(position);
            textView.setText(pitanje.getNaziv());


                image.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_input_add));
        }
        else if(lista.get(0) instanceof String){
            textView.setText((String) lista.get(position));
            String s = (String) lista.get(position);
            if(s.charAt(0) == '1') {
                s = s.substring(1);
                textView.setBackgroundColor(Color.GREEN);
                textView.setText(s);
            }
            else textView.setText((String) lista.get(position));
            image.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_input_add));
        }
        return convertView;
    }
}

