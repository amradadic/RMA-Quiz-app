package ba.unsa.etf.rma.klase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Logcat tag
    private static final String LOG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "308829.db";

    // Table Names
    private static final String TABLE_KVIZOVI = "Kvizovi";
    private static final String TABLE_KATEGORIJE = "Kategorije";
    private static final String TABLE_KVIZOVI_PITANJA = "KvizoviPitanja";
    private static final String TABLE_PITANJA = "Pitanja";
    private static final String TABLE_PITANJA_ODGOVORI = "PitanjaOdgovori";
    private static final String TABLE_ODGOVORI = "Odgovori";
    private static final String TABLE_RANGLISTE = "Rangliste";
    private static final String TABLE_RANGLISTE_POZICIJE = "RanglistePozicije";
    private static final String TABLE_POZICIJE = "Pozicije";

    // Common column names
    private static final String NAZIV = "naziv";

    // Kategorije table - column names
    private static final String KATEGORIJA_ID = "_id";
        //Naziv
    private static final String ID_IKONICE = "idIkonice";

    // Kvizovi table - column names
    private static final String KVIZ_ID = "_id";
    private static final String ID_KATEGORIJE = "idKategorije";
        //NAZIV

    // Pitanja table - column names
    private static final String PITANJE_ID = "_id";
    private static final String INDEX_TACNOG = "indexTacnog";
    private static final String TEXT_PITANJA = "tekstPitanja";
    private static final String AKTIVAN = "aktivan";
        //NAZIV

    // Kvizovi_Pitanja table - column names
    private static final String KVIZOVI_PITANJA_ID = "_id";
    private static final String ID_KVIZA = "idKviza";
    private static final String ID_PITANJA = "idPitanja";

    // Odgovori table - column names
    private static final String ODGOVOR_ID = "_id";
    private static final String TEXT_ODGOVORA = "tekstOdgovora";

    // Pitanja_Odgovori table - column names
    private static final String PITANJE_ODGOVOR_ID = "_id";
                                //id_pitanje
    private static final String ID_ODGOVORA = "idOdgovora";

    // Rangliste table - column names
    private static final String ID_RANGLISTE = "_id";
                                //ID_KVIZA

    // POZICIJE table - column names
    private static final String ID_POZICIJE = "_id";
    private static final String NAZIV_IGRACA = "nazivIgraca";
    private static final String PROCENAT = "procenat";

    // Rangliste_Pozicije table - column names
    private static final String ID_RANGLISTA_POZICIJA = "_id";
    private static final String RANGLISTE_ID = "idRangliste";
    private static final String POZICIJE_ID = "idPozicije";

////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Table Kategorije Statements
    private static final String CREATE_TABLE_KATEGORIJE = "CREATE TABLE "
            + TABLE_KATEGORIJE + "(" + KATEGORIJA_ID + " INTEGER PRIMARY KEY,"
            + NAZIV + " TEXT,"
            +  ID_IKONICE + " INTEGER)";

    // Tag Kvizovi create statement
    private static final String CREATE_TABLE_KVIZOVI = "CREATE TABLE " + TABLE_KVIZOVI
            + "(" + KVIZ_ID + " INTEGER PRIMARY KEY,"
            + NAZIV + " TEXT,"
            + ID_KATEGORIJE + " INTEGER,"
            + "FOREIGN KEY("+ID_KATEGORIJE+") REFERENCES "+TABLE_KATEGORIJE+"("+KATEGORIJA_ID+")" + ")";


    // Pitanja table create statement
    private static final String CREATE_TABLE_PITANJA= "CREATE TABLE " + TABLE_PITANJA
            + "(" + PITANJE_ID + " INTEGER PRIMARY KEY,"
            + INDEX_TACNOG + " INTEGER,"
            + TEXT_PITANJA + " TEXT," +
            AKTIVAN + " TEXT )";

    //Kvizovi_Pitanja table
    private static final String CREATE_TABLE_KVIZOVI_PITANJA= "CREATE TABLE " + TABLE_KVIZOVI_PITANJA
            + "(" + KVIZOVI_PITANJA_ID + " INTEGER PRIMARY KEY,"
            + ID_KVIZA + " INTEGER,"
            + ID_PITANJA + " INTEGER,"
            + "FOREIGN KEY("+ID_KVIZA+") REFERENCES "+TABLE_KVIZOVI+"("+ID_KVIZA+"),"
            + "FOREIGN KEY("+ID_PITANJA+") REFERENCES "+TABLE_PITANJA+"("+ID_PITANJA+")"
            +" )";

    //Odgovori table
    private static final String CREATE_TABLE_ODGOVORI = "CREATE TABLE "
            + TABLE_ODGOVORI + "(" + ODGOVOR_ID + " INTEGER PRIMARY KEY,"
            + TEXT_ODGOVORA + " TEXT)";

    //Pitanja_Odgovori table
    private static final String CREATE_TABLE_PITANJA_ODGOVORI= "CREATE TABLE " + TABLE_PITANJA_ODGOVORI
            + "(" + PITANJE_ODGOVOR_ID + " INTEGER PRIMARY KEY,"
            + ID_PITANJA + " INTEGER,"
            + ID_ODGOVORA + " INTEGER,"
            + "FOREIGN KEY("+ID_PITANJA+") REFERENCES "+TABLE_PITANJA+"("+ID_PITANJA+"),"
            + "FOREIGN KEY("+ID_ODGOVORA+") REFERENCES "+TABLE_ODGOVORI+"("+ID_ODGOVORA+")"
            +" )";

    //RANGLISTE table
    private static final String CREATE_TABLE_RANGLISTE= "CREATE TABLE "
            + TABLE_RANGLISTE + "(" + ID_RANGLISTE + " INTEGER PRIMARY KEY,"
            + ID_KVIZA + " INTEGER,"
            + "FOREIGN KEY("+ID_KVIZA+") REFERENCES "+TABLE_KVIZOVI+"("+ID_KVIZA+")" + ")";


    //POZICIJE table
    private static final String CREATE_TABLE_POZICIJE= "CREATE TABLE "
            + TABLE_POZICIJE + "(" + ID_POZICIJE + " INTEGER PRIMARY KEY,"
            + NAZIV_IGRACA + " TEXT,"
            + PROCENAT + " INTEGER)";

    //Rangliste_Pozicije table
    private static final String CREATE_TABLE_RANLISTE_POZICIJE= "CREATE TABLE " + TABLE_RANGLISTE_POZICIJE
            + "(" + ID_RANGLISTA_POZICIJA + " INTEGER PRIMARY KEY,"
            + RANGLISTE_ID + " INTEGER,"
            + POZICIJE_ID + " INTEGER,"
            + "FOREIGN KEY("+RANGLISTE_ID+") REFERENCES "+TABLE_RANGLISTE+"("+RANGLISTE_ID+"),"
            + "FOREIGN KEY("+POZICIJE_ID+") REFERENCES "+TABLE_POZICIJE+"("+POZICIJE_ID+")"
            +" )";




    /*public DatabaseHelper(Context context, String DATABASE_NAME) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }*/
    private static String TAG = "DataBaseHelper"; // Tag just for the LogCat window
    //destination path (location) of our database on device
    private static String DB_PATH = "/data/data/ba.unsa.etf.rma/databases/";
    private static String DB_NAME = "nova.db";
    private SQLiteDatabase myDataBase;
    private final Context myContext;

    public DatabaseHelper(Context context)
    {
        super(context, DB_NAME, null, 1);
        this.myContext = context;
       // Log.d("BAZINCONTEXT", context.toString()+" "+context.getPackageName());
        Log.d("IZBAZE", "KONSTRUKTOR");
    }

    public void createDataBase() throws IOException
    {
        Log.d("IZBAZE", "CREATEDB");
        Log.d("DB_PATH", DB_PATH);
        Log.d("DB_NAME", DB_NAME);
        kreirajBazu();

    }

    public void kopirajIzLokalne(){
        File staraBaza = new File("/data/data/ba.unsa.etf.rma/databases/nova.db");
        Log.d("DB_PATH", DB_PATH);
        Log.d("DB_NAME", DB_NAME);

        if(staraBaza.exists()){
            Log.d("BAZA", "POSTOJI");
            kreirajBazu();
            try {
                copyDataBase();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else{
            Log.d("IZBAZE", "LOKALNANEPOSTOJI");
        }
    }
    public void kopirajDBizAssets(){
        Log.d("BAZAIME", DB_NAME);
        Log.d("BAZA", "NEPOSTOJI");
        kreirajBazu();
        try {
            copyDataBaseFromAssets();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void copyDataBaseFromAssets() throws IOException {
        Log.d("KOPIRAM", "IZASSETS");

        InputStream myInput = myContext.getAssets().open("DBzaAssets.db");
                //new FileInputStream(stara);
        // Path to the just created empty db
        String outFileName = DB_PATH + DB_NAME;

        // Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);

        // transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }

        // Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();
        Log.d("BAZA", "KOPIRANA");
    }
    //Copy the database from assets
    private void copyDataBase() throws IOException {
        Log.d("IZBAZE", "COPY");
        // Open your local db as the input stream
        File stara;
        if(DB_NAME.equals("va.db"))
             stara =  new File(DB_PATH + "no"+DB_NAME);
        else {
             stara = new File(DB_PATH + DB_NAME);
            DB_NAME="va.db";
        }
        InputStream myInput = //myContext.getAssets().open("novaBaz.db");
                new FileInputStream(stara);
        // Path to the just created empty db
        String outFileName = DB_PATH + DB_NAME;

        // Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);

        // transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }

        // Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();
        Log.d("BAZA", "KOPIRANA");
        File nova =  new File(DB_PATH +DB_NAME);
        nova.renameTo(stara);
        DB_NAME = "nova.db";
        //stara.delete();
    }

    public void openDataBase() throws SQLException {
        Log.d("IZBAZE", "OPENDATEBSAE");
        String myPath = DB_PATH + DB_NAME;
        Log.d("OVO OTVARAM", myPath);
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
        Log.d("BAZA", "OTVORENA");
    }
    @Override
    public synchronized void close() {
        Log.d("IZBAZE", "CLOSE");
        if (myDataBase != null)
            myDataBase.close();
        super.close();
    }

    public SQLiteDatabase dajBazu(){
        return myDataBase;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("IZBAZE", "ONCREATE");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("IZBAZE", "ONUPGRADE");
    }

    public void kreirajBazu(){
        Log.d("IZBAZE", "KREIRAMBAZU");
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_KATEGORIJE);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_KVIZOVI);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_KVIZOVI_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_ODGOVORI);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_PITANJA_ODGOVORI);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_RANGLISTE);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_POZICIJE);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_RANGLISTE_POZICIJE);
        // creating required tables
        db.execSQL(CREATE_TABLE_KATEGORIJE);
        db.execSQL(CREATE_TABLE_KVIZOVI);
        db.execSQL(CREATE_TABLE_PITANJA);
        db.execSQL(CREATE_TABLE_KVIZOVI_PITANJA);
        db.execSQL(CREATE_TABLE_ODGOVORI);
        db.execSQL(CREATE_TABLE_PITANJA_ODGOVORI);
        db.execSQL(CREATE_TABLE_RANGLISTE);
        db.execSQL(CREATE_TABLE_POZICIJE);
        db.execSQL(CREATE_TABLE_RANLISTE_POZICIJE);
        Log.d("BAZA", "KREIRANA");
        //db.setVersion(db.getVersion()+5);
    }

    public long createKategoriju(Kategorija kategorija) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KATEGORIJA_ID, kategorija.getId());
        values.put(NAZIV, kategorija.getNaziv());
        values.put(ID_IKONICE, kategorija.getIcon());

        // insert row
        long kat_id = db.insert(TABLE_KATEGORIJE, null, values);

        return kat_id;
    }

    public long createKviz(Kviz kviz) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KVIZ_ID, kviz.getIdKviza());
        values.put(NAZIV, kviz.getNaziv());
        values.put(ID_KATEGORIJE, kviz.getKategorija().getId());//kviz.getKategorija().getId());

        // insert row
        long kat_id = db.insert(TABLE_KVIZOVI, null, values);

        Log.d("vel odgovora", String.valueOf(kviz.getPitanja().size()));

        for(int i=0; i<kviz.getPitanja().size(); i++){
            createPitanje(kviz.getPitanja().get(i), true);
            poveziKvizovePitanja(kviz, kviz.getPitanja().get(i));
        }
        return kat_id;
    }

    public long createPitanje(Pitanje pitanje, Boolean aktivan) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(PITANJE_ID, pitanje.getNaziv());
        values.put(INDEX_TACNOG, pitanje.getIndexTacnog());
        Log.d("tekst pitanja", pitanje.getTekstPitanja());
        values.put(TEXT_PITANJA, pitanje.getTekstPitanja());
        if(aktivan)
            values.put(AKTIVAN, "true");
        else
            values.put(AKTIVAN, "false");
        // insert row
        long kat_id = db.insert(TABLE_PITANJA, null, values);

        // assigning tags to

        long[] indexiOdgovora = new long[100];
        for(int i=0; i<pitanje.getOdgovori().size(); i++){
            indexiOdgovora[i] = createOdgovor(pitanje.getOdgovori().get(i));
        }

        for (int i=0; i<pitanje.getOdgovori().size(); i++) {
            poveziPitanjaOdgovore(pitanje, indexiOdgovora[i]);
        }

        return kat_id;
    }

    public void poveziKvizovePitanja(Kviz kviz, Pitanje p) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID_KVIZA, kviz.getIdKviza());
        values.put(ID_PITANJA, p.getNaziv());

        // insert row
        long kat_id = db.insert(TABLE_KVIZOVI_PITANJA, null, values);

    }

    public void poveziPitanjaOdgovore(Pitanje p, long idOdgovora) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID_ODGOVORA, idOdgovora);
        values.put(ID_PITANJA, p.getNaziv());

        // insert row
        long kat_id = db.insert(TABLE_PITANJA_ODGOVORI, null, values);
    }

    public long createOdgovor(String textOdgovora) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TEXT_ODGOVORA, textOdgovora);

        // insert row
        long kat_id = db.insert(TABLE_ODGOVORI, null, values);

        return kat_id;
    }

    public long createRedURangListi(String idKviza, String nazivIgraca, String procenat) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d("PRAVIM", "REDURANGLIST");
        Log.d("DBNAMEUKOJUUBACUJEM", db.getPath());
        ContentValues values = new ContentValues();
        values.put(ID_KVIZA, idKviza);

        long rang_id = db.insert(TABLE_RANGLISTE, null, values);

        createPoziciju(rang_id, nazivIgraca, procenat);
        return rang_id;
    }
    public long createPoziciju(long rang_id, String nazivIgraca, String procenat){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAZIV_IGRACA, nazivIgraca);
        values.put(PROCENAT, procenat);

        long poz_id = db.insert(TABLE_POZICIJE, null, values);

        createRangPozicija(rang_id, poz_id);
        return poz_id;
    }

    public void createRangPozicija(long rang_id, long poz_id){
        SQLiteDatabase db = this.getWritableDatabase();
        if(!db.isOpen())
            Log.d("BAZA", "NIJEOTVORENA");
        else
            Log.d("BAZA", db.toString());
        ContentValues values = new ContentValues();
        values.put(RANGLISTE_ID, rang_id);
        values.put(POZICIJE_ID, poz_id);

        db.insert(TABLE_RANGLISTE_POZICIJE, null, values);
        Log.d("KREIRAM", "POZICIJU");
    }

    public ArrayList<String> dajRanglistu(int KvizID){
        ArrayList<String> ranglista = new ArrayList<>();
        String selectAllQuery = "SELECT p."+ID_POZICIJE+",p."+NAZIV_IGRACA+", p."+PROCENAT+"" +
                "  FROM "+TABLE_POZICIJE+" p, " + TABLE_RANGLISTE +" r," + TABLE_RANGLISTE_POZICIJE + " rp "+
                " WHERE r."+ID_RANGLISTE+"=rp."+RANGLISTE_ID+" AND p."+ID_POZICIJE+"=rp."+POZICIJE_ID +
                " AND r."+ID_KVIZA+"="+KvizID;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                String novi = new String();
                novi = c.getString(c.getColumnIndex(ID_POZICIJE))+"  | "+
                        c.getString(c.getColumnIndex(NAZIV_IGRACA))+"   "+
                        c.getString(c.getColumnIndex(PROCENAT));
                ranglista.add(novi);
            } while (c.moveToNext());
        }
        Log.d("VRACENOrangliste", String.valueOf(ranglista.size()));
        return ranglista;
    }

    public ArrayList<String> dajCijeluRanglistu(){
        ArrayList<String> ranglista= new ArrayList<>();
        String selectAllQuery = "SELECT p."+ID_POZICIJE+",p."+NAZIV_IGRACA+", p."+PROCENAT+"" + ", r." + ID_KVIZA +
                "  FROM "+TABLE_POZICIJE+" p, " + TABLE_RANGLISTE +" r," + TABLE_RANGLISTE_POZICIJE + " rp "+
                " WHERE r."+ID_RANGLISTE+"=rp."+RANGLISTE_ID+" AND p."+ID_POZICIJE+"=rp."+POZICIJE_ID;

        Log.d("ovaj query", selectAllQuery);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                String novi = new String();
                novi = c.getString(c.getColumnIndex(NAZIV_IGRACA)) + " " + c.getString(c.getColumnIndex(PROCENAT)) +
                            " " + c.getString(c.getColumnIndex(ID_POZICIJE)) +
                             " " + c.getString(c.getColumnIndex(ID_KVIZA));
                ranglista.add(novi);
            } while (c.moveToNext());
        }
        return ranglista;
    }
    public ArrayList<Kategorija> dajKategorije(){
        ArrayList<Kategorija> kategorije= new ArrayList<>();

        String selectAllQuery = "SELECT * FROM " + TABLE_KATEGORIJE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                Kategorija novaKat = new Kategorija();
                novaKat.setId(c.getString(c.getColumnIndex(KATEGORIJA_ID)));
                novaKat.setNaziv(c.getString(c.getColumnIndex(NAZIV)));
                novaKat.setImageInd(1);
                novaKat.setIcon(c.getInt(c.getColumnIndex(ID_IKONICE)));
                kategorije.add(novaKat);
            } while (c.moveToNext());
        }
        Log.d("VRACENOKATEGORIJA", String.valueOf(kategorije.size()));
        return kategorije;
    }


    public ArrayList<Kviz> dajKvizove(Kategorija kategorija){
        ArrayList<Kviz> kvizovi= new ArrayList<>();

        String selectAllQuery = "SELECT * FROM " + TABLE_KVIZOVI +" k"+
                " WHERE k."+ID_KATEGORIJE+"="+kategorija.getId();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                Kviz novi = new Kviz();
                novi.setIdKviza(c.getInt(c.getColumnIndex(KVIZ_ID)));
                novi.setNaziv(c.getString(c.getColumnIndex(NAZIV)));
                novi.setIdKategorije(String.valueOf(c.getInt(c.getColumnIndex(ID_KATEGORIJE))));
                novi.setPitanja(dajPitanjaKviza(novi.getIdKviza()));
                novi.setIndicator(1);
                novi.setImage(17);
                novi.setKategorija(kategorija);
                kvizovi.add(novi);
            } while (c.moveToNext());
        }
        return kvizovi;
    }

    public ArrayList<Kviz> dajSveKvizove(){
        ArrayList<Kviz> kvizovi= new ArrayList<>();

        String selectAllQuery = "SELECT * FROM " + TABLE_KVIZOVI;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                Kviz novi = new Kviz();
                novi.setIdKviza(c.getInt(c.getColumnIndex(KVIZ_ID)));
                novi.setNaziv(c.getString(c.getColumnIndex(NAZIV)));
                novi.setIdKategorije(String.valueOf(c.getInt(c.getColumnIndex(ID_KATEGORIJE))));
                novi.setPitanja(dajPitanjaKviza(novi.getIdKviza()));
                novi.setIndicator(1);
                novi.setImage(17);
                kvizovi.add(novi);
            } while (c.moveToNext());
        }
        return kvizovi;
    }

    public ArrayList<Pitanje> dajPitanjaKviza(int idKviza){
        ArrayList<Pitanje> pitanja= new ArrayList<>();

        String selectAllQuery = "SELECT p."+PITANJE_ID+",p."+INDEX_TACNOG+",p."+TEXT_PITANJA
                +" FROM " + TABLE_KVIZOVI_PITANJA + " kp," + TABLE_PITANJA + " p " +
                "where kp."+ID_KVIZA+ "="+idKviza+" AND kp."+ID_PITANJA+"=p."+PITANJE_ID;

        Log.d("QUERY", selectAllQuery);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                Pitanje novi = new Pitanje();
                novi.setNaziv(c.getString(c.getColumnIndex(PITANJE_ID)));
                novi.setIndexTacnog(c.getInt(c.getColumnIndex(INDEX_TACNOG)));
                novi.setTekstPitanja(c.getString(c.getColumnIndex(TEXT_PITANJA)));
                novi.setOdgovori(dajOdgovoreZaOdgPitanje(Integer.parseInt(novi.getNaziv())));
                pitanja.add(novi);
            } while (c.moveToNext());
        }
        Log.d("DOHVACENO", String.valueOf(pitanja.size()));
        return pitanja;
    }

    public ArrayList<Pitanje> dajMogucaPitanja(){
        ArrayList<Pitanje> pitanja= new ArrayList<>();

        String selectAllQuery = "SELECT p."+PITANJE_ID+",p."+INDEX_TACNOG+",p."+TEXT_PITANJA
                +" FROM " + TABLE_PITANJA + " p " +
                "where p."+AKTIVAN+ "='false'";

        Log.d("QUERY", selectAllQuery);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                Pitanje novi = new Pitanje();
                novi.setNaziv(c.getString(c.getColumnIndex(PITANJE_ID)));
                novi.setIndexTacnog(c.getInt(c.getColumnIndex(INDEX_TACNOG)));
                novi.setTekstPitanja(c.getString(c.getColumnIndex(TEXT_PITANJA)));
                novi.setOdgovori(dajOdgovoreZaOdgPitanje(Integer.parseInt(novi.getNaziv())));
                pitanja.add(novi);
            } while (c.moveToNext());
        }
        Log.d("DOHVACENO mogucih", String.valueOf(pitanja.size()));
        return pitanja;
    }

    public ArrayList<String> dajOdgovoreZaOdgPitanje(int idPitanja){
        ArrayList<String> odgovori= new ArrayList<>();

        String selectAllQuery = "SELECT o."+TEXT_ODGOVORA
                +" FROM " + TABLE_ODGOVORI + " o," + TABLE_PITANJA_ODGOVORI + " po " +
                "where po."+ID_PITANJA+ "="+idPitanja+" AND po."+ID_ODGOVORA+"=o."+ODGOVOR_ID;

        Log.d("QUERY odg", selectAllQuery);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectAllQuery, null);

        if(c.moveToFirst()){
            do{
                String novi;
                novi = c.getString(c.getColumnIndex(TEXT_ODGOVORA));
                odgovori.add(novi);
            } while (c.moveToNext());
        }
        Log.d("DOHVACENO odgovora", String.valueOf(odgovori.size()));
        return odgovori;
    }
}
