package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CustomAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity {


    public ArrayList<Kategorija> kategorije;
    public ArrayList<Pitanje> listaMogucihPitanja;


    public HashMap<Kategorija, ArrayList<Kviz>> mapaKvizova;
    public HashMap<Kategorija, Boolean> mapaKategorija;
    public HashMap<Kategorija, Integer> mapaIdKategorija;
    public int ukupanBrojPitanja = 0;
    public int ukupanBrojKvizova = 0;
    public ArrayList<Pitanje> listaDodanihPitanja;
    public ArrayList<Kviz> kvizovi;
    public Kviz kviz;
    public Button button;
    public int pozicija, postavljeni =4;
    public Kategorija kategorijaKviza;
    public int ukupanBrojKategorija = 0;
    public Pitanje odabranoPitanje;

    public Spinner spinner;
    public EditText editText;
    public ListView dodanaPitanja;
    public ListView mogucaPitanja;








    public String tempEdit;
    public Uri URI;
    public boolean inputError = false, edit=false, postavljenaKategorija=false, neispravanImport=false;
    public boolean neispravanIndex=false, neispravanBrOdg=false, uriPostavljen =false;
    public CustomAdapter<Pitanje> adapter, adapter2;
    public ArrayAdapter<Kategorija> adapterZaSpinner;
    private final static int REQUEST_CODE_1 = 1;
    private static final int READ_REQUEST_CODE = 42;
    public Context context2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        odabranoPitanje = new Pitanje();



        kategorije = new ArrayList<>();




        kategorije.addAll((ArrayList<Kategorija>) getIntent().getSerializableExtra("Kategorije"));


        spinner = (Spinner) findViewById(R.id.spKategorije);

        new EditujProba().execute("");

        Intent intent2 = getIntent();
        Bundle bundle2 = intent2.getExtras();
        context2 = this;
        if(bundle2 != null && bundle2.containsKey("Postavljeni"))
            postavljeni = bundle2.getInt("Postavljeni");
        adapterZaSpinner = new ArrayAdapter<Kategorija>(this,
                android.R.layout.simple_spinner_item, kategorije){
            @Override
            public boolean isEnabled(int position){
                if(position == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if(position == 0){
                    tv.setTextColor(Color.GRAY);
                }
                else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };

        adapterZaSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapterZaSpinner);


        editText = (EditText) findViewById(R.id.etNaziv);
        dodanaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        mogucaPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);
        button = (Button) findViewById(R.id.btnDodajKviz);


        mapaKategorija = new HashMap<>();
        mapaKvizova = new HashMap<>();
        mapaIdKategorija = new HashMap<>();
        ukupanBrojPitanja = getIntent().getIntExtra("ukupanBrojPitanja", 0);
        ukupanBrojKategorija = getIntent().getIntExtra("ukupanBrojKategorija", 0);
        ukupanBrojKvizova =  getIntent().getIntExtra("ukupanBrojKvizova", 0);
        mapaIdKategorija = (HashMap<Kategorija, Integer>) getIntent().getSerializableExtra("mapaIdKategorija");
        mapaKvizova = (HashMap<Kategorija, ArrayList<Kviz>>) getIntent().getSerializableExtra("mapaKvizova");
        mapaKategorija = (HashMap<Kategorija, Boolean>) getIntent().getSerializableExtra("mapaKategorija");




        listaMogucihPitanja = new ArrayList<>();
        listaMogucihPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("DodatnaPitanja");
        adapter2 = new CustomAdapter<>(this, R.layout.elementi_liste, listaMogucihPitanja);
        mogucaPitanja.setAdapter(adapter2);
        adapter2.notifyDataSetChanged();

        kvizovi = (ArrayList<Kviz>) ((ArrayList<Kviz>) getIntent().getSerializableExtra("Kvizovi")).clone();

        listaDodanihPitanja = new ArrayList<>();

         tempEdit = (String) getIntent().getStringExtra("Edit");
        if(tempEdit.equals("true"))
            edit = true;

        if(edit){
            kviz = (Kviz) getIntent().getSerializableExtra("Kviz");
            pozicija = getIntent().getIntExtra("Pozicija", -1);
            editText.setText(kviz.getNaziv());

            adapter = new CustomAdapter<>(this, R.layout.elementi_liste,
                    kviz.getPitanja());
            dodanaPitanja.setAdapter(adapter);
            adapter.notifyDataSetChanged();


        }
        else {

            kviz = new Kviz();
            listaDodanihPitanja.add(new Pitanje("Dodaj Pitanje",
                    null, null, null, -1, android.R.drawable.ic_input_add));
            kviz.setPitanja(listaDodanihPitanja);
            adapter = new CustomAdapter<>(this, R.layout.elementi_liste,
                    listaDodanihPitanja);


            dodanaPitanja.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras.containsKey("DodanaPitanja")) {
            listaDodanihPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("DodanaPitanja");
            kviz.getPitanja().removeAll(kviz.getPitanja());
            kviz.setPitanja(listaDodanihPitanja);
            adapter = new CustomAdapter<>(this, R.layout.elementi_liste,
                    listaDodanihPitanja);
            dodanaPitanja.setAdapter(adapter);
        }

        dodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position < kviz.getPitanja().size()-1) {

                    listaMogucihPitanja.add(kviz.getPitanja().get(position));

                    adapter2.notifyDataSetChanged();

                    kviz.getPitanja().remove(position);

                    listaDodanihPitanja.remove(position);





                    if(listaDodanihPitanja.size()>0 && !listaDodanihPitanja.get(listaDodanihPitanja.size()-1).
                                    getNaziv().equals("Dodaj Pitanje"))
                        listaDodanihPitanja.add(new Pitanje("Dodaj Pitanje",
                            null, null, null, -1,android.R.drawable.ic_input_add));
                    adapter = new CustomAdapter<>(getApplicationContext(), R.layout.elementi_liste,
                            listaDodanihPitanja);
                    dodanaPitanja.setAdapter(adapter);
                }
                else{


                    //sending INTENT
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    intent.putExtra("Kviz", kviz);
                    intent.putExtra("Kategorije", kategorije);
                    listaDodanihPitanja = kviz.getPitanja();
                    intent.putExtra("MogucaPitanja", listaMogucihPitanja);
                    kvizovi.size();
                    intent.putExtra("Postavljeni", postavljeni);
                    intent.putExtra("Kvizovi", kvizovi);
                    intent.putExtra("Edit", tempEdit);
                    intent.putExtra("Pozicija", pozicija);
                    intent.putExtra("mapaIdKategorija", mapaIdKategorija);
                    intent.putExtra("mapaKategorija", mapaKategorija);
                    intent.putExtra("DodanaPitanja", listaDodanihPitanja);
                    intent.putExtra("mapaKvizova", mapaKvizova);
                    intent.putExtra("ukupanBrojPitanja", ukupanBrojPitanja);
                    intent.putExtra("ukupanBrojKategorija", ukupanBrojKategorija);
                    intent.putExtra("ukupanBrojKvizova", ukupanBrojKvizova);






                    DodajKvizAkt.this.startActivity(intent);
                }
            }
        });

        mogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                kviz.getPitanja().remove(kviz.getPitanja().size()-1);
                listaMogucihPitanja.get(position).setImage(android.R.drawable.ic_input_add);
                kviz.getPitanja().add(listaMogucihPitanja.get(position));

                kviz.getPitanja().add(
                        new Pitanje("Dodaj Pitanje", null, null, null, -1, android.R.drawable.ic_input_add));
                adapter.notifyDataSetChanged();
                listaMogucihPitanja.remove(position);
                adapter2.notifyDataSetChanged();
            }
        });
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputError = false;
                if(editText.getText().toString().equals("")){
                    editText.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                    inputError = true;
                }
                /*if(kviz.getPitanja().size()==1){
                    dodanaPitanja.setBackgroundColor(Color.RED);
                    inputError = true;
                }*/
                if(!postavljenaKategorija){
                    spinner.setBackgroundColor(Color.RED);
                    inputError = true;
                }
                for(Kviz k: kvizovi)
                    if(k.getNaziv().equals(editText.getText().toString())){
                        inputError=true;
                        editText.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                    }

                if(!inputError){

                    kviz.setNaziv(editText.getText().toString());
                    kviz.setKategorija(kategorijaKviza);
                    kviz.setIdKategorije(kategorijaKviza.getId());
                    if(edit) {
                        kvizovi.remove(pozicija);
                        kvizovi.add(pozicija, kviz);
                        new EditujKvizTask().execute("");
                    }
                    else{
                        Kviz temppp = kvizovi.get(kvizovi.size()-1);
                        kvizovi.remove(kvizovi.size()-1);
                        kvizovi.add(kviz);
                        kvizovi.add(temppp);

                        new KreirajKvizTask().execute(kviz.getNaziv());

                        Handler handler = new Handler();
                        handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                for (int k=0; k < kviz.getPitanja().size()-1; k++) {
                                    odabranoPitanje = kviz.getPitanja().get(k);
                                     new KreirajPitanjeTask().execute("pitanje");
                                }
                            }
                        }, 2000);
                    }

                    Intent intent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    intent.putExtra("Kategorije", kategorije);
                    intent.putExtra("MogucaPitanja", listaMogucihPitanja);

                    intent.putExtra("Pozicija", pozicija);
                    intent.putExtra("mapaIdKategorija", mapaIdKategorija);
                    intent.putExtra("mapaKategorija", mapaKategorija);





                    intent.putExtra("mapaKvizova", mapaKvizova);
                    intent.putExtra("ukupanBrojPitanja", ukupanBrojPitanja);
                    intent.putExtra("ukupanBrojKategorija", ukupanBrojKategorija);
                    intent.putExtra("ukupanBrojKvizova", ukupanBrojKvizova);
                    intent.putExtra("DodanaPitanja", listaDodanihPitanja);




                    intent.putExtra("Kvizovi", kvizovi);
                    intent.putExtra("Edit", edit);
                    intent.putExtra("Kviz", kviz);
                    intent.putExtra("Kvizovi", kvizovi);

                    kategorije.remove(kategorije.size()-1);
                    DodajKvizAkt.this.startActivity(intent);
                    finish();
                }
            }
        });

        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.getBackground().clearColorFilter();
                inputError = false;
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                spinner.setBackgroundColor(Color.WHITE);


                    if(position != 0){
                        postavljenaKategorija = true;
                        kategorijaKviza = kategorije.get(position);

                        adapterZaSpinner.notifyDataSetChanged();
                    }
                    postavljeni = position;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dataIntent) {
        super.onActivityResult(requestCode, resultCode, dataIntent);

        switch (requestCode)
        {
            case REQUEST_CODE_1:
                if(resultCode == RESULT_OK)
                {
                    Kategorija kategorija = (Kategorija) dataIntent.getSerializableExtra("kategorija");
                    Kategorija temp = kategorije.get(kategorije.size()-1);
                    Kategorija temp2 = kategorije.get(kategorije.size()-2);
                    kategorije.remove(kategorije.size()-1);
                    kategorije.remove(kategorije.size()-1);
                    kategorije.add(kategorija);
                    kategorije.add(temp2);
                    kategorije.add(temp);
                    kviz.setKategorija(kategorija);
                    adapterZaSpinner.notifyDataSetChanged();
                    spinner.setSelection(kategorije.size()-2);
                    kategorijaKviza = kategorija;
                    postavljenaKategorija=true;
                }

        }
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
        intent.putExtra("Kategorije", kategorije);
        intent.putExtra("MogucaPitanja", listaMogucihPitanja);



        intent.putExtra("mapaKategorija", mapaKategorija);
        intent.putExtra("mapaKvizova", mapaKvizova);
        intent.putExtra("Kvizovi", kvizovi);

        intent.putExtra("DodanaPitanja", listaDodanihPitanja);
        intent.putExtra("Kvizovi", kvizovi);
        intent.putExtra("Edit", edit);
        intent.putExtra("mapaIdKategorija", mapaIdKategorija);


        intent.putExtra("ukupanBrojPitanja", ukupanBrojPitanja);
        intent.putExtra("ukupanBrojKategorija", ukupanBrojKategorija);
        intent.putExtra("ukupanBrojKvizova", ukupanBrojKvizova);

        kategorije.remove(kategorije.size()-1);
        DodajKvizAkt.this.startActivity(intent);
        finish();
    }

    public class KreirajKvizTask extends AsyncTask<String, Void, Void> {


        //CREATING QUIZ TASK
        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;

            try{
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Kvizovi?documentId="+ ++ukupanBrojKvizova +"&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = "{" +
                        "\"fields\":{" +
                         "\"pitanja\" : {"+
                         "\"arrayValue\" : {";

                if(kviz.getPitanja().size() == 0){
                    dokument += "\"values\" : [";
                }
                else
                    for(int k=0; k < kviz.getPitanja().size()-1; k++){
                        dokument += "\"values\" : [{" +
                                "\"integerValue\": \""+kviz.getPitanja().get(k).getNaziv()+"\"},";
                    }
                dokument = dokument.substring(0, dokument.length()-1);

                dokument += "]}},"+
                   "\"naziv\" : {" +
                        "\"stringValue\": \""+kviz.getNaziv()+"\"" +
                        "}," +
                        "\"idKategorije\":{" +
                        "\"stringValue\": \""+kviz.getIdKategorije()+"\" }}}";

                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();



                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class KreirajPitanjeTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;

            try{
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Pitanja?documentId="+ ukupanBrojPitanja +"&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");







                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = "{" +
                        "\"fields\":{"+
                        "\"odgovori\" : {"+
                        "\"arrayValue\" : {" +
                        "\"values\" : [";

                for(String odgovor : odabranoPitanje.getOdgovori()){
                    dokument += "{" +
                            "\"stringValue\": \""+odgovor+"\"},";
                }
                dokument = dokument.substring(0, dokument.length()-1);

                dokument += "]}},"+
                        "\"naziv\" : {" +
                        "\"stringValue\": \""+odabranoPitanje.getNaziv()+"\"" +
                        "}," +
                        "\"indexTacnog\":{" +
                        "\"integerValue\": \""+odabranoPitanje.getIndexTacnog()+"\" }," +
                        "\"postavljen\":{" +
                        "\"booleanValue\": \""+"true"+"\" }" +
                        "}}";

                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();

                InputStream odgovor = conn.getInputStream();




                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class EditujKvizTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;

            try{
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Kvizovi/"+ kviz.getIdKviza() +"/?updateMask.fieldPaths=pitanja&" +
                        "updateMask.fieldPaths=naziv&updateMask.fieldPaths=idKategorije&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = "{" +
                        "\"fields\":{" +
                        "\"pitanja\" : {"+
                        "\"arrayValue\" : {";

                if(kviz.getPitanja().size() == 0){
                    dokument += "\"values\" : [";
                }
                else
                    for(int k=0; k < kviz.getPitanja().size()-1; k++){
                        dokument += "\"values\" : [{" +
                                "\"integerValue\": \""+kviz.getPitanja().get(k).getNaziv()+"\"},";
                    }
                dokument = dokument.substring(0, dokument.length()-1);

                dokument += "]}},"+
                        "\"naziv\" : {" +  "\"stringValue\": \""+kviz.getNaziv()+"\"" +
                        "}," +  "\"idKategorije\":{" +


                        "\"stringValue\": \""+kviz.getIdKategorije()+"\" }}}";

                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();



                    String responseLine = null;



                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class EditujProba extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;

            try{
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/ProbnaKolekcija/1/?updateMask.fieldPaths=naziv&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = "{" + "\"fields\":{" + "\"naziv\" : {"+
                        "\"stringValue\" : \"gljiva\"}}}";

                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();

                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
