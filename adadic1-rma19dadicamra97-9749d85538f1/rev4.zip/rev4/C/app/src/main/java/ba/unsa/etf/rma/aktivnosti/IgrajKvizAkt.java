package ba.unsa.etf.rma.aktivnosti;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;


public class IgrajKvizAkt extends AppCompatActivity
            implements PitanjeFrag.OnFragmentInteractionListener, InformacijeFrag.OnFragmentInteractionListener,
                        InformacijeFrag.FragmentCallback, RangLista.OnListFragmentInteractionListener{


    public Button button;
    public Kviz kviz;
    public int brojTacnihOdgovora, brojPreostalihPitanja;
    public double procenatTacnihOdg=0;
    public InformacijeFrag informacijeFrag;
    public PitanjeFrag pitanjeFrag;
    public int brojPitanja;
    public View view;
    public int pozicija=0;
    public ArrayList<Pitanje> pitanjes;
    public Configuration config;
    public FragmentManager fragmentManager;
    public FragmentTransaction fragmentTransaction;
    public boolean saveTransaction=true;
    public int ukupnoOdg=0;
    public int tacan = 0;
    public int tempBr=1;
    public EditText editText;
    public ArrayList<String> rangListaIgraci;
    public int ukupanBrojIgraca=0;
    public int pozicija1=0;
    public int procentat=0;
    public String Online;
    public ArrayList<String> ranglista;
    public String dodanIgrac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);


        config = getResources().getConfiguration();
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();

        informacijeFrag = new InformacijeFrag();
        pitanjeFrag = new PitanjeFrag();

        kviz = (Kviz) getIntent().getSerializableExtra("Kviz");
        Online = getIntent().getStringExtra("Online");
        ranglista = new ArrayList<>();
        dodanIgrac = "- - -";
        ranglista = (ArrayList<String>) (getIntent().getStringArrayListExtra("RANGLISTA")).clone();
        Random rand = new Random();
        int n = rand.nextInt(500000);

        brojPreostalihPitanja = kviz.getPitanja().size()-1;
        brojTacnihOdgovora = 0;


        if(kviz.getPitanja().size()>0) {
            Date currentTime = Calendar.getInstance().getTime();
            Integer hour = currentTime.getHours();
            Integer minute;// = currentTime.getMinutes() + Math.round(kviz.getPitanja().size()/2);
            if(currentTime.getMinutes() == 59){
                minute = 0;
                hour++;
            }
            else minute = currentTime.getMinutes()+1;

            minute += Math.round(kviz.getPitanja().size()/2);

            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Game over!");
            i.putExtra(AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    Intent intent2 = new Intent();
                    intent2.putExtra("dodanIgrac", dodanIgrac);
                    intent2.putExtra("set", "true");
                    setResult(RESULT_OK, intent2);
                    finish();
                }
            }, (minute*60*1000-(currentTime.getMinutes()*60+currentTime.getSeconds())*1000));
            startActivity(i);
        }

        postaviInfo(null);


        fragmentTransaction.add(R.id.informacijePlace, informacijeFrag);
        fragmentTransaction.replace(R.id.pitanjePlace, pitanjeFrag);


        if(kviz.getPitanja().size() == 0){
            brojPreostalihPitanja=0;
            procenatTacnihOdg = 0;

            config = getResources().getConfiguration();
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();

            informacijeFrag = new InformacijeFrag();
            pitanjeFrag = new PitanjeFrag();
            postaviInfo("kraj");

            if(saveTransaction) {
                fragmentTransaction.replace(R.id.informacijePlace, informacijeFrag);
                fragmentTransaction.replace(R.id.pitanjePlace, pitanjeFrag);
                fragmentTransaction.commit();
            }
        }
        else {

            /*timer*/
            brojPitanja = kviz.getPitanja().size();
            pitanjes = new ArrayList<>();
            pitanjes.addAll(kviz.getPitanja());
            Collections.shuffle(pitanjes);

            fragmentTransaction.commit();
        }


    }
    public void postaviInfo(String string){
        Bundle bundle = new Bundle();

        bundle.putInt("BrojPreostalihPitanja", brojPreostalihPitanja);
        bundle.putInt("BrojTacnihOdgovora", brojTacnihOdgovora);
        bundle.putDouble("procenat", procenatTacnihOdg);
        if(string != null && string.equals("kraj")){
            bundle.putString("Kraj", "yep");
            bundle.putString("Naziv", kviz.getNaziv());
        }
        else{
            bundle.putString("Naziv", kviz.getNaziv());
            bundle.putString("Kraj", "nope");
        }
        informacijeFrag.setArguments(bundle);
        pitanjeFrag.setArguments(bundle);
    }
    public ArrayList<String> getOdgovori(){

        Pitanje pitanje = pitanjes.get(pozicija);
        tacan = pitanje.getIndexTacnog();
        Boolean nasao = false;
        ukupnoOdg += pitanje.getOdgovori().size();
        ArrayList<String> temp = pitanje.dajRandomOdgovore();
            String tacanOdg = pitanje.getOdgovori().get(tacan);

            for (int i = 0; i < pitanje.getOdgovori().size(); i++) {
                if (temp.get(i).equals(tacanOdg)) {
                    tacan = i;
                    nasao = true;
                    break;
                }
            }
            if (!nasao)
                Toast.makeText(getApplicationContext(), "nisam nasao", Toast.LENGTH_SHORT).show();
       return temp;
    }

    public int dajTacan(){
        return tacan;
    }

    public String dajNaziv(){
        return pitanjes.get(pozicija).getTekstPitanja();
    }
    @Override
    public void onFragmentInteraction(String string) {
        if(string.equals("prekid")){
            saveTransaction = false;
            Intent intent2 = new Intent();
            intent2.putExtra("dodanIgrac", dodanIgrac);
            intent2.putExtra("set", "false");
            setResult(RESULT_OK, intent2);
            finish();
        }
        else if(string.equals("tacno")){
            brojTacnihOdgovora++;
        }
        else if(string.equals("kraj")){

            saveTransaction = false;
            fragmentTransaction.remove(informacijeFrag);
            fragmentTransaction.remove(pitanjeFrag);
            upisiNaRangListu();
        }
        next(string);
    }

    public void upisiNaRangListu(){
        AlertDialog.Builder alert = new AlertDialog.Builder(IgrajKvizAkt.this);
        View view2 = View.inflate(getApplicationContext(), R.layout.alert_dialog, null);

        editText = (EditText) view2.findViewById(R.id.imeRangLista);

        alert.setView(view2).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(!editText.getEditableText().equals("")){

                    if(Online.equals("True")) {
                        new UpisiKorisnikaNaRangListuTask().execute("");

                        ranglista.add(pozicija1+" "+editText.getEditableText().toString()+" "+String.valueOf(procenatTacnihOdg));
                        dodanIgrac = kviz.getIdKviza()+" "+editText.getEditableText().toString()+" "+String.valueOf(procenatTacnihOdg);
                    }
                    else {
                        ranglista.add(pozicija1 + " " + editText.getEditableText().toString() + " " + String.valueOf(procenatTacnihOdg));
                        dodanIgrac = kviz.getIdKviza() + " " + editText.getEditableText().toString() + " " + String.valueOf(procenatTacnihOdg);

                    }
                        rangListaIgraci = ranglista;
                        ukupanBrojIgraca = rangListaIgraci.size();

                        RangLista rangLista = new RangLista();
                        config = getResources().getConfiguration();
                        fragmentManager = getSupportFragmentManager();
                        fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.remove(pitanjeFrag);
                        fragmentTransaction.remove(informacijeFrag);
                        fragmentTransaction.add(R.id.ranglista, rangLista);
                        Bundle bundle = new Bundle();
                        bundle.putStringArrayList("lista", rangListaIgraci);
                        rangLista.setArguments(bundle);
                        fragmentTransaction.commit();

                }
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Intent intent2 = new Intent();
                intent2.putExtra("dodanIgrac", dodanIgrac);
                intent2.putExtra("set", "false");
                setResult(RESULT_OK, intent2);
                finish();
            }
        });

        AlertDialog a = alert.create();
        a.show();
    }

    @Override
    public void onClickButton(InformacijeFrag fragment) {
        Toast.makeText(getApplicationContext(), "ppp", Toast.LENGTH_SHORT).show();
    }

    public void next(final String string){
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                if(--brojPitanja > 0){

                    brojPreostalihPitanja--;
                        pozicija++;

                    procenatTacnihOdg = (double)brojTacnihOdgovora/(double)tempBr;
                    tempBr++;
                    config = getResources().getConfiguration();
                    fragmentManager = getSupportFragmentManager();
                    fragmentTransaction = fragmentManager.beginTransaction();


                    informacijeFrag = new InformacijeFrag();
                    pitanjeFrag = new PitanjeFrag();
                    postaviInfo(null);

                    if(saveTransaction) {
                        fragmentTransaction.replace(R.id.informacijePlace, informacijeFrag);
                        fragmentTransaction.replace(R.id.pitanjePlace, pitanjeFrag);
                        fragmentTransaction.commit();
                    }

                }
                else{
                    procenatTacnihOdg = (double)brojTacnihOdgovora/(double)tempBr;
                    config = getResources().getConfiguration();
                    fragmentManager = getSupportFragmentManager();
                    fragmentTransaction = fragmentManager.beginTransaction();

                    informacijeFrag = new InformacijeFrag();
                    pitanjeFrag = new PitanjeFrag();
                    postaviInfo("kraj");

                    if(saveTransaction) {
                        fragmentTransaction.replace(R.id.informacijePlace, informacijeFrag);
                        fragmentTransaction.replace(R.id.pitanjePlace, pitanjeFrag);
                        fragmentTransaction.commit();
                    }
                }
            }
        }, 2000);
    }


    @Override
    public void onListFragmentInteraction(String item) {

    }

    public class UpisiKorisnikaNaRangListuTask extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;

            try{
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents/Rangliste?&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = " {"+
                        "\"fields\": {"+
                            "\"lista\": {"+
                                "\"mapValue\": {"+
                                "\"fields\": {"+
                                "\"pozicija\": {"+
                                "\"stringValue\": \""+ ++pozicija1 +"\""+
                                "},"+
                                "\"vrijednost\": {"+
                                "\"mapValue\": {"+
                                "\"fields\": {"+
                                "\"procenat\": {"+
                                "\"integerValue\": \""+(int)procenatTacnihOdg+"\""+
                            "},"+
                            "\"ime\": {"+
                                "\"stringValue\": \""+editText.getEditableText().toString()+"\""+
                            "}}}}}}},"+
                            "\"nazivKviza\": {"+
                                "\"stringValue\": \""+kviz.getIdKviza()+"\""+
                        "}}}";

                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    public class DohvatiRangListu extends AsyncTask<String, Void, ArrayList<String>>{

        @Override
        protected ArrayList<String> doInBackground(String... strings) {

            GoogleCredential credentials;
            ArrayList<String> ranglista = new ArrayList<>();

            String query = "{\n" +
                    "    \"structuredQuery\": {\n" +
                    "   \"where\" : {\n" +
                    "      \"fieldFilter\" : {\n" +
                    "         \"field\" : {\"fieldPath\" : \"nazivKviza\"}, \n" +
                    "         \"op\" : \"EQUAL\", \n" +
                    "                \"value\" : {\"stringValue\" : \""+kviz.getIdKviza()+"\"}\n" +
                    "   }\n" +
                    "  },\n" +
                    "\"select\" : { "+
                    "\"fields\" : ["+
                    "{\"fieldPath\" : \"lista\"}, {\"fieldPath\" : \"nazivKviza\"}] },\n"+
                    " \"from\" : [{\"collectionId\" : \"Rangliste\"}], \n" +
                    " \"limit\" : 1000 \n"+
                    " }\n}";

            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(
                        Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala-411ce/databases/(default)/" +
                        "documents:runQuery?access_token=";
                try {

                    URL urlObj2 = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn2 = (HttpURLConnection) urlObj2.openConnection();
                    conn2.setDoInput(true);
                    conn2.setRequestMethod("POST");
                    conn2.setRequestProperty("Content-Type", "application/json");
                    conn2.setRequestProperty("Accept", "application/json");


                    try (OutputStream os = conn2.getOutputStream()) {
                        byte[] input = query.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                    int code = conn2.getResponseCode();
                    InputStream odgovor2 = conn2.getInputStream();
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(odgovor2));
                    StringBuilder sb = new StringBuilder();
                    String rezulat = null;

                    try {
                        while ((rezulat = reader2.readLine()) != null) {
                            sb.append(rezulat + "\n");
                        }
                    } catch (IOException e) {
                    } finally {
                        try {
                            odgovor2.close();
                        } catch (IOException e) {
                        }
                    }

                    try {

                        JSONArray array = new JSONArray(sb.toString());
                        try {
                            for(int i=0; i<array.length(); i++) {
                                String igrac = "";
                                pozicija1++;
                                JSONObject object = array.getJSONObject(i);
                                JSONObject doc = object.getJSONObject("document");
                                JSONObject fields = doc.getJSONObject("fields");
                                JSONObject lista = fields.getJSONObject("lista");
                                JSONObject mapa = lista.getJSONObject("mapValue");
                                JSONObject fi = mapa.getJSONObject("fields");
                                igrac += fi.getJSONObject("pozicija").getString("stringValue");

                                igrac += " "+fi.
                                        getJSONObject("vrijednost").
                                        getJSONObject("mapValue").
                                        getJSONObject("fields").
                                        getJSONObject("ime").getString("stringValue") +
                                        "       "+ fi.
                                                getJSONObject("vrijednost").
                                                getJSONObject("mapValue").
                                                getJSONObject("fields").
                                                getJSONObject("procenat").getInt("integerValue")+"%";
                                ranglista.add(igrac);

                            }
                        } catch (JSONException e) {
                        }
                    } catch (JSONException e) {
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return ranglista;
        }

        @Override
        protected void onPostExecute(ArrayList<String> lista) {
            super.onPostExecute(lista);

            rangListaIgraci = lista;
            ukupanBrojIgraca = lista.size();

            RangLista rangLista = new RangLista();
            config = getResources().getConfiguration();
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.remove(pitanjeFrag);
            fragmentTransaction.remove(informacijeFrag);
            fragmentTransaction.add(R.id.ranglista, rangLista);
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("lista", rangListaIgraci);
            rangLista.setArguments(bundle);
            fragmentTransaction.commit();

        }
    }

    public class MyReceiver extends BroadcastReceiver {

        public MyReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "Intent Detected.", Toast.LENGTH_LONG).show();
        }
    }

    public class AlarmReceiver extends WakefulBroadcastReceiver {

        @Override
        public void onReceive(final Context context, Intent intent) {

            Toast.makeText(context, "Intenddt Detected.", Toast.LENGTH_LONG).show();
        }
    }

    public class AlarmHelper {
        private Context mCtx;

        public AlarmHelper(Context ctx) {
            mCtx = ctx;
        }

        public void setAlarm() {
            try {
                Calendar calendar = Calendar.getInstance();

                calendar.set(Calendar.MONTH, 8);
                calendar.set(Calendar.YEAR, 2015);
                calendar.set(Calendar.DAY_OF_MONTH, 27);

                calendar.set(Calendar.HOUR_OF_DAY, 14);
                calendar.set(Calendar.MINUTE, 52);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.AM_PM, Calendar.PM);

                Intent myIntent = new Intent(mCtx, MyReceiver.class);
                AlarmManager alarmManager = (AlarmManager) mCtx.getSystemService(mCtx.ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), PendingIntent.getBroadcast(mCtx, 1, myIntent, PendingIntent.FLAG_UPDATE_CURRENT));
            } catch (Exception e) {

            }
        }
    }
}
