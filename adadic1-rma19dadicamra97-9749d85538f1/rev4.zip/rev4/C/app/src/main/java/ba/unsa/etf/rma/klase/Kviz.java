package ba.unsa.etf.rma.klase;


import java.io.Serializable;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class Kviz implements Serializable{
    public String naziv;
    ArrayList<Pitanje> pitanja;
    ArrayList<String> indexiPitanja;
    Kategorija kategorija;
    String idKategorije;
    public int indicator = 0;
    public int idKviza = 0;

    public int image = android.R.drawable.ic_input_add;

    public Kviz(){
    }

    public int getIndicator() {
        return indicator;
    }

    public int getIdKviza() {
        return idKviza;
    }

    public void setIdKviza(int idKviza) {
        this.idKviza = idKviza;
    }

    public void dodajPitanje(Pitanje pitanje){
        if(pitanja==null){
            pitanja = new ArrayList<>();
        }
        pitanja.add(pitanje);
    }

    public void setIndicator(int indicator) {
        this.indicator = indicator;
    }

    public String getIdKategorije() {
        return idKategorije;
    }

    public void setIdKategorije(String idKategorije) {
        this.idKategorije = idKategorije;
    }

    public ArrayList<String> getIndexiPitanja() {
        return indexiPitanja;
    }

    public void setIndexiPitanja(ArrayList<String> indexiPitanja) {
        this.indexiPitanja = indexiPitanja;
    }

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija, int image, int indicator) {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
        this.image = image;
        this.indicator = indicator;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

}
