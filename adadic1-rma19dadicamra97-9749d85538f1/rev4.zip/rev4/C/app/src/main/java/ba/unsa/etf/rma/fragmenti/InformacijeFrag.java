package ba.unsa.etf.rma.fragmenti;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link InformacijeFrag.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link InformacijeFrag#newInstance} factory method to
 * create an instance of this fragment.
 */

public class InformacijeFrag extends Fragment implements View.OnClickListener {
    View.OnClickListener callback;
    public View view;
    public Button button;
    private FragmentCallback mCallback;

    public TextView nazivKviza;
    public TextView brTacnihPitanja;
    public TextView brPreostalihPitanja;
    public TextView procenatTacnihOdgovora;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private InformacijeFrag.OnFragmentInteractionListener mListener;

    public InformacijeFrag() {
        // Required empty public constructor
    }


    // This interface can be implemented by the Activity, parent Fragment,
    // or a separate test implementation.

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment InformacijeFrag.
     */
    // TODO: Rename and change types and number of parameters
    public static InformacijeFrag newInstance(String param1, String param2) {
        InformacijeFrag fragment = new InformacijeFrag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCallback = new FragmentCallback() {
            @Override
            public void onClickButton(InformacijeFrag fragment) {
                switch (fragment.getId()) {
                    case R.id.btnKraj:
                       // mCallback.onClickButton(this);
                        Toast.makeText(getContext(), "klik", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    public void AzurirajInfo(int brojTacnihOdgovora, int brojPreostalihPitanja, Double procenatTacnihOdg){
        brTacnihPitanja.setText(brojTacnihOdgovora);
        brPreostalihPitanja.setText(brojPreostalihPitanja);
        procenatTacnihOdgovora.setText(String.valueOf(procenatTacnihOdg));
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        //super.onSaveInstanceState(outState);
    }
    @SuppressLint("ResourceType")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Aktivirati landscape layout
        view = inflater.inflate(R.layout.informacije_place, container, false);
        button = (Button) view.findViewById(R.id.btnKraj);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onFragmentInteraction("prekid");
            }
        });

        nazivKviza = (TextView) view.findViewById(R.id.infNazivKviza);


        nazivKviza.setText(getArguments().getString("Naziv"));//kviz.getNaziv());

        brTacnihPitanja = (TextView) view.findViewById(R.id.infBrojTacnihPitanja);
        brPreostalihPitanja = (TextView) view.findViewById(R.id.infBrojPreostalihPitanja);
        procenatTacnihOdgovora = (TextView) view.findViewById(R.id.infProcenatTacni);

        brPreostalihPitanja.setText(String.valueOf(getArguments().getInt("BrojPreostalihPitanja")));
        brTacnihPitanja.setText(String.valueOf(getArguments().getInt("BrojTacnihOdgovora")));
        DecimalFormat df = new DecimalFormat("####0.00");
        procenatTacnihOdgovora.setText(String.valueOf(df.format(getArguments().getDouble("procenat")*100))+"%");


        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    /*public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }*/

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof InformacijeFrag.OnFragmentInteractionListener) {
            mListener = (InformacijeFrag.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(String string);
    }


    public interface FragmentCallback {
        void onClickButton(InformacijeFrag fragment);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnKraj:
                mCallback.onClickButton(this);
                break;
        }
    }
}
