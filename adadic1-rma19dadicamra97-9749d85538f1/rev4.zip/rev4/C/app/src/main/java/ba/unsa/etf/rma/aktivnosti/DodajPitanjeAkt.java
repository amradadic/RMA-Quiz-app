package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CustomAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {

    public ListView listView;
    public EditText etNaziv;
    public ArrayList<String> odgovori;
    public Pitanje pitanje;
    public boolean error=false;
    public int postavljeni=0;
    public Kviz kviz;
    public String tacanOdg, edit;
    public CustomAdapter<String> customAdapter;
    public int indexTacnog = 0;
    public EditText etOdgovor;
    public Button dodajOdgovor;


    public HashMap<Kategorija, ArrayList<Kviz>> mapaKvizova;
    public HashMap<Kategorija, Boolean> mapaKategorija;
    public HashMap<Kategorija, Integer> mapaIdKategorija;
    public int ukupanBrojPitanja = 0;
    public int ukupanBrojKvizova = 0;
    public int ukupanBrojKategorija = 0;
    public Button dodajTacanOdgovor;
    public Button dodajPitanje;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);



        dodajTacanOdgovor = (Button) findViewById(R.id.btnDodajTacan);
        dodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);
        odgovori = new ArrayList<>();
        listView = (ListView) findViewById(R.id.lvOdgovori);
        etNaziv = (EditText) findViewById(R.id.etNaziv);


        mapaKategorija = new HashMap<>();
        mapaKvizova = new HashMap<>();


        etOdgovor = (EditText) findViewById(R.id.etOdgovor);
        dodajOdgovor = (Button) findViewById(R.id.btnDodajOdgovor);

        mapaIdKategorija = new HashMap<>();

        mapaIdKategorija = (HashMap<Kategorija, Integer>) getIntent().getSerializableExtra("mapaIdKategorija");
        mapaKvizova = (HashMap<Kategorija, ArrayList<Kviz>>) getIntent().getSerializableExtra("mapaKvizova");
        mapaKategorija = (HashMap<Kategorija, Boolean>) getIntent().getSerializableExtra("mapaKategorija");
        ukupanBrojPitanja = getIntent().getIntExtra("ukupanBrojPitanja", 0);
        ukupanBrojKategorija = getIntent().getIntExtra("ukupanBrojKategorija", 0);
        ukupanBrojKvizova =  getIntent().getIntExtra("ukupanBrojKvizova", 0);



        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        kviz = ((Kviz) getIntent().getSerializableExtra("Kviz"));

        customAdapter = new CustomAdapter<>(this,
                R.layout.elementi_liste, odgovori);


        listView.setAdapter(customAdapter);
        edit = new String();




        edit = (String) getIntent().getStringExtra("Edit");


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                odgovori.remove(position);
                customAdapter.notifyDataSetChanged();
            }
        });

        dodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etOdgovor.getText().toString().isEmpty()){
                    etOdgovor.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                }
                else{
                    odgovori.add(etOdgovor.getText().toString());
                    customAdapter.notifyDataSetChanged();
                }
            }
        });

        dodajTacanOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etOdgovor.getText().toString().isEmpty()){
                    etOdgovor.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                }
                else{
                    odgovori.add("1"+etOdgovor.getText().toString());
                    indexTacnog = odgovori.size();
                    tacanOdg = etOdgovor.getText().toString();
                    customAdapter.notifyDataSetChanged();
                }
            }
        });

        dodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = etNaziv.getText().toString();
                for(Pitanje p: kviz.getPitanja())
                    if(p.getNaziv().equals(temp))
                        error = true;

                if(odgovori.isEmpty()) error = true;

                if(!error){
                    ArrayList<Pitanje> tempPitanja = (ArrayList<Pitanje>) ((ArrayList<Pitanje>) getIntent().getSerializableExtra("MogucaPitanja")).clone();
                    ArrayList<Kategorija> kategorijas = (ArrayList<Kategorija>) ((ArrayList<Kategorija>) getIntent().getSerializableExtra("Kategorije")).clone();
                    ArrayList<Kviz> kvizovi = (ArrayList<Kviz>) ((ArrayList<Kviz>) getIntent().getSerializableExtra("Kvizovi")).clone();
                    ArrayList<Pitanje> dodanaPitanja2 = (ArrayList<Pitanje>) ((ArrayList<Pitanje>) getIntent().getSerializableExtra("DodanaPitanja")).clone();
                    Kviz kviz2 = (Kviz)  getIntent().getSerializableExtra("Kviz");
                    int pozicija = (int) getIntent().getIntExtra("Pozicija", -1);
                    postavljeni = (int) getIntent().getIntExtra("Postavljeni", 0);

                    pitanje = new Pitanje();
                    pitanje.setNaziv(String.valueOf(++ukupanBrojPitanja));
                    pitanje.setTekstPitanja(etNaziv.getText().toString());
                    pitanje.setOdgovori(odgovori);




                    pitanje.setTacan(tacanOdg);
                    pitanje.setImage(android.R.drawable.ic_input_add);
                    pitanje.setIndexTacnog(indexTacnog);
                    kviz.getPitanja().add(pitanje);
                    Pitanje tempPitanje2 = dodanaPitanja2.get(dodanaPitanja2.size()-1);
                    dodanaPitanja2.remove(dodanaPitanja2.size()-1);
                    dodanaPitanja2.add(pitanje);
                    dodanaPitanja2.add(tempPitanje2);

                    Intent intent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                    intent.putExtra("Pitanje", pitanje);
                    intent.putExtra("DodatnaPitanja", tempPitanja);
                    intent.putExtra("DodanaPitanja", dodanaPitanja2);


                    intent.putExtra("Edit", edit);
                    intent.putExtra("Kviz", kviz2);
                    intent.putExtra("Pozicija", pozicija);
                    intent.putExtra("mapaKategorija", mapaKategorija);


                    intent.putExtra("Postavljeni", postavljeni);
                    intent.putExtra("mapaIdKategorija", mapaIdKategorija);


                    intent.putExtra("Kategorije", kategorijas);
                    intent.putExtra("Kvizovi", kvizovi);
                    intent.putExtra("mapaKvizova", mapaKvizova);
                    intent.putExtra("ukupanBrojPitanja", ukupanBrojPitanja);
                    intent.putExtra("ukupanBrojKategorija", ukupanBrojKategorija);
                    intent.putExtra("ukupanBrojKvizova", ukupanBrojKvizova);



                    DodajPitanjeAkt.this.startActivity(intent);
                    finish();
                }
            }
        });

        etNaziv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                error = false;
            }
        });
    }
}
