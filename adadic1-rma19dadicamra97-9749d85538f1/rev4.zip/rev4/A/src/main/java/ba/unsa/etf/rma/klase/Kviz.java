package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

public class Kviz implements Parcelable, Comparable {
    private String naziv;
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private Kategorija kategorija;
    private String id;

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija){
        id = naziv;
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
    }

    public Kviz(String id, String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija){
        this.id = id;
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
    }

    protected Kviz(Parcel in) {
        naziv = in.readString();
        kategorija = in.readParcelable(Kategorija.class.getClassLoader());
    }

    public static final Creator<Kviz> CREATOR = new Creator<Kviz>() {
        @Override
        public Kviz createFromParcel(Parcel in) {
            return new Kviz(in);
        }

        @Override
        public Kviz[] newArray(int size) {
            return new Kviz[size];
        }
    };

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void dodajPitanje(Pitanje pitanje){
        pitanja.add(pitanje);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(naziv);
        dest.writeParcelable(kategorija, flags);
    }

    @Override
    public int compareTo(Object o) {
        Kviz k = (Kviz) o;
        if(k.getNaziv().equalsIgnoreCase(this.getNaziv())) return 0;
        else return 1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Kviz kviz = (Kviz) o;
        return Objects.equals(naziv, kviz.naziv) &&
                Objects.equals(pitanja, kviz.pitanja) &&
                Objects.equals(kategorija, kviz.kategorija);
    }

    @Override
    public int hashCode() {
        return Objects.hash(naziv);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
