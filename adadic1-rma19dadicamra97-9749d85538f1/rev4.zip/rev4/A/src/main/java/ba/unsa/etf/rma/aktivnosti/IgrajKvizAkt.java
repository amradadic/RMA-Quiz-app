package ba.unsa.etf.rma.aktivnosti;


import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.InformacijeFragListener, PitanjeFrag.PitanjeFragListener {

    private PitanjeFrag pitanjeFrag;
    private InformacijeFrag informacijeFrag;
    private Intent intent;
    private FragmentManager fm;
    public static Intent intentZaAlarm;
    public static PendingIntent pendingIntent;
    public static AlarmManager am;
    private Ringtone ringtone;
    private BroadcastReceiver receiver;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_igraj_kviz_akt);

        intent = getIntent();
        fm = getSupportFragmentManager();

        Kviz kviz = intent.getParcelableExtra("kviz");
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        pitanja = intent.getParcelableArrayListExtra("pitanja");

        for(Pitanje p : pitanja){
            if(p.getNaziv().equalsIgnoreCase("Dodaj pitanje")){
                pitanja.remove(p);
                break;
            }
        }


        if(pitanja.size() != 0) {
            Calendar cal = Calendar.getInstance();
            if (pitanja.size() % 2 == 0) {
                cal.add(Calendar.MINUTE, pitanja.size() / 2);
            } else if (pitanja.size() == 1) {
                cal.add(Calendar.SECOND, 30);
            } else {
                cal.add(Calendar.MINUTE, pitanja.size() / 2);
                cal.add(Calendar.SECOND, 30);

            }

            receiver = dajBroadcastReceiver();
            this.registerReceiver(receiver, new IntentFilter("isteklo"));

            pendingIntent = PendingIntent.getBroadcast(this, 12345, new Intent("isteklo"), 0);


            am = (AlarmManager) getSystemService(Activity.ALARM_SERVICE);
            am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
        }



        FrameLayout info = (FrameLayout) findViewById(R.id.informacijePlace);
        FrameLayout ques = (FrameLayout) findViewById(R.id.pitanjePlace);



        if(informacijeFrag == null){

            informacijeFrag = new InformacijeFrag();

            Bundle argumenti=new Bundle();
            argumenti.putParcelable("kviz", kviz);
            argumenti.putParcelableArrayList("pitanja", pitanja);
            informacijeFrag.setArguments(argumenti);

            fm.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        }

        if(pitanjeFrag == null){

            pitanjeFrag = new PitanjeFrag();

            Bundle argumenti=new Bundle();
            argumenti.putParcelable("kviz", kviz);
            argumenti.putParcelableArrayList("pitanja", pitanja);
            pitanjeFrag.setArguments(argumenti);

            fm.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
        }


    }

    @Override
    public void onInputASent(CharSequence tacni, CharSequence preostali, CharSequence procenat) {
        informacijeFrag.updateEditText(tacni, preostali, procenat);
    }

    @Override
    public void onInputBSent(CharSequence brojTacnihChar, CharSequence brojPreostalihChar, CharSequence postotakTacnihChar) {
        //ne radi se nista
    }

    private BroadcastReceiver dajBroadcastReceiver() {
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent )
            {
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                ringtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
                ringtone.play();

                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("TIME IS UP!");
                alertDialog.setMessage("Vrijeme za igranje kviza je isteklo!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                ringtone.stop();
                                finish();
                            }
                        });
                alertDialog.show();
            }
        };
        return receiver;
    }

}
