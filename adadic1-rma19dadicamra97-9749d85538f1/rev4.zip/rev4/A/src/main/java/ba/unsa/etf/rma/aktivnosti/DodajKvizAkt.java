package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.adapteri.AdapterZaListuPitanja;
import ba.unsa.etf.rma.adapteri.AdapterZaSpinner;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.R;

public class DodajKvizAkt extends AppCompatActivity {
    Intent intent;
    Spinner spinner;
    EditText imeKviza;
    Button button, importujKviz;
    ListView listaPitanja;
    ListView listaMogucihPitanja;
    ArrayList<Kategorija> kategorije;
    AdapterZaSpinner adapterZaSpinner;
    ArrayList<Kviz> kvizovi = new ArrayList<>();
    ArrayList<Pitanje> pitanja = new ArrayList<>();
    ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();
    AdapterZaListuPitanja adapterZaListuPitanja;
    AdapterZaListuPitanja adapterZaListuMogucihPitanja;
    int pozicijaKliknutogKviza;
    private static final int READ_REQUEST_CODE = 99;
    Kviz kviz, noviKviz;
    private static int ikonica = 1;
    private String TOKEN = "", idKviza, stariNaziv;
    private boolean azuriranje;
    Kategorija novaKategorija;
    Pitanje novoPitanje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodavanje_azuriranje_kviza);

        new DajToken().execute("dajToken");

        intent = getIntent();

        importujKviz = (Button) findViewById(R.id.btnImportKviz);
        spinner = (Spinner) findViewById(R.id.spKategorije);
        button = (Button) findViewById(R.id.btnDodajKviz);
        imeKviza = (EditText) findViewById(R.id.etNaziv);
        listaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        listaMogucihPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);


        kvizovi = intent.getParcelableArrayListExtra("listaKvizovi");
        kategorije = intent.getParcelableArrayListExtra("kategorije");
        kviz = (Kviz) intent.getParcelableExtra("pritisnutiKviz");

        if (intent.getParcelableArrayListExtra("pitanja") != null) {
            pitanja = intent.getParcelableArrayListExtra("pitanja");
        }



        pozicijaKliknutogKviza = intent.getIntExtra("pozicijaKliknutogKviza", -1);

        boolean dodajKategoriju = false;
        for(Kategorija p : kategorije){
            if(p.getNaziv().equalsIgnoreCase("Dodaj kategoriju")){
                dodajKategoriju = true;
                break;
            }
        }
        if(!dodajKategoriju){
            kategorije.add(new Kategorija("Dodaj kategoriju", "dodajKategoriju"));
        }

        adapterZaSpinner = new AdapterZaSpinner(this, kategorije);
        spinner.setAdapter(adapterZaSpinner);


        boolean dodajPitanje = false;
        for(Pitanje p : pitanja){
            if(p.getNaziv().equalsIgnoreCase("Dodaj pitanje")){
                dodajPitanje = true;
                break;
            }
        }
        if(!dodajPitanje){
            pitanja.add(new Pitanje("Dodaj pitanje", null, null, null));
        }

        adapterZaListuPitanja = new AdapterZaListuPitanja(this, pitanja, getResources());
        listaPitanja.setAdapter(adapterZaListuPitanja);

        adapterZaListuMogucihPitanja = new AdapterZaListuPitanja(this, mogucaPitanja, getResources());
        listaMogucihPitanja.setAdapter(adapterZaListuMogucihPitanja);

        if (kviz.getKategorija() != null) {

            idKviza = (String) intent.getStringExtra("idKviza");
            kviz.setId(idKviza);
            stariNaziv = kviz.getNaziv();
            imeKviza.setText(kviz.getNaziv()); // provjeri slucajeve oko prikazivanja ili ne kategorije SVI
            int pozicija = kategorije.indexOf(kviz.getKategorija());
            spinner.setSelection(pozicija);//PROMJENA
            azuriranje = true;

        } else {

            spinner.setSelection(0);
            azuriranje = false;

        }


        new DobaviPitanja().execute("Pitanja");

        listaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < pitanja.size() - 1) { //ako nije pritisnuto na dodaj pitanje
                    mogucaPitanja.add(pitanja.get(position));
                    pitanja.remove(pitanja.get(position));
                    adapterZaListuPitanja.notifyDataSetChanged();
                    adapterZaListuMogucihPitanja.notifyDataSetChanged();
                } else {
                    Intent dodajPitanje = new Intent(getApplicationContext(), DodajPitanjeAkt.class);
                    dodajPitanje.putParcelableArrayListExtra("odgovori", pitanja);
                    dodajPitanje.putExtra("kojePitanjeJePritisnuto", position);
                    startActivityForResult(dodajPitanje, 1);
                }
            }
        });

        listaMogucihPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pitanja.add(pitanja.size() - 1, mogucaPitanja.get(position));
                mogucaPitanja.remove(mogucaPitanja.get(position));
                adapterZaListuPitanja.notifyDataSetChanged();
                adapterZaListuMogucihPitanja.notifyDataSetChanged();
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imeKviza.getText().toString().matches("")) {

                    imeKviza.setBackgroundColor(Color.RED);

                } else {

                    if (azuriranje) {

                        noviKviz = new Kviz(imeKviza.getText().toString(), imeKviza.getText().toString(), pitanja, (Kategorija) spinner.getSelectedItem());

                        if (stariNaziv.equalsIgnoreCase(imeKviza.getText().toString())) {
                            new AzurirajKviz().execute("Kvizovi", noviKviz.getId());
                        } else {
                            new ObrisiDodajKviz().execute("Kvizovi", kviz.getId());
                        }

                    } else {

                        noviKviz = new Kviz(imeKviza.getText().toString(), pitanja, (Kategorija) spinner.getSelectedItem());
                        new PostojiLiKvizUBazi().execute("Kvizovi", noviKviz.getId());

                    }


                }
            }
        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == kategorije.size() - 1) {
                    Intent novaKategorija = new Intent(getApplicationContext(), DodajKategorijuAkt.class);
                    novaKategorija.putParcelableArrayListExtra("kategory", kategorije);
                    startActivityForResult(novaKategorija, 2);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        importujKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (kviz.getKategorija() != null) {

                    prikaziAlert("Samo kada dodajete kviz mozete importovati, pri editovanju importovanje nije dozvoljeno");

                } else {

                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

                    intent.addCategory(Intent.CATEGORY_OPENABLE);

                    intent.setType("text/*");

                    startActivityForResult(intent, READ_REQUEST_CODE);

                }
            }
        });

    }

    public void prikaziAlert(String s) {
        AlertDialog alert = new AlertDialog.Builder(DodajKvizAkt.this)
                .setTitle("Greska")
                .setMessage(s)
                .setNeutralButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();
        alert.show();
    }

    private ArrayList<String> readTextFromUri(Uri uri) throws Exception {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<String> kvizIzDatoteke = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {

            if (line.equals("")) {
                continue;
            }
            kvizIzDatoteke.add(line);
        }

        inputStream.close();
        reader.close();

        return kvizIzDatoteke;
    }

    public boolean kvizVecPostoji(ArrayList<String> lista) throws Exception {
        String[] s = lista.get(0).split(",");
        for (Kviz i : kvizovi) {
            if (i.getNaziv().equalsIgnoreCase(s[0])) return true;
        }
        return false;
    }

    public boolean nesipravanBrojPitanja(ArrayList<String> lista) {

        String[] s = lista.get(0).split(",");
        if (lista.size() - 1 == Integer.parseInt(s[2])) {
            return false;
        }
        return true;
    }

    public boolean neispravanBrojOdgovora(ArrayList<String> lista) {

        for (int i = 1; i < lista.size(); i++) {
            String[] s = lista.get(i).split(",");


            if (Integer.parseInt(s[1]) != s.length - 3) {
                return true;
            }
        }
        return false;
    }

    public boolean neispravanIndeks(ArrayList<String> lista) {

        for (int i = 1; i < lista.size(); i++) {
            String[] s = lista.get(i).split(",");

            if (Integer.parseInt(s[2]) < 0 || Integer.parseInt(s[2]) >= s.length - 3) {
                return true;
            }
        }
        return false;
    }

    public void postaviIliDodajKategoriju(String[] s) {

        novaKategorija = new Kategorija(s[1], Integer.toString(ikonica++));

        new PostojiLiKategorija().execute("Kategorije", s[1]);
    }

    public void staviPitanja(ArrayList<String> pitanja) {

        for (int i = 1; i < pitanja.size(); i++) {

            String[] odgovoriIOstalo = pitanja.get(i).split(",");
            ArrayList<String> sviOdgovori = new ArrayList<>();

            for (int j = 3; j < odgovoriIOstalo.length; j++) {
                sviOdgovori.add(odgovoriIOstalo[j]);
            }

            int pozicijaTacnogOdgovora = Integer.parseInt(odgovoriIOstalo[2]);
            Pitanje novoPitanje = new Pitanje(odgovoriIOstalo[0], null, odgovoriIOstalo[3 + pozicijaTacnogOdgovora], sviOdgovori);

            this.pitanja.add(this.pitanja.size() - 1, novoPitanje);

        }
        adapterZaListuPitanja.notifyDataSetChanged();
    }

    public boolean postojeLiIstaPitanja(ArrayList<String> lista) {

        ArrayList<String> zaProvjeruIstihPitanja = new ArrayList<>();
        for (int i = 1; i < lista.size(); i++) {
            String[] jedanRedUDatoteci = lista.get(i).split(",");
            zaProvjeruIstihPitanja.add(jedanRedUDatoteci[0]);
        }

        Set<String> set = new HashSet<>(zaProvjeruIstihPitanja);

        if (set.size() == zaProvjeruIstihPitanja.size()) {
            return false;
        }
        return true;
    }

    public boolean imaLiIstihOdgovora(ArrayList<String> lista) {

        boolean imaLiDuplikata = false;

        for (int i = 1; i < lista.size(); i++) {

            String[] s = lista.get(i).split(",");
            ArrayList<String> pomocni = new ArrayList<>();
            for (int j = 3; j < s.length; j++) {
                pomocni.add(s[j]);
            }

            Set<String> set = new HashSet<>(pomocni);

            if (set.size() == pomocni.size()) {
                imaLiDuplikata = false;
            } else {
                imaLiDuplikata = true;
                break;
            }
        }
        if (imaLiDuplikata) {
            return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Uri uri = null;
            if (data != null) {
                uri = data.getData(); // Ispitaj sta ako je prazna dateka ili neispravnog formata

                try {
                    ArrayList<String> kvizIzDatoteke = readTextFromUri(uri);

                    if (kvizVecPostoji(kvizIzDatoteke)) {
                        prikaziAlert("Kviz kojeg importujete već postoji!");
                    } else if (nesipravanBrojPitanja(kvizIzDatoteke)) {
                        prikaziAlert("Kviz kojeg imporujete ima neispravan broj pitanja!");
                    } else if (neispravanBrojOdgovora(kvizIzDatoteke)) {
                        prikaziAlert("Kviz kojeg importujete ima neispravan broj odgovora!");
                    } else if (neispravanIndeks(kvizIzDatoteke)) {
                        prikaziAlert("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
                    } else if (postojeLiIstaPitanja(kvizIzDatoteke)) {
                        prikaziAlert("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                    } else if (imaLiIstihOdgovora(kvizIzDatoteke)) {
                        prikaziAlert("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
                    } else {

                        String[] prvaLinija = kvizIzDatoteke.get(0).split(",");
                        imeKviza.setText(prvaLinija[0]);

                        postaviIliDodajKategoriju(prvaLinija);
                        staviPitanja(kvizIzDatoteke);

                    }


                } catch (Exception e) {
                    prikaziAlert("Datoteka kviza kojeg importujete nema ispravan format!");
                    e.printStackTrace();
                }


            }
        }

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                novoPitanje = data.getParcelableExtra("novoPitanje");
                novoPitanje.setOdgovori(data.getStringArrayListExtra("odg"));
                pitanja.add(pitanja.size() - 1, novoPitanje);
                adapterZaListuPitanja.notifyDataSetChanged();

                String odgovori = "";
                int j = 0;
                for(String o : novoPitanje.getOdgovori()) {// odgovore stavljam u stri  ng kako bih mogao dodat u bazu
                    if (j != novoPitanje.getOdgovori().size() - 1)
                        odgovori += o + ",";
                    else odgovori += o;
                }

                new DodajPitanje().execute(odgovori);
            }
        }


        if (requestCode == 2) {
            if (resultCode == RESULT_OK) {
                novaKategorija = data.getParcelableExtra("novaKategorija");
                if (data.getIntExtra("nazad", -1) == 1) {
                    spinner.setSelection(0);
                    adapterZaSpinner.notifyDataSetChanged();
                } else {
                    new DodajKategorijuUBazu().execute("dodavanjeKategorijeUBazu");
                    kategorije.add(kategorije.size() - 1, novaKategorija);
                    adapterZaSpinner.notifyDataSetChanged();
                }

            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent vratiKategorije = new Intent(getApplicationContext(), KvizoviAkt.class);
        kategorije.remove(kategorije.size() - 1);
        vratiKategorije.putParcelableArrayListExtra("azuriraneKategorije", kategorije);
        setResult(RESULT_OK, vratiKategorije);
        finish();
    }

    public static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
        } finally {
            try {
                is.close();
            } catch (IOException e) {
            }
        }
        return sb.toString();
    }

    private class DajToken extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential googleCredential;
            try {
                InputStream tajna = getResources().openRawResource(R.raw.secret);
                googleCredential = GoogleCredential.fromStream(tajna).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));

                googleCredential.refreshToken();
                TOKEN = googleCredential.getAccessToken();
                Log.d("TOKEN", TOKEN);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class DobaviPitanja extends AsyncTask<String, Integer, ArrayList<Pitanje>> {

        @Override
        protected void onPostExecute(ArrayList<Pitanje> pitanjes) {
            super.onPostExecute(pitanjes);
            mogucaPitanja.clear();
            mogucaPitanja.addAll(pitanjes);
            adapterZaListuMogucihPitanja.notifyDataSetChanged();
        }

        @Override
        protected ArrayList<Pitanje> doInBackground(String... urls) {
            String url1;
            ArrayList<Pitanje> listaMogucih = new ArrayList<>();
            if (urls.length == 1)
                url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "?access_token=" + TOKEN;
            else
                url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=" + TOKEN;
            URL url;

            try {
                url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);
                JSONObject jo = null;
                jo = new JSONObject(rezultat);
                JSONArray items = new JSONArray();
                if (urls[0].equalsIgnoreCase("Pitanja")) {
                    items = jo.getJSONArray("documents");
                    ArrayList<Pitanje> ucitanaPitanja = ucitajSvaPitanjaIzBaze(items);
                    boolean postojiLi = false;
                    for (Pitanje p : ucitanaPitanja) {
                        for (Pitanje pitanje : pitanja) {
                            if (pitanje.compareTo(p) == 0) postojiLi = true;
                        }
                        if (!postojiLi) listaMogucih.add(p);
                        postojiLi = false;
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return listaMogucih;
        }
    }

    public static ArrayList<Pitanje> ucitajSvaPitanjaIzBaze(JSONArray items) {
        ArrayList<Pitanje> pitanjaIzBaze = new ArrayList<>();
        try {
            for (int i = 0; i < items.length(); i++) {
                JSONObject name = null;
                name = items.getJSONObject(i);
                JSONObject kviz = name.getJSONObject("fields");
                String naziv = kviz.getJSONObject("naziv").getString("stringValue");
                int indexTacnog = Integer.parseInt(kviz.getJSONObject("indexTacnog").getString("integerValue"));
                ArrayList<String> odgovori = new ArrayList<String>();
                JSONArray jArray = kviz.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                for (int j = 0; j < jArray.length(); j++) {
                    odgovori.add(jArray.getJSONObject(j).getString("stringValue"));
                }
                Pitanje pitanje = new Pitanje(naziv, naziv, odgovori.get(indexTacnog), odgovori);
                pitanjaIzBaze.add(pitanje);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return pitanjaIzBaze;
    }

    private class DodajKviz extends AsyncTask<String, Integer, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            try {
                String url = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/Kvizovi?documentId=" + noviKviz.getId() + "&access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int i = 0;
                String dokument = "{ \"fields\": { \"pitanja\": { \"arrayValue\": { \"values\": [";
                for (Pitanje p : noviKviz.getPitanja()) {
                    if (i < noviKviz.getPitanja().size() - 2)
                        dokument += "{ \"stringValue\": \"" + p.getNaziv() + "\"}, ";
                    else if (i == noviKviz.getPitanja().size() - 2)
                        dokument += "{ \"stringValue\": \"" + p.getNaziv() + "\"} ";
                    i++;
                }
                dokument += "]}}, \"naziv\": { \"stringValue\": \"" + noviKviz.getNaziv() + "\"}, \"idKategorije\": { \"stringValue\": \"" + noviKviz.getKategorija().getNaziv() + "\"}}}";


                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("odgovor", response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class AzurirajKviz extends AsyncTask<String, Integer, Void> {

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            Intent vratiKviz = new Intent(getApplicationContext(), KvizoviAkt.class);

            vratiKviz.putExtra("idKviza", noviKviz.getId());

            vratiKviz.putExtra("noviKviz", noviKviz);

            vratiKviz.putParcelableArrayListExtra("azuriraneKategorije", kategorije);

            vratiKviz.putParcelableArrayListExtra("pitanja", pitanja);

            vratiKviz.putExtra("pozicijaKliknutogKviza", pozicijaKliknutogKviza);

            setResult(RESULT_OK, vratiKviz);

            finish();
        }

        @Override
        protected Void doInBackground(String... urls) {
            String url = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=";

            try {
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int i = 0;
                String dokument = "{ \"fields\": { \"pitanja\": { \"arrayValue\": { \"values\": [";
                for (Pitanje p : noviKviz.getPitanja()) {
                    if (i < noviKviz.getPitanja().size() - 2)
                        dokument += "{ \"stringValue\": \"" + p.getNaziv() + "\"}, ";
                    else if (i == noviKviz.getPitanja().size() - 2)
                        dokument += "{ \"stringValue\": \"" + p.getNaziv() + "\"} ";
                    i++;
                }
                dokument += "]}}, \"naziv\": { \"stringValue\": \"" + noviKviz.getNaziv() + "\"}, \"idKategorije\": { \"stringValue\": \"" + noviKviz.getKategorija().getNaziv() + "\"}}}";

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class PostojiLiKvizUBazi extends AsyncTask<String, Integer, Integer> {

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                new DodajKviz().execute("Kvizovi", noviKviz.getId());

                kategorije.remove(kategorije.size() - 1);

                Intent vratiKviz = new Intent(getApplicationContext(), KvizoviAkt.class);

                vratiKviz.putExtra("idKviza", noviKviz.getId());

                vratiKviz.putExtra("noviKviz", noviKviz);

                vratiKviz.putParcelableArrayListExtra("azuriraneKategorije", kategorije);

                vratiKviz.putParcelableArrayListExtra("pitanja", pitanja);

                vratiKviz.putExtra("pozicijaKliknutogKviza", pozicijaKliknutogKviza);

                setResult(RESULT_OK, vratiKviz);

                finish();

            } else {

                AlertDialog alertDialog = new AlertDialog.Builder(DodajKvizAkt.this).create();
                alertDialog.setTitle("Greska");
                alertDialog.setMessage("Kviz pod tim imenom vec postoji!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        }

        protected Integer doInBackground(String... urls) {
            try {
                String url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=" + TOKEN;
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                return 1;
            }
            return 0;
        }
    }

    private class DodajKategorijuUBazu extends AsyncTask<String, Integer, Void> {

        @Override
        protected Void doInBackground(String... strings) {

            try {
                String url = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/Kategorije?documentId=" + novaKategorija.getNaziv() + "&access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"idIkonice\": { \"integerValue\": \"" + novaKategorija.getId() + "\"}, \"naziv\": { \"stringValue\": \"" + novaKategorija.getNaziv() + "\"}}}";
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("odgovor", response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    private class ObrisiDodajKviz extends AsyncTask<String, Integer, Void> {

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new PostojiLiKvizUBazi().execute("Kvizovi", noviKviz.getId());
        }

        @Override
        protected Void doInBackground(String... strings) {
            String url = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + strings[0] + "/" + strings[1] + "?access_token=";
            String dokument = "";
            try {

                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class DodajPitanje extends AsyncTask<String, Integer, Void>{

        @Override
        protected Void doInBackground(String... strings) {
            try {
                String url = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/Pitanja?documentId=" + novoPitanje.getNaziv() + "&access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument;
                String[] odgovori = strings[0].split(",");
                int i = 0;
                dokument = "{ \"fields\": { \"naziv\": { \"stringValue\": \"" + novoPitanje.getNaziv() + "\"}, \"odgovori\": { \"arrayValue\": { \"values\": [" ;
                for(String p : odgovori) {
                    if(i++ != odgovori.length - 1)
                        dokument += "{ \"stringValue\": \"" + p + "\"}, ";
                    else dokument += "{ \"stringValue\": \"" + p + "\"} ";
                }
                dokument += "]}}, \"indexTacnog\": { \"integerValue\": \"" + novoPitanje.getOdgovori().indexOf(novoPitanje.getTacan()) + "\"}}}";


                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("odgovor", response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }




            return null;
        }
    }

    private class PostojiLiKategorija extends AsyncTask<String, Integer, Integer> {

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if (integer == 1) {

                try {
                    new DodajKategorijuUBazu().execute("Kategorije", novaKategorija.getNaziv()).get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Toast.makeText(getApplicationContext(),"Kategrija dodata u bazu",Toast.LENGTH_SHORT).show();
                kategorije.add(kategorije.size() - 1, novaKategorija);
                spinner.setSelection(kategorije.size() - 2);
                adapterZaSpinner.notifyDataSetChanged();

            } else {
                Toast.makeText(getApplicationContext(),"Kategrija je vec postojala u bazi",Toast.LENGTH_SHORT).show();
                kategorije.add(kategorije.size() - 1, novaKategorija);
                spinner.setSelection(kategorije.size() - 2);
                adapterZaSpinner.notifyDataSetChanged();
            }
        }

        protected Integer doInBackground(String... urls) {
            try {
                String url1;
                if (urls.length == 1)
                    url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "?access_token=" + TOKEN;
                else
                    url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=" + TOKEN;
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                return 1;
            }
            return 0;
        }
    }
}
