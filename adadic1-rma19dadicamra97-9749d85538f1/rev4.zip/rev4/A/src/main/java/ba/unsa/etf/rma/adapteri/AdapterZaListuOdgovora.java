package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class AdapterZaListuOdgovora extends BaseAdapter {

    Activity context;
    ArrayList<String> muzicari;
    private static LayoutInflater infalter = null;
    Resources resources;
    private int pozicija = - 1;
    String tempValues;


    public AdapterZaListuOdgovora(Activity context, ArrayList<String> muzicari, Resources res) {
        this.context = context;
        this.muzicari = muzicari;
        resources = res;

        infalter = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return muzicari.size();
    }

    @Override
    public Object getItem(int position) {
        return muzicari.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder{

        public TextView odgovor;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        ViewHolder holder;

        if(convertView==null){

            /****** Inflate tabitem.xml file for each row ( Defined below ) *******/
            vi = infalter.inflate(R.layout.element_odgovora, null);

            /****** View Holder Object to contain tabitem.xml file elements ******/

            holder = new ViewHolder();
            holder.odgovor = (TextView) vi.findViewById(R.id.textView4);


            /************  Set holder with LayoutInflater ************/
            vi.setTag( holder );
        }
        else
            holder=(ViewHolder)vi.getTag();

        if(muzicari.size()<=0)
        {
            holder.odgovor.setText("No Data");

        }
        else
        {
            /***** Get each Model object from Arraylist ********/
            tempValues=null;
            tempValues = (String ) muzicari.get( position );

            /************  Set Model values in Holder elements ***********/

            holder.odgovor.setText( tempValues );
        }

        holder.odgovor.setBackgroundColor(0x00000000);
        if(position == pozicija){
            holder.odgovor.setBackgroundColor(Color.GREEN);
        }
        return vi;
    }

    public int getPozicija() {
        return pozicija;
    }

    public void setPozicija(int pozicija) {
        this.pozicija = pozicija;
    }
}